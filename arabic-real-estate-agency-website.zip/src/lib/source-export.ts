import { createHash } from "node:crypto";
import { lstat, readFile, readdir, realpath } from "node:fs/promises";
import path from "node:path";
import { zipSync, type Zippable } from "fflate";

const ROOT_FILES = [
  "package.json", "package-lock.json", "tsconfig.json", "next-env.d.ts",
  "next.config.ts", "postcss.config.mjs", "eslint.config.mjs", "drizzle.config.ts",
  ".env.example", ".gitignore", ".nvmrc", "PROJECT-FILES.json", "README.md", "START-HERE.html", "DEPLOYMENT-AR.md", "AUDIT-REPORT-AR.md",
] as const;
const CORE_FILES = [
  "src/app/layout.tsx", "src/app/globals.css", "src/app/(site)/page.tsx",
  "src/app/(site)/layout.tsx", "src/app/admin/(auth)/login/page.tsx",
  "src/app/admin/(panel)/layout.tsx", "src/app/api/health/route.ts", "src/proxy.ts",
  "src/app/uploads/[...path]/route.ts",
  "src/db/index.ts", "src/db/schema.ts", "src/lib/auth.ts", "src/lib/source-export.ts",
  "public/.gitkeep", "public/favicon.svg", "scripts/seed.ts",
  "scripts/check-deployment.mjs", "scripts/verify-download.mjs", "scripts/export-project.ts",
] as const;
const INCLUDED_DIRECTORIES = ["src", "public", "scripts"] as const;
const OPTIONAL_DIRECTORIES = ["drizzle"] as const;
const MAX_FILES = 3000;
const MAX_FILE_BYTES = 16 * 1024 * 1024;
const MAX_TOTAL_BYTES = 32 * 1024 * 1024;
const ARCHIVE_ROOT = "arabic-real-estate";

export type SourceManifestEntry = { path: string; bytes: number; sha256: string };
export type SourceManifest = {
  format: "arabic-real-estate-source-v1";
  createdAt: string;
  framework: "Next.js App Router";
  entryPoint: "src/app/(site)/page.tsx";
  requiresNodeServer: true;
  includesRuntimeData: false;
  fileCount: number;
  files: SourceManifestEntry[];
  excluded: string[];
};
export type SourceBundle = { zip: Uint8Array; manifest: SourceManifest };

function isPrivatePath(relative: string): boolean {
  const parts = relative.split("/");
  const blocked = new Set(["node_modules", ".next", ".git", ".vercel", ".railway", "coverage"]);
  if (parts.some((part) => blocked.has(part))) return true;
  // Only root runtime directories are private. src/app/uploads is application
  // code serving those images and MUST be included in every complete source ZIP.
  if (parts[0] === "uploads" || parts[0] === "exports") return true;
  const name = parts.at(-1) ?? "";
  if (name.startsWith(".env") && relative !== ".env.example") return true;
  return /\.(?:cookies|log|pem|key|p12|pfx|tsbuildinfo)$/i.test(name) || name === ".DS_Store";
}

/** Read-only allowlisted source export. Never include credentials or customer data. */
export async function createSourceBundle(rootDirectory = process.cwd()): Promise<SourceBundle> {
  const root = await realpath(/*turbopackIgnore: true*/ rootDirectory);
  const candidates = new Set<string>(ROOT_FILES);
  async function collect(relative: string, optional = false) {
    const directory = path.join(/*turbopackIgnore: true*/ root, relative);
    let info;
    try { info = await lstat(directory); } catch {
      if (optional) return;
      throw new Error(`Required source directory is missing: ${relative}`);
    }
    if (!info.isDirectory() || info.isSymbolicLink()) throw new Error(`Unsafe or incomplete source directory: ${relative}`);
    const entries = await readdir(directory, { withFileTypes: true });
    for (const entry of entries) {
      const child = `${relative}/${entry.name}`;
      if (isPrivatePath(child)) continue;
      if (entry.isSymbolicLink()) throw new Error(`Source archive cannot include a symbolic link: ${child}`);
      if (entry.isDirectory()) await collect(child);
      else if (entry.isFile()) candidates.add(child);
      else throw new Error(`Unsupported source file: ${child}`);
      if (candidates.size > MAX_FILES) throw new Error("Source archive exceeds its file limit");
    }
  }
  for (const directory of INCLUDED_DIRECTORIES) await collect(directory);
  for (const directory of OPTIONAL_DIRECTORIES) await collect(directory, true);
  const contract = JSON.parse(await readFile(path.join(/*turbopackIgnore: true*/ root, "PROJECT-FILES.json"), "utf8")) as { format?: unknown; files?: unknown; routes?: unknown };
  if (contract.format !== "arabic-real-estate-delivery-v1" || !Array.isArray(contract.files) || !contract.files.length || contract.files.length > MAX_FILES || !Array.isArray(contract.routes)) {
    throw new Error("A valid PROJECT-FILES.json delivery contract is required before exporting source.");
  }
  const requiredPaths = new Set<string>(CORE_FILES);
  for (const entry of contract.files) {
    if (typeof entry !== "string" || isPrivatePath(entry) || entry.startsWith("/") || /[\\\\\u0000:]/.test(entry) || entry.split("/").some((part) => !part || part === "." || part === "..")) throw new Error("Unsafe path in delivery contract.");
    requiredPaths.add(entry);
  }
  for (const required of requiredPaths) {
    if (!candidates.has(required)) throw new Error(`Required application file is missing: ${required}`);
  }

  const input: Zippable = Object.create(null);
  const files: SourceManifestEntry[] = [];
  let totalBytes = 0;
  for (const relative of [...candidates].sort()) {
    if (isPrivatePath(relative) || relative.startsWith("/") || relative.includes("\\") || relative.split("/").some((part) => !part || part === "." || part === "..")) {
      throw new Error("Unsafe archive path encountered");
    }
    const filename = path.join(/*turbopackIgnore: true*/ root, relative);
    const info = await lstat(filename);
    if (!info.isFile() || info.isSymbolicLink()) throw new Error(`Source file must be a regular file: ${relative}`);
    if (info.size > MAX_FILE_BYTES || totalBytes + info.size > MAX_TOTAL_BYTES) throw new Error("Source archive exceeds its size limit");
    const bytes = await readFile(filename);
    if (bytes.length > MAX_FILE_BYTES || totalBytes + bytes.length > MAX_TOTAL_BYTES) throw new Error("Source archive exceeds its size limit");
    totalBytes += bytes.length;
    input[`${ARCHIVE_ROOT}/${relative}`] = bytes;
    files.push({ path: relative, bytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex") });
  }

  // Never distribute secrets accidentally entered into the example template.
  const example = await readFile(path.join(root, ".env.example"), "utf8");
  for (const key of ["DATABASE_URL", "AUTH_SECRET", "ADMIN_EMAIL", "ADMIN_PASSWORD"]) {
    if (!new RegExp(`^${key}=\\s*$`, "m").test(example)) throw new Error("The environment example must contain empty credential values");
  }
  const pkg = JSON.parse(await readFile(path.join(root, "package.json"), "utf8"));
  const lock = JSON.parse(await readFile(path.join(root, "package-lock.json"), "utf8"));
  const locked = lock.packages?.[""];
  if (!locked) throw new Error("Package lockfile is incomplete");
  for (const kind of ["dependencies", "devDependencies"]) {
    const current = pkg[kind] ?? {};
    const pinned = locked[kind] ?? {};
    const keys = new Set([...Object.keys(current), ...Object.keys(pinned)]);
    if ([...keys].some((key) => current[key] !== pinned[key])) throw new Error("Package lockfile does not match package.json");
  }

  const manifest: SourceManifest = {
    format: "arabic-real-estate-source-v1", createdAt: new Date().toISOString(),
    framework: "Next.js App Router", entryPoint: "src/app/(site)/page.tsx",
    requiresNodeServer: true, includesRuntimeData: false, fileCount: files.length, files,
    excluded: [".env and credentials", "node_modules/", ".next/", "uploads/", "PostgreSQL data", ".git/", "exports/"],
  };
  input[`${ARCHIVE_ROOT}/PROJECT-MANIFEST.json`] = new TextEncoder().encode(JSON.stringify(manifest, null, 2) + "\n");
  const zip = zipSync(input, { level: 6, mtime: new Date("2020-01-01T00:00:00Z") });
  return { zip, manifest };
}
