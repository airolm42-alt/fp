import { redirect } from "next/navigation";
import { getCurrentAdmin } from "@/lib/auth";
import { getAllSettings } from "@/lib/settings";
import { getSiteUrlInfo } from "@/lib/site-url";
import { PageHeader } from "@/components/admin/admin-shell";
import { PublishingPanel, type PublishingCheck } from "@/components/admin/publishing-panel";

export const dynamic = "force-dynamic";
export const metadata = { title: "النشر والروابط — لوحة الإدارة", robots: { index: false, follow: false } };

export default async function PublishingPage() {
  const admin = await getCurrentAdmin();
  if (!admin) redirect("/admin/login");
  const [info, { business, seo }] = await Promise.all([getSiteUrlInfo(), getAllSettings()]);

  let remoteDatabase = false;
  try {
    const host = new URL(process.env.DATABASE_URL ?? "").hostname;
    remoteDatabase = !!host && !["localhost", "127.0.0.1", "[::1]"].includes(host);
  } catch {}

  const checks: PublishingCheck[] = [
    { label: "نطاق إنتاج محفوظ", ready: info.kind === "public" && !!info.configuredOrigin, description: "احفظ عنوانك بعد أن يفتح الموقع بالفعل. لا تعتمد عنوان المعاينة." },
    { label: "سر الجلسة مضبوط في البيئة", ready: (process.env.AUTH_SECRET?.length ?? 0) >= 32, description: "AUTH_SECRET يجب أن يكون عشوائيًا وقويًا، وليس قيمة افتراضية أو منشورة." },
    { label: "اتصال قاعدة بيانات خارجية", ready: remoteDatabase, description: "انقل البيانات إلى PostgreSQL الإنتاج وفعّل النسخ الاحتياطية؛ الاتصال الخارجي وحده لا يؤكد وجود نسخ احتياطية." },
    { label: "مسار صور محدد", ready: !!(process.env.UPLOAD_DIR || process.env.RAILWAY_VOLUME_MOUNT_PATH), description: "ربط Volume أو التخزين الدائم ضروري. وجود المسار في المتغيرات ليس إثباتًا أن التخزين دائم." },
    { label: "بيانات النشاط", ready: !!business.businessName, description: "املأ اسم نشاطك الحقيقي وبيانات التواصل قبل إرساله للعملاء." },
    { label: "عنوان ووصف البحث", ready: !!(seo.siteTitle && seo.siteDescription), description: "ثم وثّق الدومين الحقيقي في Search Console وأرسل sitemap.xml." },
  ];

  return <div><PageHeader title="النشر والروابط" description="دليل عملي للانتقال من المعاينة إلى عنوان ثابت للموقع والإدارة" /><PublishingPanel baseUrl={info.url} configuredUrl={info.configuredOrigin ?? ""} kind={info.kind} canManage={admin.isOwner} checks={checks} /></div>;
}
