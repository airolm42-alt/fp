import { NextRequest, NextResponse } from "next/server";
import { getAdminFromToken, SESSION_COOKIE } from "@/lib/auth";
import { isUuid } from "@/lib/input-safety";

function privateJson(message: string, status: number) {
  return NextResponse.json({ error: message }, { status, headers: { "Cache-Control": "private, no-store" } });
}
export async function proxy(req: NextRequest) {
  const pathname = req.nextUrl.pathname;
  const token = req.cookies.get(SESSION_COOKIE)?.value;
  const admin = token ? await getAdminFromToken(token) : null;
  const isApi = pathname.startsWith("/api/admin/");
  if (isApi) {
    if (!["GET", "HEAD", "OPTIONS"].includes(req.method)) {
      const origin = req.headers.get("origin");
      const host = (req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? "").split(",")[0].trim();
      try {
        if ((origin && new URL(origin).host !== host) || (!origin && req.headers.get("sec-fetch-site") === "cross-site")) return privateJson("مصدر الطلب غير مسموح", 403);
      } catch { return privateJson("مصدر الطلب غير مسموح", 403); }
      const size = Number(req.headers.get("content-length") ?? "0");
      if (size > (pathname === "/api/admin/upload" ? 25 * 1024 * 1024 : 128 * 1024)) return privateJson("حجم الطلب أكبر من المسموح", 413);
    }
    if (!admin && pathname !== "/api/admin/login") return privateJson("انتهت الجلسة أو لم يتم تسجيل الدخول", 401);
    if (admin?.mustChangePassword && !["/api/admin/account", "/api/admin/logout", "/api/admin/session"].includes(pathname)) return privateJson("غيّر كلمة المرور المبدئية من صفحة حسابي أولًا", 403);
    const match = pathname.match(/^\/api\/admin\/(?:properties|services|types|areas|inquiries|team)\/([^/]+)$/);
    if (match && !isUuid(match[1])) return privateJson("معرّف غير صالح", 400);
  } else {
    if (!admin && pathname !== "/admin/login") {
      const url = req.nextUrl.clone(); url.pathname = "/admin/login"; url.search = ""; url.searchParams.set("next", pathname);
      return NextResponse.redirect(url);
    }
    if (admin?.mustChangePassword && pathname !== "/admin/account") return NextResponse.redirect(new URL("/admin/account", req.url));
    if (admin && pathname === "/admin/login") return NextResponse.redirect(new URL("/admin/dashboard", req.url));
  }
  const requestHeaders = new Headers(req.headers);
  requestHeaders.set("x-admin-path", pathname);
  const response = NextResponse.next({ request: { headers: requestHeaders } });
  response.headers.set("Cache-Control", "private, no-store");
  response.headers.set("X-Robots-Tag", "noindex, nofollow");
  return response;
}
export const config = { matcher: ["/admin/:path*", "/api/admin/:path*"] };
