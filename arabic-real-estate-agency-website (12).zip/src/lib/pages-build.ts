import { build } from "esbuild";
import { mkdir, readFile, rm, writeFile, copyFile } from "node:fs/promises";
import path from "node:path";
import os from "node:os";
import { createHash } from "node:crypto";
import { normalizeSiteOrigin, siteOriginKind } from "@/lib/site-origin";

export type PagesBuildOptions = { apiUrl: string; siteUrl?: string; outputDirectory?: string; rootDirectory?: string; allowLocal?: boolean };
export type PagesBuildResult = { directory: string; files: { path: string; bytes: number; sha256: string }[]; apiOrigin: string; siteUrl: string; adminUrl: string };
function htmlEscape(text: string) { return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;"); }
function jsonScript(value: unknown) { return JSON.stringify(value).replace(/</g, "\\u003c").replace(/>/g, "\\u003e").replace(/&/g, "\\u0026"); }

/** Build ONLY the static public frontend; no database access and no secrets. */
export async function buildPages(options: PagesBuildOptions): Promise<PagesBuildResult> {
  const root = path.resolve(/*turbopackIgnore: true*/ options.rootDirectory ?? process.cwd());
  const apiOrigin = normalizeSiteOrigin(options.apiUrl);
  if (!apiOrigin || options.apiUrl.trim().replace(/\/$/, "") !== apiOrigin || !options.allowLocal && siteOriginKind(apiOrigin) === "local") throw new Error("PAGES_API_URL must be the exact public HTTPS backend origin without /api, paths, credentials, or query strings. Local HTTP is allowed only with --allow-local for tests.");
  let siteUrl = "";
  if (options.siteUrl) {
    const value = new URL(options.siteUrl);
    if ((!options.allowLocal && (value.protocol !== "https:" || !normalizeSiteOrigin(value.origin) || siteOriginKind(value.origin) === "local")) || !["https:", "http:"].includes(value.protocol) || value.username || value.password || value.search || value.hash) throw new Error("PAGES_SITE_URL must be the public Pages URL, optionally including /repository/.");
    siteUrl = value.href.replace(/\/*$/, "/");
  }
  const directory = path.resolve(/*turbopackIgnore: true*/ options.outputDirectory ?? path.join(root, "out-pages"));
  const permittedDefault = path.join(root, "out-pages");
  const temporary = directory.startsWith(path.join(os.tmpdir(), "arabic-pages-") );
  if (directory !== permittedDefault && !temporary) throw new Error("Pages output must be out-pages/ or a private arabic-pages-* temporary directory");
  // Only this generated output directory is cleared; the Next.js app is untouched.
  await rm(directory, { recursive: true, force: true });
  await mkdir(path.join(directory, "assets"), { recursive: true });
  const result = await build({
    absWorkingDir: root, entryPoints: ["github-pages/src/app.tsx"], outdir: path.join(directory, "assets"), entryNames: "app-[hash]", assetNames: "asset-[hash]",
    bundle: true, minify: true, sourcemap: false, platform: "browser", format: "esm", target: ["es2022"], jsx: "automatic", write: false, metafile: true,
    define: { "process.env.NODE_ENV": '"production"' }, legalComments: "none", logLevel: "silent",
  });
  const allFiles: string[] = [];
  for (const output of result.outputFiles ?? []) {
    const relative = path.relative(directory, output.path).replaceAll("\\", "/");
    if (relative.startsWith("../") || !relative.startsWith("assets/")) throw new Error("Unexpected static output path");
    await writeFile(output.path, output.contents); allFiles.push(relative);
  }
  const script = allFiles.find((file) => file.endsWith(".js"));
  const style = allFiles.find((file) => file.endsWith(".css"));
  if (!script || !style) throw new Error("Static JavaScript/CSS output missing");
  const backendInputs = Object.keys(result.metafile?.inputs ?? {}).filter((name) => /(?:src\/db\/|src\/lib\/(?:auth|settings|public-data|rate-limit|pages-access)\.|node_modules\/(?:pg|drizzle-orm|jose)\/)/.test(name));
  if (backendInputs.length) throw new Error("Server-only code would be included in the browser bundle");
  const runtime = { version: 1, apiOrigin, siteUrl };
  const head = [`<link rel="stylesheet" href="./${style}">`, siteUrl ? `<link rel="canonical" href="${htmlEscape(siteUrl)}">` : '<meta name="robots" content="noindex, nofollow">'].join("\n  ");
  let html = await readFile(path.join(root, "github-pages/index.html"), "utf8");
  for (const token of ["<!--PAGES_HEAD-->", "<!--PAGES_RUNTIME-->", "<!--PAGES_SCRIPTS-->"]) if (!html.includes(token)) throw new Error("Pages HTML template is incomplete");
  html = html.replace("<!--PAGES_HEAD-->", head).replace("<!--PAGES_RUNTIME-->", jsonScript(runtime)).replace("<!--PAGES_SCRIPTS-->", `<script type="module" src="./${script}"></script>`);
  await writeFile(path.join(directory, "index.html"), html); allFiles.push("index.html");
  // Hash navigation supports refresh/deep links under any repository base path.
  const base = siteUrl ? `<base href="${htmlEscape(siteUrl)}">` : "";
  await writeFile(path.join(directory, "404.html"), html.replace("<head>", `<head>${base}`)); allFiles.push("404.html");
  await writeFile(path.join(directory, ".nojekyll"), ""); allFiles.push(".nojekyll");
  await copyFile(path.join(root, "public/favicon.svg"), path.join(directory, "assets/favicon.svg")); allFiles.push("assets/favicon.svg");
  const adminUrl = `${apiOrigin}/admin`;
  await mkdir(path.join(directory, "admin"), { recursive: true });
  await writeFile(path.join(directory, "admin/index.html"), `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><meta http-equiv="refresh" content="0;url=${htmlEscape(adminUrl)}"><title>دخول الإدارة على الخادم المحمي</title></head><body><h1>دخول الإدارة</h1><p>الدخول وبيانات الحسابات موجودة على الخادم المحمي، وليست على GitHub Pages.</p><a href="${htmlEscape(adminUrl)}">افتح صفحة تسجيل الدخول الحقيقية</a></body></html>`); allFiles.push("admin/index.html");
  await writeFile(path.join(directory, "robots.txt"), siteUrl ? `User-agent: *\nAllow: /\nSitemap: ${siteUrl}sitemap.xml\n` : "User-agent: *\nDisallow: /\n"); allFiles.push("robots.txt");
  if (siteUrl) { await writeFile(path.join(directory, "sitemap.xml"), `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${htmlEscape(siteUrl)}</loc></url></urlset>`); allFiles.push("sitemap.xml"); }
  await writeFile(path.join(directory, "PAGES-SETUP.txt"), `واجهة عامة ثابتة متصلة بخادم حقيقي.\nعنوان API العام: ${apiOrigin}\nدخول الإدارة: ${adminUrl}\nمطلوب على الخادم: PAGES_ALLOWED_ORIGINS يضم أصل GitHub Pages مثل https://OWNER.github.io دون اسم المستودع.\nالمجلد لا يحتوي قاعدة بيانات أو كلمات مرور أو أسرار. يحتاج API حيًا لعرض البيانات وحفظ الاستفسارات.\nروابط الصفحات تستخدم # لتعمل تحت /REPOSITORY/ دون خادم إعادة كتابة.\nلا تتساوى قابلية البناء مع النشر أو موافقة شروط استضافة Pages للاستخدام التجاري.\n`); allFiles.push("PAGES-SETUP.txt");
  const files = await Promise.all(allFiles.sort().map(async (name) => { const bytes = await readFile(path.join(directory, name)); return { path: name, bytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex") }; }));
  const buildMetadata = new TextEncoder().encode(JSON.stringify({ format: "arabic-real-estate-pages-v1", apiOrigin, siteUrl, adminUrl, builtAt: new Date().toISOString(), files, containsCredentials: false, requiresLiveBackend: true }, null, 2) + "\n");
  await writeFile(path.join(directory, "PAGES-BUILD.json"), buildMetadata);
  return { directory, files: [...files, { path: "PAGES-BUILD.json", bytes: buildMetadata.length, sha256: createHash("sha256").update(buildMetadata).digest("hex") }], apiOrigin, siteUrl, adminUrl };
}
