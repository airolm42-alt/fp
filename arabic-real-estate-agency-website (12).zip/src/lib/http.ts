import { NextResponse } from "next/server";

export class RequestError extends Error { constructor(message: string, public status = 400) { super(message); } }

/** Stream and limit bodies before parsing instead of trusting Content-Length. */
export async function readBodyLimited(req: Request, maxBytes: number): Promise<Uint8Array> {
  const length = req.headers.get("content-length");
  if (length && Number(length) > maxBytes) throw new RequestError("حجم الطلب أكبر من المسموح", 413);
  if (!req.body) throw new RequestError("الطلب فارغ");
  const reader = req.body.getReader();
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > maxBytes) { await reader.cancel(); throw new RequestError("حجم الطلب أكبر من المسموح", 413); }
      chunks.push(value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  return bytes;
}
export async function readJsonBody(req: Request, maxBytes = 128 * 1024): Promise<unknown> {
  if (!req.headers.get("content-type")?.toLowerCase().startsWith("application/json")) throw new RequestError("الطلب يجب أن يكون JSON", 415);
  try { return JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(await readBodyLimited(req, maxBytes))); }
  catch (error) { if (error instanceof RequestError) throw error; throw new RequestError("بيانات JSON غير صالحة"); }
}
export function apiError(error: unknown, fallback = "تعذّر تنفيذ العملية") {
  if (error instanceof RequestError) return NextResponse.json({ error: error.message }, { status: error.status });
  const cause = error as { code?: string; cause?: { code?: string } };
  const code = cause?.code ?? cause?.cause?.code;
  if (code === "23505") return NextResponse.json({ error: "هذه البيانات أو الرابط موجود بالفعل" }, { status: 409 });
  if (code === "23503") return NextResponse.json({ error: "العنصر المرتبط غير موجود أو ما زال مستخدمًا" }, { status: 400 });
  console.error(fallback, error instanceof Error ? error.message : "unknown error");
  return NextResponse.json({ error: fallback }, { status: 500 });
}
