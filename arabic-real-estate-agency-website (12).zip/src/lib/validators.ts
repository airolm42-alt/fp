import { z } from "zod";
import { imagePathSchema, optionalHttpsUrl, optionalPhoneSchema, passwordSchema } from "@/lib/input-safety";

export const propertyInputSchema = z.object({
  title: z.string().trim().min(2, "العنوان مطلوب").max(200),
  slug: z.string().trim().max(120).default(""),
  description: z.string().trim().max(10000).default(""),
  typeId: z.string().uuid().nullable().optional(),
  listingType: z.enum(["sale", "rent"]),
  price: z.union([z.number().finite().min(0).max(9_999_999_999_999), z.literal("")]).nullable().optional(),
  currency: z.string().trim().min(1).max(20).default("ج.م"),
  location: z.string().trim().max(300).default(""),
  address: z.string().trim().max(500).default(""),
  area: z.union([z.number().finite().min(0).max(99_999_999), z.literal("")]).nullable().optional(),
  bedrooms: z.union([z.number().int().min(0).max(50), z.literal("")]).nullable().optional(),
  bathrooms: z.union([z.number().int().min(0).max(50), z.literal("")]).nullable().optional(),
  floor: z.string().trim().max(50).default(""),
  finishing: z.string().trim().max(100).default(""),
  features: z.array(z.string().trim().min(1).max(120)).max(60).default([]),
  mainImage: imagePathSchema,
  images: z.array(z.object({ url: imagePathSchema.refine(Boolean, "الصورة مطلوبة"), alt: z.string().trim().max(300).default("") })).max(40).default([]),
  googleMapsUrl: optionalHttpsUrl,
  whatsappMessage: z.string().trim().max(500).default(""),
  status: z.enum(["draft", "published"]).default("draft"),
  featured: z.boolean().default(false),
  metaTitle: z.string().trim().max(200).default(""),
  metaDescription: z.string().trim().max(300).default(""),
});
export type PropertyInput = z.infer<typeof propertyInputSchema>;
export const serviceInputSchema = z.object({
  title: z.string().trim().min(2, "اسم الخدمة مطلوب").max(200),
  description: z.string().trim().max(3000).default(""), icon: z.string().max(60).default(""),
  image: imagePathSchema, published: z.boolean().default(false), sort: z.number().int().min(-10000).max(10000).default(0),
});
export const areaInputSchema = z.object({
  name: z.string().trim().min(2, "اسم المنطقة مطلوب").max(200),
  description: z.string().trim().max(1000).default(""), image: imagePathSchema,
  published: z.boolean().default(true), sort: z.number().int().min(-10000).max(10000).default(0),
});
export const typeInputSchema = z.object({ name: z.string().trim().min(2, "اسم النوع مطلوب").max(100), slug: z.string().trim().max(120).default("") });
export const inquiryInputSchema = z.object({
  name: z.string().trim().min(2, "الاسم مطلوب").max(120),
  phone: optionalPhoneSchema.refine(Boolean, "رقم الهاتف مطلوب"),
  email: z.union([z.string().trim().email("بريد إلكتروني غير صالح").max(200), z.literal("")]).optional(),
  message: z.string().trim().min(5, "الرسالة مطلوبة").max(3000),
  propertyId: z.string().uuid().nullable().optional(),
  website: z.string().max(200).optional().default(""),
});
export const inquiryStatusSchema = z.object({ status: z.enum(["new", "contacted", "closed"]) });
export const accountProfileSchema = z.object({ name: z.string().trim().min(2).max(120), email: z.string().trim().email().max(200) });
export const accountPasswordSchema = z.object({ currentPassword: z.string().min(1, "كلمة المرور الحالية مطلوبة").max(200), newPassword: passwordSchema });
export const createAdminSchema = z.object({ name: z.string().trim().min(2, "الاسم مطلوب").max(120), email: z.string().trim().email("بريد إلكتروني غير صالح").max(200), password: passwordSchema, mustChangePassword: z.boolean().default(true) });
export const resetAdminPasswordSchema = z.object({ password: passwordSchema });
export const loginSchema = z.object({ email: z.string().trim().email("بريد إلكتروني غير صالح").max(200), password: z.string().min(1, "كلمة المرور مطلوبة").max(200) });
