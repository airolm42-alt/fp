import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/* ------------------------------ Formatting ------------------------------ */
export function formatNumber(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "";
  const n = typeof value === "string" ? Number(value) : value;
  if (Number.isNaN(n)) return "";
  return new Intl.NumberFormat("ar-EG-u-nu-latn", { maximumFractionDigits: 2 }).format(n);
}

export function formatPrice(
  price: number | string | null | undefined,
  currency = "ج.م",
): string {
  const n = formatNumber(price);
  if (!n) return "السعر عند الطلب";
  return `${n} ${currency}`;
}

export function formatDate(date: Date | string | null | undefined): string {
  if (!date) return "";
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat("ar-EG-u-nu-latn", {
    dateStyle: "medium",
    timeStyle: "short",
  }).format(d);
}

/* -------------------------------- Slugging ------------------------------- */
const AR_MAP: Record<string, string> = {
  ا: "a", أ: "a", إ: "e", آ: "a", ب: "b", ت: "t", ث: "th", ج: "g", ح: "h", خ: "kh",
  د: "d", ذ: "z", ر: "r", ز: "z", س: "s", ش: "sh", ص: "s", ض: "d", ط: "t", ظ: "z",
  ع: "a", غ: "gh", ف: "f", ق: "q", ك: "k", ل: "l", م: "m", ن: "n", ه: "h", ة: "a",
  و: "w", ى: "a", ي: "y", ء: "a", ؤ: "o", ئ: "e", "ـ": "", "0": "0", "١": "1", "٢": "2",
  "٣": "3", "٤": "4", "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9", "٠": "0",
};

export function slugify(input: string): string {
  const transliterated = input
    .split("")
    .map((ch) => AR_MAP[ch] ?? ch)
    .join("");
  const slug = transliterated
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
  return slug;
}

export function uniqueSlug(base: string): string {
  const suffix = Math.random().toString(36).slice(2, 7);
  const b = slugify(base);
  return b ? `${b}-${suffix}` : `property-${suffix}`;
}

/* -------------------------------- WhatsApp ------------------------------- */
export function normalizePhone(phone: string): string {
  const digits = phone.replace(/[٠-٩۰-۹]/g, (ch) => String("٠١٢٣٤٥٦٧٨٩".includes(ch) ? "٠١٢٣٤٥٦٧٨٩".indexOf(ch) : "۰۱۲۳۴۵۶۷۸۹".indexOf(ch))).replace(/[^\d]/g, "");
  return /^01[0125]\d{8}$/.test(digits) ? `2${digits}` : digits.replace(/^00/, "");
}

export function whatsappLink(number: string, message?: string): string {
  const n = normalizePhone(number);
  const base = `https://wa.me/${n}`;
  return message ? `${base}?text=${encodeURIComponent(message)}` : base;
}

export function mapsLink(url: string): string {
  return url;
}

export function isMapsEmbed(input: string): boolean {
  try {
    const url = new URL(input);
    return url.protocol === "https:" && /^(?:www\.)?google\.(?:com|com\.eg|co\.uk)$/.test(url.hostname) && (url.pathname.startsWith("/maps/embed") || url.pathname.startsWith("/maps") && url.searchParams.get("output") === "embed");
  } catch { return false; }
}
