import path from "node:path";

/** All upload operations share this runtime-only persistent directory. */
export function getUploadsDirectory(): string {
  const configured = process.env.UPLOAD_DIR?.trim() || process.env.RAILWAY_VOLUME_MOUNT_PATH?.trim();
  if (configured) {
    if (!path.isAbsolute(configured)) throw new Error("UPLOAD_DIR must be an absolute persistent storage path");
    return configured;
  }
  // Uploaded user content is runtime data, not files to bundle at build time.
  return path.join(/*turbopackIgnore: true*/ process.cwd(), "uploads");
}
