import { cache } from "react";
import { db } from "@/db";
import { properties, propertyImages, propertyTypes, services, areas } from "@/db/schema";
import { and, asc, desc, eq, gte, lte, ilike, or, sql, type SQL } from "drizzle-orm";
import { decimalFilter, isUuid, likePattern, pageNumber } from "@/lib/input-safety";

export type PropertyWithType = {
  id: string; title: string; slug: string; listingType: "sale" | "rent"; price: string | null;
  currency: string; location: string; area: string | null; bedrooms: number | null; bathrooms: number | null;
  mainImage: string; featured: boolean; createdAt: Date; typeName: string | null; description: string;
};
export type PropertyFilters = {
  q?: string; listing?: string; type?: string; location?: string; minPrice?: string; maxPrice?: string;
  beds?: string; baths?: string; minArea?: string; maxArea?: string; sort?: string; page?: number; featuredOnly?: boolean;
};
const columns = {
  id: properties.id, title: properties.title, slug: properties.slug, listingType: properties.listingType,
  price: properties.price, currency: properties.currency, location: properties.location, area: properties.area,
  bedrooms: properties.bedrooms, bathrooms: properties.bathrooms, mainImage: properties.mainImage,
  featured: properties.featured, createdAt: properties.createdAt, typeName: propertyTypes.name, description: properties.description,
};
const PAGE_SIZE = 12;
export async function getPublishedProperties(filters: PropertyFilters) {
  const conds: SQL[] = [eq(properties.status, "published")];
  if (filters.featuredOnly) conds.push(eq(properties.featured, true));
  if (filters.q?.trim()) conds.push(or(ilike(properties.title, likePattern(filters.q)), ilike(properties.location, likePattern(filters.q)), ilike(properties.description, likePattern(filters.q)))!);
  if (filters.listing === "sale" || filters.listing === "rent") conds.push(eq(properties.listingType, filters.listing));
  if (filters.type) {
    if (isUuid(filters.type)) conds.push(eq(properties.typeId, filters.type));
    else {
      const [type] = await db.select({ id: propertyTypes.id }).from(propertyTypes).where(eq(propertyTypes.slug, filters.type.slice(0, 120))).limit(1);
      conds.push(type ? eq(properties.typeId, type.id) : sql`false`);
    }
  }
  if (filters.location?.trim()) conds.push(ilike(properties.location, likePattern(filters.location, 300)));
  const minPrice = decimalFilter(filters.minPrice), maxPrice = decimalFilter(filters.maxPrice);
  const minArea = decimalFilter(filters.minArea, 99_999_999), maxArea = decimalFilter(filters.maxArea, 99_999_999);
  if (minPrice !== null) conds.push(gte(properties.price, minPrice));
  if (maxPrice !== null) conds.push(lte(properties.price, maxPrice));
  if (minArea !== null) conds.push(gte(properties.area, minArea));
  if (maxArea !== null) conds.push(lte(properties.area, maxArea));
  if (filters.beds && /^\d{1,2}$/.test(filters.beds) && Number(filters.beds) <= 50) conds.push(gte(properties.bedrooms, Number(filters.beds)));
  if (filters.baths && /^\d{1,2}$/.test(filters.baths) && Number(filters.baths) <= 50) conds.push(gte(properties.bathrooms, Number(filters.baths)));
  const order: SQL[] = filters.sort === "price_asc" ? [sql`${properties.price} asc nulls last`] : filters.sort === "price_desc" ? [sql`${properties.price} desc nulls last`]
    : filters.sort === "area_asc" ? [sql`${properties.area} asc nulls last`] : filters.sort === "area_desc" ? [sql`${properties.area} desc nulls last`]
    : filters.sort === "oldest" ? [asc(properties.createdAt)] : [desc(properties.featured), desc(properties.createdAt)];
  order.push(desc(properties.id));
  const page = pageNumber(filters.page);
  const where = and(...conds);
  const [items, counts] = await Promise.all([
    db.select(columns).from(properties).leftJoin(propertyTypes, eq(properties.typeId, propertyTypes.id)).where(where).orderBy(...order).limit(PAGE_SIZE).offset((page - 1) * PAGE_SIZE),
    db.select({ count: sql<number>`count(*)` }).from(properties).where(where),
  ]);
  const total = Number(counts[0]?.count ?? 0);
  return { items, total, page, pages: Math.max(1, Math.ceil(total / PAGE_SIZE)) };
}
export const getFeaturedProperties = cache(async (limit = 6) => db.select(columns).from(properties).leftJoin(propertyTypes, eq(properties.typeId, propertyTypes.id)).where(and(eq(properties.status, "published"), eq(properties.featured, true))).orderBy(desc(properties.createdAt)).limit(Math.min(12, Math.max(1, limit))));
export const getPropertyBySlug = cache(async (slug: string) => {
  let decoded;
  try { decoded = decodeURIComponent(slug); } catch { return null; }
  if (!decoded || decoded.length > 120) return null;
  const [property] = await db.select().from(properties).where(and(eq(properties.slug, decoded), eq(properties.status, "published"))).limit(1);
  if (!property) return null;
  const [images, types] = await Promise.all([
    db.select().from(propertyImages).where(eq(propertyImages.propertyId, property.id)).orderBy(asc(propertyImages.sort)),
    property.typeId ? db.select().from(propertyTypes).where(eq(propertyTypes.id, property.typeId)).limit(1) : Promise.resolve([]),
  ]);
  return { ...property, images, typeName: types[0]?.name ?? null };
});
export async function getSimilarProperties(property: { id: string; typeId: string | null; listingType: string }, limit = 3) {
  const publicOnly = and(eq(properties.status, "published"), sql`${properties.id} != ${property.id}`);
  const related = and(publicOnly, eq(properties.listingType, property.listingType as "sale" | "rent"), property.typeId ? eq(properties.typeId, property.typeId) : undefined);
  let rows = await db.select(columns).from(properties).leftJoin(propertyTypes, eq(properties.typeId, propertyTypes.id)).where(related).orderBy(desc(properties.createdAt)).limit(Math.min(limit, 6));
  if (!rows.length) rows = await db.select(columns).from(properties).leftJoin(propertyTypes, eq(properties.typeId, propertyTypes.id)).where(publicOnly).orderBy(desc(properties.createdAt)).limit(Math.min(limit, 6));
  return rows;
}
export const getPublishedServices = cache(async () => db.select().from(services).where(eq(services.published, true)).orderBy(asc(services.sort), asc(services.createdAt)));
export const getPublishedAreas = cache(async () => db.select().from(areas).where(eq(areas.published, true)).orderBy(asc(areas.sort), asc(areas.createdAt)));
export const getAllPropertyTypes = cache(async () => db.select().from(propertyTypes).orderBy(asc(propertyTypes.name)));
export const getDistinctLocations = cache(async () => (await db.selectDistinct({ location: properties.location }).from(properties).where(and(eq(properties.status, "published"), sql`${properties.location} != ''`)).orderBy(properties.location).limit(40)).map((row) => row.location));
