import { createHash } from "node:crypto";
import { isIP } from "node:net";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { securityLimits } from "@/db/schema";

/** Configure the hosting reverse proxy to overwrite forwarded client IPs. */
export function clientIp(headers: Headers): string {
  const raw = (headers.get("x-real-ip") ?? headers.get("x-forwarded-for")?.split(",")[0] ?? "").trim();
  return isIP(raw) ? raw : "unknown-client";
}
export async function consumeLimit(scope: string, identity: string, maximum: number, windowSeconds: number) {
  const key = `${scope}:${createHash("sha256").update(identity.slice(0, 500)).digest("hex")}`;
  const expiry = new Date(Date.now() + windowSeconds * 1000);
  const [row] = await db.insert(securityLimits).values({ key, hits: 1, expiresAt: expiry })
    .onConflictDoUpdate({ target: securityLimits.key, set: {
      hits: sql`case when ${securityLimits.expiresAt} <= now() then 1 else ${securityLimits.hits} + 1 end`,
      expiresAt: sql`case when ${securityLimits.expiresAt} <= now() then ${expiry} else ${securityLimits.expiresAt} end`,
    } }).returning();
  // Expired counters do not accumulate indefinitely. Cleanup is cheap and indexed.
  if (Math.random() < 0.02) await db.delete(securityLimits).where(sql`${securityLimits.expiresAt} < now()`);
  return { allowed: row.hits <= maximum, retryAfter: Math.max(1, Math.ceil((row.expiresAt.getTime() - Date.now()) / 1000)) };
}
