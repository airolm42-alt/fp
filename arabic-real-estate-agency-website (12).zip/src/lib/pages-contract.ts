import type { AboutSettings, BusinessSettings, SeoSettings, SiteSettings } from "@/lib/settings";

/** Public API contract. Type-only imports never bundle server/database code. */
export type PagesProperty = {
  id: string; title: string; slug: string; listingType: "sale" | "rent"; price: string | null;
  currency: string; location: string; area: string | null; bedrooms: number | null; bathrooms: number | null;
  mainImage: string; featured: boolean; typeName: string | null; description: string;
};
export type PagesPropertyDetails = PagesProperty & {
  address: string; floor: string; finishing: string; features: string[]; googleMapsUrl: string;
  whatsappMessage: string; images: { url: string; alt: string }[];
};
export type PagesService = { id: string; title: string; description: string; icon: string; image: string };
export type PagesArea = { id: string; name: string; description: string; image: string };
export type PagesConfig = {
  version: 1; backendOrigin: string; adminUrl: string; contactUrl: string; inquiriesEnabled: boolean;
  business: BusinessSettings; about: AboutSettings; site: SiteSettings;
  seo: Pick<SeoSettings, "siteTitle" | "siteDescription" | "keywords" | "ogImage">;
  services: PagesService[]; areas: PagesArea[]; types: { id: string; name: string; slug: string }[];
  locations: string[]; featured: PagesProperty[];
};
export type PagesList = { items: PagesProperty[]; total: number; page: number; pages: number };
export type PagesDetails = { property: PagesPropertyDetails; similar: PagesProperty[] };
