import { cache } from "react";
import { headers } from "next/headers";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { normalizeSiteOrigin, siteOriginKind } from "@/lib/site-origin";

export type SiteUrlInfo = {
  url: string;
  requestOrigin: string;
  configuredOrigin: string | null;
  source: "dashboard" | "environment" | "railway" | "request";
  kind: "preview" | "local" | "public";
};

/** Request-scoped deduplication. No global cache of visitor hostnames. */
export const getSiteUrlInfo = cache(async (): Promise<SiteUrlInfo> => {
  let requestOrigin = "http://localhost:3000";
  try {
    const h = await headers();
    const rawHost = (h.get("x-forwarded-host") ?? h.get("host") ?? "").split(",")[0].trim();
    const isLocal = /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/.test(rawHost);
    requestOrigin = normalizeSiteOrigin(`${isLocal ? "http" : "https"}://${rawHost}`) ?? requestOrigin;
  } catch {
    // Build-time metadata has no incoming request.
  }

  let configuredOrigin: string | null = null;
  let source: SiteUrlInfo["source"] = "request";
  try {
    const rows = await db.select().from(settings).where(eq(settings.key, "seo")).limit(1);
    const value = rows[0]?.value as { siteUrl?: string } | undefined;
    configuredOrigin = normalizeSiteOrigin(value?.siteUrl ?? "");
    if (configuredOrigin) source = "dashboard";
  } catch {
    // The public server can build before a fresh production database is initialized.
  }

  if (!configuredOrigin) {
    configuredOrigin = normalizeSiteOrigin(process.env.NEXT_PUBLIC_SITE_URL ?? "");
    if (configuredOrigin) source = "environment";
  }
  if (!configuredOrigin) {
    configuredOrigin = normalizeSiteOrigin(process.env.RAILWAY_PUBLIC_DOMAIN ?? "");
    if (configuredOrigin) source = "railway";
  }

  const url = configuredOrigin ?? requestOrigin;
  return { url, requestOrigin, configuredOrigin, source, kind: siteOriginKind(url) };
});

/** Base URL for canonical URLs, structured data, sitemap, and robots. */
export async function getSiteUrl(): Promise<string> {
  return (await getSiteUrlInfo()).url;
}

/** Backwards compatibility: resolution is already request-scoped. */
export function invalidateSiteUrlCache(): void {}
