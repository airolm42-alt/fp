import { db } from "@/db";
import { adminUsers, propertyTypes } from "@/db/schema";
import { sql } from "drizzle-orm";
import { hashPassword } from "@/lib/auth";

const DEFAULT_TYPES = [
  { name: "شقة", slug: "apartment" }, { name: "فيلا", slug: "villa" },
  { name: "دوبلكس", slug: "duplex" }, { name: "بنتهاوس", slug: "penthouse" },
  { name: "تاون هاوس", slug: "townhouse" }, { name: "ستوديو", slug: "studio" },
  { name: "شالية", slug: "chalet" }, { name: "محل تجاري", slug: "shop" },
  { name: "مكتب إداري", slug: "office" }, { name: "أرض", slug: "land" },
  { name: "مخزن", slug: "warehouse" },
];

/**
 * First-time provisioning only. There are no built-in admin passwords.
 * Existing accounts are never changed. Server credentials must be configured
 * explicitly before an empty production database can create its initial owner.
 */
export async function ensureAdminExists(): Promise<void> {
  await db.transaction(async (tx) => {
    // Serialize first-time provisioning across multiple server processes.
    await tx.execute(sql`select pg_advisory_xact_lock(73114282)`);
    const existing = await tx.select({ id: adminUsers.id }).from(adminUsers).limit(1);
    if (existing.length) return;

    const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
    const password = process.env.ADMIN_PASSWORD;
    if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !password || password.length < 12 || !/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
      throw new Error("First owner provisioning requires ADMIN_EMAIL and a strong ADMIN_PASSWORD in server environment variables");
    }
    await tx.insert(adminUsers).values({ email, passwordHash: await hashPassword(password), name: "المدير", isOwner: true });
    const types = await tx.select({ id: propertyTypes.id }).from(propertyTypes).limit(1);
    if (!types.length) await tx.insert(propertyTypes).values(DEFAULT_TYPES).onConflictDoNothing();
  });
}
