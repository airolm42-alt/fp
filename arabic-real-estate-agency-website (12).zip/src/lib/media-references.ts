import { inArray } from "drizzle-orm";
import { db } from "@/db";
import { mediaFiles } from "@/db/schema";
import { RequestError } from "@/lib/http";

/** Validate library URLs inside settings/service data before publishing them. */
export async function assertMediaReferences(value: unknown, database: Pick<typeof db, "select"> = db) {
  const urls = new Set<string>();
  function collect(input: unknown) {
    if (typeof input === "string" && input.startsWith("/uploads/")) urls.add(input);
    else if (Array.isArray(input)) input.forEach(collect);
    else if (input && typeof input === "object") Object.values(input).forEach(collect);
  }
  collect(value);
  if (!urls.size) return;
  const rows = await database.select({ url: mediaFiles.url }).from(mediaFiles).where(inArray(mediaFiles.url, [...urls]));
  if (rows.length !== urls.size) throw new RequestError("إحدى الصور لم تعد موجودة. اختر صورة من المكتبة أو ارفعها مرة أخرى.");
}
