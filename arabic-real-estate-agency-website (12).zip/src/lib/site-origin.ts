/** Shared, non-secret URL helpers. Safe to import from browser components. */
export function normalizeSiteOrigin(input: string): string | null {
  const value = input.trim();
  if (!value || value.length > 2048 || /\s/.test(value)) return null;
  const candidate = /^https?:\/\//i.test(value) ? value : `https://${value}`;
  try {
    const url = new URL(candidate);
    if (!['http:', 'https:'].includes(url.protocol)) return null;
    if (url.username || url.password || url.search || url.hash) return null;
    if (url.pathname !== '/' && url.pathname !== '') return null;
    const hostname = url.hostname.toLowerCase();
    const local = /^(localhost|127\.0\.0\.1|\[::1\])$/.test(hostname);
    if (!local) {
      if (!hostname.includes('.') || hostname.length > 253 || url.port) return null;
      if (!hostname.split('.').every((part) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(part))) return null;
    }
    return `${local ? url.protocol : 'https:'}//${url.host}`;
  } catch {
    return null;
  }
}

export function siteOriginKind(origin: string): 'preview' | 'local' | 'public' {
  try {
    const host = new URL(origin).hostname.toLowerCase();
    if (/^(localhost|127\.0\.0\.1|\[::1\])$/.test(host)) return 'local';
    if (host === 'e2b.app' || host.endsWith('.e2b.app') || host.endsWith('.e2b.dev')) return 'preview';
    return 'public';
  } catch {
    return 'local';
  }
}

/** An explicitly configured public domain is needed before listing production URLs.
 * This filters preview/local addresses; it does not verify DNS or deployment.
 */
export function configuredProductionOrigin(input: string): string | null {
  const origin = normalizeSiteOrigin(input);
  return origin && siteOriginKind(origin) === 'public' ? origin : null;
}

export const SITE_LINKS = [
  { label: 'الموقع الرئيسي', path: '/' },
  { label: 'دخول الإدارة', path: '/admin' },
  { label: 'فريق الإدارة', path: '/admin/team' },
  { label: 'العقارات', path: '/properties' },
  { label: 'من نحن', path: '/about' },
  { label: 'الخدمات', path: '/services' },
  { label: 'تواصل معنا', path: '/contact' },
  { label: 'خريطة الموقع', path: '/sitemap.xml' },
] as const;

export function siteLink(origin: string, path: string): string {
  return `${origin.replace(/\/$/, '')}${path === '/' ? '' : path}`;
}
