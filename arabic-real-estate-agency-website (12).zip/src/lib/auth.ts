import { SignJWT, jwtVerify } from "jose";
import { createHash } from "node:crypto";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";
import { cache } from "react";
import { db } from "@/db";
import { adminUsers, type AdminUser } from "@/db/schema";
import { eq } from "drizzle-orm";
import { isUuid } from "@/lib/input-safety";

export const SESSION_COOKIE = "aqarat_session";
const SESSION_DAYS = 7;
function getSecret() {
  const secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < 32) throw new Error("Configure a private AUTH_SECRET of at least 32 characters");
  return new TextEncoder().encode(secret);
}
function credentialsVersion(admin: Pick<AdminUser, "email" | "passwordHash" | "updatedAt">) {
  return createHash("sha256").update(`${admin.email}\n${admin.passwordHash}\n${admin.updatedAt.toISOString()}`).digest("hex");
}
export async function hashPassword(password: string) { return bcrypt.hash(password, 12); }
export async function verifyPassword(password: string, hash: string) { return bcrypt.compare(password, hash); }
export async function createSessionToken(admin: Pick<AdminUser, "id" | "email" | "passwordHash" | "updatedAt">) {
  return new SignJWT({ email: admin.email, role: "admin", cv: credentialsVersion(admin) })
    .setProtectedHeader({ alg: "HS256" }).setSubject(admin.id).setIssuedAt()
    .setExpirationTime(`${SESSION_DAYS}d`).sign(getSecret());
}
export async function getAdminFromToken(token: string): Promise<AdminUser | null> {
  try {
    const { payload } = await jwtVerify(token, getSecret(), { algorithms: ["HS256"] });
    if (payload.role !== "admin" || typeof payload.sub !== "string" || !isUuid(payload.sub)) return null;
    const [admin] = await db.select().from(adminUsers).where(eq(adminUsers.id, payload.sub)).limit(1);
    if (!admin || payload.cv !== credentialsVersion(admin)) return null;
    return admin;
  } catch { return null; }
}
export async function setSessionCookie(token: string) {
  const store = await cookies();
  const production = process.env.NODE_ENV === "production";
  store.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: production ? "none" : "lax", secure: production, maxAge: SESSION_DAYS * 86400, path: "/" });
}
export async function clearSessionCookie() {
  const store = await cookies();
  const production = process.env.NODE_ENV === "production";
  store.set(SESSION_COOKIE, "", { httpOnly: true, sameSite: production ? "none" : "lax", secure: production, maxAge: 0, path: "/" });
}
export const getCurrentAdmin = cache(async (): Promise<AdminUser | null> => {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  return token ? getAdminFromToken(token) : null;
});
export async function requireAdmin(options?: { allowPasswordChange?: boolean }): Promise<AdminUser | null> {
  const admin = await getCurrentAdmin();
  return admin && (!admin.mustChangePassword || options?.allowPasswordChange) ? admin : null;
}
