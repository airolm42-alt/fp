import { randomUUID } from "node:crypto";
import { and, eq, inArray, ne, sql } from "drizzle-orm";
import { db } from "@/db";
import { mediaFiles, properties, propertyImages, propertyTypes } from "@/db/schema";
import type { PropertyInput } from "@/lib/validators";
import { RequestError } from "@/lib/http";
import { isUuid } from "@/lib/input-safety";
import { slugify } from "@/lib/utils";

/** Transactional property + gallery writes. Shared lock with media deletion. */
export async function saveProperty(input: PropertyInput, id?: string) {
  if (id && !isUuid(id)) throw new RequestError("معرّف العقار غير صالح");
  return db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(7410032)`);
    let currentSlug = "";
    if (id) {
      const [current] = await tx.select({ slug: properties.slug }).from(properties).where(eq(properties.id, id)).limit(1).for("update");
      if (!current) throw new RequestError("العقار غير موجود", 404);
      currentSlug = current.slug;
    }
    if (input.typeId) {
      const [type] = await tx.select({ id: propertyTypes.id }).from(propertyTypes).where(eq(propertyTypes.id, input.typeId)).limit(1);
      if (!type) throw new RequestError("نوع العقار غير موجود");
    }
    const images = input.images.filter((img, index, list) => list.findIndex((x) => x.url === img.url) === index);
    const mainImage = input.mainImage || images[0]?.url || "";
    const urls = [...new Set([mainImage, ...images.map((image) => image.url)].filter(Boolean))];
    if (urls.length) {
      const existing = await tx.select({ url: mediaFiles.url }).from(mediaFiles).where(inArray(mediaFiles.url, urls));
      if (existing.length !== urls.length) throw new RequestError("إحدى الصور غير موجودة في المكتبة؛ ارفعها أو اختر صورة موجودة");
    }
    const base = input.slug ? slugify(input.slug) : currentSlug || slugify(input.title) || `property-${randomUUID().slice(0, 8)}`;
    let slug = base;
    const duplicate = await tx.select({ id: properties.id }).from(properties).where(id ? and(eq(properties.slug, slug), ne(properties.id, id)) : eq(properties.slug, slug)).limit(1);
    if (duplicate.length) {
      if (input.slug) throw new RequestError("رابط العقار مستخدم؛ اختر رابطًا آخر", 409);
      slug = `${base}-${randomUUID().slice(0, 8)}`;
    }
    const values = {
      title: input.title, slug, description: input.description, typeId: input.typeId || null,
      listingType: input.listingType, price: input.price === "" || input.price == null ? null : input.price.toFixed(2),
      currency: input.currency, location: input.location, address: input.address,
      area: input.area === "" || input.area == null ? null : input.area.toFixed(2),
      bedrooms: input.bedrooms === "" || input.bedrooms == null ? null : input.bedrooms,
      bathrooms: input.bathrooms === "" || input.bathrooms == null ? null : input.bathrooms,
      floor: input.floor, finishing: input.finishing, features: [...new Set(input.features)], mainImage,
      googleMapsUrl: input.googleMapsUrl, whatsappMessage: input.whatsappMessage,
      status: input.status, featured: input.featured, metaTitle: input.metaTitle, metaDescription: input.metaDescription,
      updatedAt: new Date(),
    };
    const [saved] = id
      ? await tx.update(properties).set(values).where(eq(properties.id, id)).returning({ id: properties.id, slug: properties.slug })
      : await tx.insert(properties).values(values).returning({ id: properties.id, slug: properties.slug });
    if (id) await tx.delete(propertyImages).where(eq(propertyImages.propertyId, id));
    if (images.length) await tx.insert(propertyImages).values(images.map((image, sort) => ({ propertyId: saved.id, url: image.url, alt: image.alt || input.title, sort })));
    return saved;
  });
}
