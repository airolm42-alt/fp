import { z } from "zod";

export const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
export function isUuid(input: string): boolean { return uuidPattern.test(input); }
export function pageNumber(input: unknown): number {
  const value = Number(input);
  return Number.isSafeInteger(value) && value > 0 ? Math.min(value, 10000) : 1;
}
export function decimalFilter(input: string | undefined, maximum = 9_999_999_999_999): string | null {
  if (!input || !/^\d{1,13}(?:\.\d{1,2})?$/.test(input)) return null;
  const number = Number(input);
  return Number.isFinite(number) && number >= 0 && number <= maximum ? String(number) : null;
}
export function likePattern(input: string, maxLength = 200): string {
  return `%${input.trim().slice(0, maxLength).replace(/[\\%_]/g, "\\$&")}%`;
}
export function safeJsonLd(value: unknown): string {
  return JSON.stringify(value).replace(/</g, "\\u003c").replace(/>/g, "\\u003e").replace(/&/g, "\\u0026").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
}
export function publicHttpsUrl(input: string): boolean {
  try {
    const url = new URL(input);
    return url.protocol === "https:" && !url.username && !url.password && !url.port &&
      url.hostname.includes(".") && !/^(?:localhost|127\.|10\.|192\.168\.|169\.254\.|172\.(?:1[6-9]|2\d|3[01])\.)/.test(url.hostname) && !url.hostname.endsWith(".local");
  } catch { return false; }
}
export const optionalHttpsUrl = z.string().trim().max(2048).refine((v) => !v || publicHttpsUrl(v), "استخدم رابط HTTPS صالحًا دون بيانات دخول").default("");
export const imagePathSchema = z.string().trim().max(500).refine((v) => !v || /^\/(?:uploads|images)\/[\w/-]+\.(?:webp|jpe?g|png|avif)$/i.test(v) && !v.includes(".."), "اختر صورة مرفوعة من مكتبة الموقع").default("");
export const optionalPhoneSchema = z.string().trim().max(30).refine((v) => !v || /^\+?[0-9٠-٩۰-۹ ()-]{6,30}$/.test(v), "رقم الهاتف غير صالح").default("");
export const passwordSchema = z.string().min(12, "كلمة المرور 12 حرفًا على الأقل").max(72, "الحد الأقصى 72 حرفًا")
  .refine((v) => new TextEncoder().encode(v).length <= 72, "كلمة المرور طويلة جدًا")
  .regex(/[A-Za-z]/, "أضف حرفًا لاتينيًا إلى كلمة المرور").regex(/[0-9]/, "أضف رقمًا إلى كلمة المرور");
