import { cache } from "react";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { assertMediaReferences } from "@/lib/media-references";
import { z } from "zod";
import { imagePathSchema, optionalHttpsUrl, optionalPhoneSchema } from "@/lib/input-safety";

const text = (max: number) => z.string().trim().max(max).default("");
export const businessSettingsSchema = z.object({
  businessName: text(160), logo: imagePathSchema, cover: imagePathSchema,
  phone: optionalPhoneSchema, whatsapp: optionalPhoneSchema,
  email: z.union([z.string().trim().email("بريد إلكتروني غير صالح").max(200), z.literal("")]).default(""),
  address: text(500), googleMapsUrl: optionalHttpsUrl, googleReviewsUrl: optionalHttpsUrl,
  workingHours: text(300), facebook: optionalHttpsUrl, instagram: optionalHttpsUrl, tiktok: optionalHttpsUrl, youtube: optionalHttpsUrl,
});
export const aboutSettingsSchema = z.object({ title: text(200), description: text(10000), mission: text(3000), vision: text(3000), values: z.array(z.string().trim().min(1).max(200)).max(30).default([]), images: z.array(imagePathSchema.refine(Boolean)).max(20).default([]) });
export const siteSettingsSchema = z.object({ heroTitle: text(250), heroSubtitle: text(1000), heroImage: imagePathSchema, footerAbout: text(1000), primaryColor: z.string().refine((v) => !v || /^#[a-f0-9]{6}$/i.test(v), "لون غير صالح").default("") });
export const seoSettingsSchema = z.object({
  siteTitle: text(200), siteDescription: text(500), ogImage: imagePathSchema, keywords: text(1000), siteUrl: text(2048),
  googleVerification: z.string().trim().max(512).refine((v) => !v || /^[a-zA-Z0-9_-]+$/.test(v), "كود توثيق Google غير صالح").default(""),
  googleAnalyticsId: z.string().trim().max(40).refine((v) => !v || /^G-[A-Z0-9]{4,32}$/.test(v), "معرّف Analytics غير صالح").default(""),
});
export type BusinessSettings = z.infer<typeof businessSettingsSchema>;
export type AboutSettings = z.infer<typeof aboutSettingsSchema>;
export type SiteSettings = z.infer<typeof siteSettingsSchema>;
export type SeoSettings = z.infer<typeof seoSettingsSchema>;
export const DEFAULT_BUSINESS: BusinessSettings = businessSettingsSchema.parse({});
export const DEFAULT_ABOUT: AboutSettings = aboutSettingsSchema.parse({});
export const DEFAULT_SITE: SiteSettings = siteSettingsSchema.parse({});
export const DEFAULT_SEO: SeoSettings = seoSettingsSchema.parse({});
async function readSetting<T>(key: string, schema: z.ZodType<T>, fallback: T): Promise<T> {
  try {
    const [row] = await db.select().from(settings).where(eq(settings.key, key)).limit(1);
    if (!row) return fallback;
    const parsed = schema.safeParse(row.value);
    return parsed.success ? parsed.data : fallback;
  } catch { return fallback; }
}
export const getBusinessSettings = cache(async () => readSetting<BusinessSettings>("business", businessSettingsSchema, DEFAULT_BUSINESS));
export const getAboutSettings = cache(async () => readSetting<AboutSettings>("about", aboutSettingsSchema, DEFAULT_ABOUT));
export const getSiteSettings = cache(async () => readSetting<SiteSettings>("site", siteSettingsSchema, DEFAULT_SITE));
export const getSeoSettings = cache(async () => readSetting<SeoSettings>("seo", seoSettingsSchema, DEFAULT_SEO));
export const getAllSettings = cache(async () => {
  const [business, about, site, seo] = await Promise.all([getBusinessSettings(), getAboutSettings(), getSiteSettings(), getSeoSettings()]);
  return { business, about, site, seo };
});
export async function saveSetting(key: string, value: unknown) {
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(7410032)`);
    await assertMediaReferences(value, tx);
    await tx.insert(settings).values({ key, value, updatedAt: new Date() }).onConflictDoUpdate({ target: settings.key, set: { value, updatedAt: new Date() } });
  });
}
