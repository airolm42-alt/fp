import { NextRequest, NextResponse } from "next/server";
import { normalizeSiteOrigin } from "@/lib/site-origin";
import { RequestError } from "@/lib/http";

/** Only public origins; never a secret, wildcard, username, password, or path. */
export function backendOrigin(req: NextRequest): string {
  const configured = normalizeSiteOrigin(process.env.PAGES_BACKEND_PUBLIC_ORIGIN ?? "");
  if (configured) return configured;
  const host = (req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? req.nextUrl.host).split(",")[0].trim();
  const local = /^(localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/.test(host);
  const origin = normalizeSiteOrigin(`${local ? "http" : "https"}://${host}`);
  if (!origin) throw new RequestError("عنوان الخادم غير صالح", 400);
  return origin;
}
export function allowedPagesWrite(req: NextRequest): boolean {
  const raw = req.headers.get("origin");
  if (!raw || raw === "null") return false;
  const origin = normalizeSiteOrigin(raw);
  if (!origin || origin !== raw) return false;
  if (origin === backendOrigin(req)) return true;
  return (process.env.PAGES_ALLOWED_ORIGINS ?? "").split(",").map((value) => normalizeSiteOrigin(value)).filter(Boolean).includes(origin);
}
export function pagesHeaders(origin?: string): Headers {
  const headers = new Headers({
    "Access-Control-Allow-Origin": origin || "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "600",
    "Cache-Control": "no-store",
    "Vary": "Origin",
    "X-Content-Type-Options": "nosniff",
  });
  return headers;
}
export function publicPagesJson(body: unknown, status = 200) {
  return NextResponse.json(body, { status, headers: pagesHeaders() });
}

/** Keep API responses portable: images are on the backend, not on github.io. */
export function absoluteMedia<T>(value: T, origin: string): T {
  if (typeof value === "string") return (value.startsWith("/uploads/") || value.startsWith("/images/") ? `${origin}${value}` : value) as T;
  if (value instanceof Date) return value.toISOString() as T;
  if (Array.isArray(value)) return value.map((entry) => absoluteMedia(entry, origin)) as T;
  if (value && typeof value === "object") return Object.fromEntries(Object.entries(value).map(([key, entry]) => [key, absoluteMedia(entry, origin)])) as T;
  return value;
}
