"use client";

import {
  forwardRef,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type TextareaHTMLAttributes,
  type SelectHTMLAttributes,
  type ReactNode,
  useEffect,
  useState,
  useId,
  Children,
  cloneElement,
  isValidElement,
  type ReactElement,
} from "react";
import { Loader2, X, CheckCircle2, AlertCircle, Inbox } from "lucide-react";
import { cn } from "@/lib/utils";
import { createPortal } from "react-dom";
import { useDialog } from "@/components/use-dialog";

/* --------------------------------- Button -------------------------------- */
type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "gold" | "outline" | "ghost" | "danger" | "dark";
  size?: "sm" | "md" | "lg" | "icon";
  loading?: boolean;
};

export const buttonStyles = {
  base: "inline-flex items-center justify-center gap-2 rounded-xl font-bold transition-all duration-200 outline-none focus-visible:ring-2 focus-visible:ring-brand-500/40 disabled:opacity-50 disabled:pointer-events-none active:scale-[0.98] cursor-pointer",
  variants: {
    primary: "bg-brand-700 text-white hover:bg-brand-800 shadow-sm",
    gold: "bg-gold-500 text-brand-950 hover:bg-gold-400 shadow-sm",
    outline: "border border-stone-300 bg-white text-ink hover:border-brand-500 hover:text-brand-700",
    ghost: "text-ink-soft hover:bg-stone-100 hover:text-ink",
    danger: "bg-red-600 text-white hover:bg-red-700",
    dark: "bg-brand-950 text-white hover:bg-brand-900",
  },
  sizes: {
    sm: "px-3 py-1.5 text-xs",
    md: "px-4 py-2.5 text-sm",
    lg: "px-6 py-3.5 text-base",
    icon: "p-2 text-sm",
  },
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { className, variant = "primary", size = "md", loading, children, disabled, ...props },
  ref,
) {
  return (
    <button
      ref={ref}
      className={cn(buttonStyles.base, buttonStyles.variants[variant], buttonStyles.sizes[size], className)}
      disabled={disabled || loading}
      {...props}
    >
      {loading && <Loader2 className="h-4 w-4 animate-spin" />}
      {children}
    </button>
  );
});

/* ---------------------------------- Inputs -------------------------------- */
export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(
  function Input({ className, ...props }, ref) {
    return <input ref={ref} className={cn("field", className)} {...props} />;
  },
);

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(
  function Textarea({ className, ...props }, ref) {
    return <textarea ref={ref} className={cn("field min-h-28 leading-relaxed", className)} {...props} />;
  },
);

export const Select = forwardRef<HTMLSelectElement, SelectHTMLAttributes<HTMLSelectElement>>(
  function Select({ className, children, ...props }, ref) {
    return (
      <select ref={ref} className={cn("field appearance-none bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2216%22 height=%2216%22 viewBox=%220 0 24 24%22 fill=%22none%22 stroke=%22%236b7280%22 stroke-width=%222%22%3E%3Cpath d=%22m6 9 6 6 6-6%22/%3E%3C/svg%3E')] bg-[length:16px] bg-[left_0.75rem_center] bg-no-repeat pl-9 cursor-pointer", className)} {...props}>
        {children}
      </select>
    );
  },
);

export function Label({ children, className, htmlFor }: { children: ReactNode; className?: string; htmlFor?: string }) {
  return (
    <label htmlFor={htmlFor} className={cn("field-label", className)}>
      {children}
    </label>
  );
}

export function Field({ label, children, hint, error }: { label?: string; children: ReactNode; hint?: string; error?: string }) {
  const generatedId = useId();
  function findControl(nodes: ReactNode): ReactElement<Record<string, unknown>> | null {
    for (const node of Children.toArray(nodes)) {
      if (!isValidElement(node)) continue;
      const element = node as ReactElement<Record<string, unknown>>;
      if (node.type === Input || node.type === Textarea || node.type === Select || typeof node.type === "string" && ["input", "select", "textarea"].includes(node.type)) return element;
      const nested = findControl(element.props.children as ReactNode);
      if (nested) return nested;
    }
    return null;
  }
  const control = findControl(children);
  const fieldId = typeof control?.props.id === "string" ? control.props.id : generatedId;
  function associate(nodes: ReactNode): ReactNode {
    return Children.map(nodes, (node) => {
      if (!isValidElement(node)) return node;
      const element = node as ReactElement<Record<string, unknown>>;
      if (node === control || element.type === control?.type && element.props === control.props) return cloneElement(element, { id: fieldId, "aria-describedby": hint || error ? `${generatedId}-hint` : undefined, "aria-invalid": error ? true : undefined });
      return element.props.children ? cloneElement(element, {}, associate(element.props.children as ReactNode)) : node;
    });
  }
  const content = associate(children);
  return <div>{label && (control ? <Label htmlFor={fieldId}>{label}</Label> : <div className="field-label">{label}</div>)}{content}
    {hint && !error && <p id={`${generatedId}-hint`} className="mt-1 text-xs text-stone-400">{hint}</p>}
    {error && <p id={`${generatedId}-hint`} role="alert" className="mt-1 text-xs font-semibold text-red-600">{error}</p>}
  </div>;
}

/* ---------------------------------- Badge --------------------------------- */
export function Badge({
  children,
  tone = "stone",
  className,
}: {
  children: ReactNode;
  tone?: "stone" | "green" | "gold" | "red" | "blue" | "brand";
  className?: string;
}) {
  const tones = {
    stone: "bg-stone-100 text-stone-600",
    green: "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-600/20",
    gold: "bg-gold-100 text-gold-800 ring-1 ring-gold-600/20",
    red: "bg-red-50 text-red-700 ring-1 ring-red-600/20",
    blue: "bg-sky-50 text-sky-700 ring-1 ring-sky-600/20",
    brand: "bg-brand-50 text-brand-700 ring-1 ring-brand-600/20",
  };
  return (
    <span className={cn("inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-bold", tones[tone], className)}>
      {children}
    </span>
  );
}

/* ---------------------------------- Card ---------------------------------- */
export function Card({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("rounded-2xl border border-stone-200 bg-white shadow-card", className)}>{children}</div>;
}

/* ---------------------------------- Switch -------------------------------- */
export function Switch({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label?: string }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="inline-flex cursor-pointer items-center gap-2.5"
    >
      <span
        className={cn(
          "relative h-6 w-11 rounded-full transition-colors duration-200",
          checked ? "bg-brand-600" : "bg-stone-300",
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all duration-200",
            checked ? "right-0.5" : "right-[1.375rem]",
          )}
        />
      </span>
      {label && <span className="text-sm font-semibold text-ink">{label}</span>}
    </button>
  );
}

/* -------------------------------- Empty state ------------------------------ */
export function EmptyState({
  title,
  description,
  action,
  icon,
}: {
  title: string;
  description?: string;
  action?: ReactNode;
  icon?: ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border-2 border-dashed border-stone-200 bg-stone-50/60 px-6 py-14 text-center">
      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-stone-400 shadow-sm">
        {icon ?? <Inbox className="h-7 w-7" />}
      </div>
      <p className="text-base font-bold text-ink">{title}</p>
      {description && <p className="mt-1.5 max-w-md text-sm leading-relaxed text-stone-500">{description}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

/* -------------------------------- Form alert ------------------------------- */
export function FormAlert({ type, message }: { type: "success" | "error"; message: string }) {
  return (
    <div
      className={cn(
        "flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-semibold",
        type === "success" ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-600/20" : "bg-red-50 text-red-700 ring-1 ring-red-600/20",
      )}
    >
      {type === "success" ? <CheckCircle2 className="h-4 w-4 shrink-0" /> : <AlertCircle className="h-4 w-4 shrink-0" />}
      {message}
    </div>
  );
}

/* ---------------------------------- Toast ---------------------------------- */
type ToastItem = { id: number; type: "success" | "error"; message: string };

export function toast(message: string, type: "success" | "error" = "success") {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("app-toast", { detail: { message, type } }));
  }
}

export function Toaster() {
  const [items, setItems] = useState<ToastItem[]>([]);

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail as { message: string; type: "success" | "error" };
      const id = Date.now() + Math.random();
      setItems((prev) => [...prev, { id, ...detail }]);
      setTimeout(() => setItems((prev) => prev.filter((t) => t.id !== id)), 4000);
    };
    window.addEventListener("app-toast", handler);
    return () => window.removeEventListener("app-toast", handler);
  }, []);

  return (
    <div className="pointer-events-none fixed bottom-5 left-1/2 z-[100] flex w-full max-w-sm -translate-x-1/2 flex-col gap-2 px-4">
      {items.map((t) => (
        <div
          key={t.id}
          className={cn(
            "pointer-events-auto flex items-center gap-2.5 rounded-xl px-4 py-3 text-sm font-bold text-white shadow-lg animate-rise",
            t.type === "success" ? "bg-brand-700" : "bg-red-600",
          )}
        >
          {t.type === "success" ? <CheckCircle2 className="h-4.5 w-4.5 shrink-0" /> : <AlertCircle className="h-4.5 w-4.5 shrink-0" />}
          <span className="flex-1">{t.message}</span>
          <button
            onClick={() => setItems((prev) => prev.filter((x) => x.id !== t.id))}
            className="cursor-pointer opacity-70 hover:opacity-100"
            aria-label="إغلاق"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ))}
    </div>
  );
}

/* -------------------------------- Modal -------------------------------- */
export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  const titleId = useId();
  const dialog = useDialog(open, onClose);

  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-[90] flex items-end justify-center sm:items-center">
      <div className="absolute inset-0 bg-brand-950/50 backdrop-blur-sm" onClick={onClose} />
      <div
        ref={dialog} role="dialog" aria-modal="true" aria-labelledby={titleId}
        className={cn(
          "relative flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-2xl bg-white shadow-2xl animate-rise sm:rounded-2xl",
          wide ? "sm:max-w-3xl" : "sm:max-w-lg",
        )}
      >
        <div className="flex items-center justify-between border-b border-stone-100 px-5 py-4">
          <h3 id={titleId} className="text-base font-extrabold text-ink">{title}</h3>
          <button onClick={onClose} className="cursor-pointer rounded-lg p-1.5 text-stone-400 hover:bg-stone-100 hover:text-ink" aria-label="إغلاق">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="overflow-y-auto px-5 py-5">{children}</div>
      </div>
    </div>, document.body
  );
}
