"use client";

import { useState } from "react";
import { Plus, X } from "lucide-react";
import { Button, Card, Field, Input, Textarea, toast } from "@/components/ui";
import { ImageUpload, type UploadedImage } from "@/components/admin/image-upload";
import type { BusinessSettings, AboutSettings, SiteSettings, SeoSettings } from "@/lib/settings";


/* ------------------------------- Shared save ------------------------------ */
async function saveSection(section: string, data: unknown): Promise<boolean> {
  try {
    const res = await fetch("/api/admin/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ section, data }),
    });
    if (!res.ok) {
      toast("فشل حفظ الإعدادات", "error");
      return false;
    }
    toast("تم حفظ الإعدادات بنجاح — سيظهر التحديث على الموقع فورًا");
    return true;
  } catch {
    toast("حدث خطأ في الاتصال", "error");
    return false;
  }
}

function SaveBar({ saving, onSave }: { saving: boolean; onSave: () => void }) {
  return (
    <div className="sticky bottom-4 z-10 mt-6">
      <Button onClick={onSave} loading={saving} size="lg" className="w-full shadow-lg">
        حفظ التغييرات
      </Button>
    </div>
  );
}

/* ------------------------------ Business form ----------------------------- */
export function BusinessForm({ initial }: { initial: BusinessSettings }) {
  const [form, setForm] = useState<BusinessSettings>(initial);
  const [saving, setSaving] = useState(false);
  const set = <K extends keyof BusinessSettings>(k: K, v: BusinessSettings[K]) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="space-y-6 lg:col-span-2">
        <Card className="p-5 sm:p-6">
          <h2 className="mb-5 text-base font-extrabold text-ink">بيانات النشاط التجاري</h2>
          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="اسم النشاط التجاري">
                <Input value={form.businessName} onChange={(e) => set("businessName", e.target.value)} placeholder="مثال: شركة النيل للعقارات" />
              </Field>
              <Field label="البريد الإلكتروني">
                <Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="info@example.com" dir="ltr" className="text-left" />
              </Field>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="رقم الهاتف">
                <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="01xxxxxxxxx" dir="ltr" className="text-left" />
              </Field>
              <Field label="رقم الواتساب" hint="بصيغة دولية، مثال: 2010xxxxxxxx">
                <Input value={form.whatsapp} onChange={(e) => set("whatsapp", e.target.value)} placeholder="2010xxxxxxxx" dir="ltr" className="text-left" />
              </Field>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="العنوان">
                <Input value={form.address} onChange={(e) => set("address", e.target.value)} placeholder="المحافظة، المدينة، الشارع" />
              </Field>
              <Field label="مواعيد العمل">
                <Input value={form.workingHours} onChange={(e) => set("workingHours", e.target.value)} placeholder="مثال: يوميًا من 10 صباحًا حتى 10 مساءً" />
              </Field>
            </div>
            <Field label="رابط الموقع على خرائط Google">
              <Input value={form.googleMapsUrl} onChange={(e) => set("googleMapsUrl", e.target.value)} placeholder="https://maps.google.com/..." dir="ltr" className="text-left" />
            </Field>
          </div>
        </Card>

        <Card className="p-5 sm:p-6">
          <h2 className="mb-5 text-base font-extrabold text-ink">روابط التواصل الاجتماعي</h2>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="فيسبوك">
              <Input value={form.facebook} onChange={(e) => set("facebook", e.target.value)} placeholder="https://facebook.com/..." dir="ltr" className="text-left" />
            </Field>
            <Field label="إنستجرام">
              <Input value={form.instagram} onChange={(e) => set("instagram", e.target.value)} placeholder="https://instagram.com/..." dir="ltr" className="text-left" />
            </Field>
            <Field label="تيك توك">
              <Input value={form.tiktok} onChange={(e) => set("tiktok", e.target.value)} placeholder="https://tiktok.com/@..." dir="ltr" className="text-left" />
            </Field>
            <Field label="يوتيوب">
              <Input value={form.youtube} onChange={(e) => set("youtube", e.target.value)} placeholder="https://youtube.com/..." dir="ltr" className="text-left" />
            </Field>
          </div>
        </Card>
      </div>

      <div className="space-y-6">
        <Card className="p-5 sm:p-6">
          <h2 className="mb-4 text-base font-extrabold text-ink">الشعار (Logo)</h2>
          <ImageUpload
            value={form.logo ? [{ url: form.logo }] : []}
            onChange={(imgs: UploadedImage[]) => set("logo", imgs[0]?.url ?? "")}
            multiple={false}
            label="ارفع شعار النشاط"
            aspect="aspect-square"
          />
        </Card>
        <Card className="p-5 sm:p-6">
          <h2 className="mb-4 text-base font-extrabold text-ink">صورة الغلاف</h2>
          <ImageUpload
            value={form.cover ? [{ url: form.cover }] : []}
            onChange={(imgs: UploadedImage[]) => set("cover", imgs[0]?.url ?? "")}
            multiple={false}
            label="ارفع صورة الغلاف"
          />
        </Card>
      </div>

      <div className="lg:col-span-3">
        <SaveBar saving={saving} onSave={async () => { setSaving(true); await saveSection("business", form); setSaving(false); }} />
      </div>
    </div>
  );
}

/* -------------------------------- About form ------------------------------ */
export function AboutForm({ initial }: { initial: AboutSettings }) {
  const [form, setForm] = useState<AboutSettings>(initial);
  const [valueInput, setValueInput] = useState("");
  const [saving, setSaving] = useState(false);
  const set = <K extends keyof AboutSettings>(k: K, v: AboutSettings[K]) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      <div className="space-y-6 lg:col-span-2">
        <Card className="p-5 sm:p-6">
          <h2 className="mb-5 text-base font-extrabold text-ink">محتوى صفحة «من نحن»</h2>
          <div className="space-y-4">
            <Field label="العنوان الرئيسي">
              <Input value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="مثال: من نحن" />
            </Field>
            <Field label="نبذة عن النشاط">
              <Textarea rows={7} value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="اكتب نبذة تعريفية عن شركتك وخدماتها..." />
            </Field>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="رسالتنا">
                <Textarea rows={4} value={form.mission} onChange={(e) => set("mission", e.target.value)} placeholder="رسالة الشركة" />
              </Field>
              <Field label="رؤيتنا">
                <Textarea rows={4} value={form.vision} onChange={(e) => set("vision", e.target.value)} placeholder="رؤية الشركة" />
              </Field>
            </div>
            <Field label="قيمنا" hint="اكتب القيمة ثم اضغط إضافة">
              <div className="flex gap-2">
                <Input
                  value={valueInput}
                  onChange={(e) => setValueInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      const v = valueInput.trim();
                      if (v && !form.values.includes(v)) {
                        set("values", [...form.values, v]);
                        setValueInput("");
                      }
                    }
                  }}
                  placeholder="مثال: الشفافية، الالتزام، المصداقية..."
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    const v = valueInput.trim();
                    if (v && !form.values.includes(v)) {
                      set("values", [...form.values, v]);
                      setValueInput("");
                    }
                  }}
                >
                  <Plus className="h-4 w-4" /> إضافة
                </Button>
              </div>
              {form.values.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {form.values.map((v) => (
                    <span key={v} className="inline-flex items-center gap-1.5 rounded-full bg-gold-100 py-1 pe-2 ps-3 text-xs font-bold text-gold-800 ring-1 ring-gold-600/20">
                      {v}
                      <button type="button" onClick={() => set("values", form.values.filter((x) => x !== v))} className="cursor-pointer text-gold-600 hover:text-red-600" aria-label={`حذف ${v}`}>
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </Field>
          </div>
        </Card>
      </div>

      <div>
        <Card className="p-5 sm:p-6">
          <h2 className="mb-4 text-base font-extrabold text-ink">صور المكتب</h2>
          <p className="mb-4 text-xs text-stone-500">ارفع صورًا حقيقية للمكتب أو فريق العمل — تظهر في صفحة «من نحن»</p>
          <ImageUpload value={form.images.map((url) => ({ url }))} onChange={(imgs) => set("images", imgs.map((i) => i.url))} />
        </Card>
      </div>

      <div className="lg:col-span-3">
        <SaveBar saving={saving} onSave={async () => { setSaving(true); await saveSection("about", form); setSaving(false); }} />
      </div>
    </div>
  );
}

/* ----------------------------- Site settings form ---------------------------- */
export function SiteSettingsForm({ initial }: { initial: SiteSettings }) {
  const [form, setForm] = useState<SiteSettings>(initial);
  const [saving, setSaving] = useState(false);
  const set = <K extends keyof SiteSettings>(k: K, v: SiteSettings[K]) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <div className="max-w-3xl space-y-6">
      <Card className="p-5 sm:p-6">
        <h2 className="mb-5 text-base font-extrabold text-ink">قسم الواجهة الرئيسية (Hero)</h2>
        <div className="space-y-4">
          <Field label="العنوان الرئيسي" hint="عند تركه فارغًا يُستخدم عنوان افتراضي عام">
            <Input value={form.heroTitle} onChange={(e) => set("heroTitle", e.target.value)} placeholder="مثال: اعثر على عقارك المثالي" />
          </Field>
          <Field label="الوصف المختصر">
            <Textarea rows={3} value={form.heroSubtitle} onChange={(e) => set("heroSubtitle", e.target.value)} placeholder="جملة تعريفية قصيرة تظهر أسفل العنوان في الصفحة الرئيسية" />
          </Field>
          <Field label="نبذة مختصرة (تظهر في الفوتر)">
            <Textarea rows={3} value={form.footerAbout} onChange={(e) => set("footerAbout", e.target.value)} placeholder="سطر أو سطران عن النشاط يظهران أسفل الموقع" />
          </Field>
        </div>
      </Card>

      <Card className="p-5 sm:p-6">
        <h2 className="mb-4 text-base font-extrabold text-ink">صورة الواجهة الرئيسية</h2>
        <p className="mb-4 text-xs text-stone-500">عند عدم رفع صورة تظهر خلفية تصميمية أنيقة تلقائيًا</p>
        <ImageUpload
          value={form.heroImage ? [{ url: form.heroImage }] : []}
          onChange={(imgs) => set("heroImage", imgs[0]?.url ?? "")}
          multiple={false}
          label="ارفع صورة الواجهة"
          aspect="aspect-video"
        />
      </Card>

      <SaveBar saving={saving} onSave={async () => { setSaving(true); await saveSection("site", form); setSaving(false); }} />
    </div>
  );
}

/* --------------------------------- SEO form -------------------------------- */
export function SeoForm({ initial }: { initial: SeoSettings }) {
  const [form, setForm] = useState<SeoSettings>(initial);
  const [saving, setSaving] = useState(false);
  const set = <K extends keyof SeoSettings>(k: K, v: SeoSettings[K]) => setForm((f) => ({ ...f, [k]: v }));

  return (
    <div className="max-w-3xl space-y-6">
      <Card className="p-5 sm:p-6">
        <h2 className="mb-5 text-base font-extrabold text-ink">إعدادات SEO العامة</h2>
        <div className="space-y-4">
          <Field label="عنوان الموقع" hint="يظهر في تبويب المتصفح ونتائج البحث">
            <Input value={form.siteTitle} onChange={(e) => set("siteTitle", e.target.value)} placeholder="مثال: شركة النيل للعقارات" />
          </Field>
          <Field label="وصف الموقع (160 حرفًا تقريبًا)">
            <Textarea rows={3} value={form.siteDescription} onChange={(e) => set("siteDescription", e.target.value)} placeholder="وصف مختصر وواضح لنشاطك يظهر في نتائج بحث Google" />
          </Field>
          <Field label="الكلمات المفتاحية" hint="افصل بين الكلمات بفاصلة — استخدم كلمات حقيقية مرتبطة بنشاطك فقط">
            <Input value={form.keywords} onChange={(e) => set("keywords", e.target.value)} placeholder="عقارات، شقق للبيع، عقارات القاهرة" />
          </Field>
        </div>
      </Card>

      <Card className="p-5 sm:p-6">
        <h2 className="mb-2 text-base font-extrabold text-ink">الظهور في Google</h2>
        <p className="mb-5 text-xs leading-relaxed text-stone-500">
          لإدراج موقعك في نتائج بحث Google: افتح Google Search Console، اختر طريقة التوثيق
          <span className="font-black"> HTML tag</span>، وانسخ قيمة <span dir="ltr" className="font-mono">content</span> والصقها هنا، ثم اضغط حفظ وبعدها «تحقق» في Google.
        </p>
        <div className="space-y-4">
          <Field label="كود توثيق Google Search Console" hint="القيمة فقط وليس الوسم كاملًا">
            <Input
              value={form.googleVerification}
              onChange={(e) => set("googleVerification", e.target.value)}
              placeholder="google-site-verification code"
              dir="ltr"
              className="text-left"
            />
          </Field>
          <Field label="معرّف Google Analytics (اختياري)" hint="لمتابعة عدد الزوار ومصادرهم">
            <Input
              value={form.googleAnalyticsId}
              onChange={(e) => set("googleAnalyticsId", e.target.value)}
              placeholder="G-XXXXXXXXXX"
              dir="ltr"
              className="text-left"
            />
          </Field>
        </div>
        <div className="mt-4 rounded-xl bg-brand-50 p-3.5 text-xs leading-relaxed font-semibold text-brand-800">
          خريطة الموقع جاهزة تلقائيًا على <span dir="ltr" className="font-mono">/sitemap.xml</span> — أرسل هذا الرابط داخل Search Console لتسريع الفهرسة.
        </div>
      </Card>

      <Card className="p-5 sm:p-6">
        <h2 className="mb-4 text-base font-extrabold text-ink">الصورة الافتراضية للمشاركة (Open Graph)</h2>
        <p className="mb-4 text-xs text-stone-500">تظهر عند مشاركة روابط الموقع على مواقع التواصل</p>
        <ImageUpload
          value={form.ogImage ? [{ url: form.ogImage }] : []}
          onChange={(imgs) => set("ogImage", imgs[0]?.url ?? "")}
          multiple={false}
          label="ارفع صورة المشاركة"
          aspect="aspect-video"
        />
      </Card>

      <SaveBar saving={saving} onSave={async () => { setSaving(true); await saveSection("seo", form); setSaving(false); }} />
    </div>
  );
}

/* ------------------------------- Reviews form ------------------------------ */
export function ReviewsForm({ initial }: { initial: BusinessSettings }) {
  const [form, setForm] = useState<BusinessSettings>(initial);
  const [saving, setSaving] = useState(false);

  return (
    <div className="max-w-3xl space-y-6">
      <Card className="p-5 sm:p-6">
        <h2 className="mb-2 text-base font-extrabold text-ink">تقييمات Google</h2>
        <p className="mb-5 text-xs leading-relaxed text-stone-500">
          أضف رابط صفحة نشاطك التجاري على Google وسيُعرض في الموقع زر و QR code حقيقيان يوجّهان عملاءك لتقييمك.
        </p>
        <div className="space-y-4">
          <Field label="رابط تقييمات Google Business" hint="من لوحة Google Business: «اطلب من العملاء التقييم» ثم انسخ الرابط">
            <Input
              value={form.googleReviewsUrl}
              onChange={(e) => setForm((f) => ({ ...f, googleReviewsUrl: e.target.value }))}
              placeholder="https://g.page/r/.... /review"
              dir="ltr"
              className="text-left"
            />
          </Field>
          <Field label="رابط الموقع على خرائط Google">
            <Input
              value={form.googleMapsUrl}
              onChange={(e) => setForm((f) => ({ ...f, googleMapsUrl: e.target.value }))}
              placeholder="https://maps.google.com/..."
              dir="ltr"
              className="text-left"
            />
          </Field>
        </div>
      </Card>

      <SaveBar saving={saving} onSave={async () => { setSaving(true); await saveSection("business", form); setSaving(false); }} />
    </div>
  );
}
