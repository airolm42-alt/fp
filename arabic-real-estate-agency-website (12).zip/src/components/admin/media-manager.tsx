"use client";

import { useCallback, useEffect, useState } from "react";
import Image from "next/image";
import { Copy, Check, Trash2, Images as ImagesIcon, Loader2 } from "lucide-react";
import { Button, EmptyState, toast } from "@/components/ui";
import { ImageUpload, type UploadedImage } from "@/components/admin/image-upload";
import { cn } from "@/lib/utils";

type MediaItem = { id: string; url: string; name: string; mime: string; size: number; createdAt: string };

export function MediaManager() {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [copied, setCopied] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = useCallback(async (p: number) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/media?page=${p}`);
      const data = await res.json();
      if (res.ok) {
        setItems(data.items);
        setPage(data.page);
        setPages(data.pages);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { const timer = window.setTimeout(() => { void load(1); }, 0); return () => window.clearTimeout(timer); }, [load]);

  function toggleSelect(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  async function copyUrl(url: string, id: string) {
    try {
      await navigator.clipboard.writeText(`${location.origin}${url}`);
      setCopied(id);
      setTimeout(() => setCopied(null), 1500);
      toast("تم نسخ رابط الصورة");
    } catch {
      toast("تعذر النسخ", "error");
    }
  }

  async function deleteSelected() {
    if (selected.size === 0) return;
    if (!window.confirm(`حذف ${selected.size} صورة نهائيًا من المكتبة؟`)) return;
    setDeleting(true);
    try {
      const res = await fetch("/api/admin/media", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ids: Array.from(selected) }),
      });
      if (!res.ok) { const data = await res.json().catch(() => null); return toast(data?.error ?? "فشل الحذف", "error"); }
      toast("تم حذف الصور المحددة");
      setSelected(new Set());
      load(page);
    } finally { setDeleting(false); }
  }

  function onUploaded(imgs: UploadedImage[]) {
    if (imgs.length === 0) return;
    load(1);
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-stone-200 bg-white p-5 shadow-card">
        <h2 className="mb-4 text-base font-extrabold text-ink">رفع صور جديدة</h2>
        <ImageUpload value={[]} onChange={onUploaded} label="اختر صورًا لرفعها للمكتبة" />
      </div>

      <div className="flex items-center justify-between">
        <h2 className="text-base font-extrabold text-ink">الصور المرفوعة</h2>
        {selected.size > 0 && (
          <Button variant="danger" size="sm" loading={deleting} onClick={deleteSelected}>
            <Trash2 className="h-4 w-4" /> حذف المحدد ({selected.size})
          </Button>
        )}
      </div>

      {loading ? (
        <div className="flex justify-center py-20 text-brand-600"><Loader2 className="h-8 w-8 animate-spin" /></div>
      ) : items.length === 0 ? (
        <EmptyState
          icon={<ImagesIcon className="h-7 w-7" />}
          title="مكتبة الوسائط فارغة"
          description="ارفع صور العقارات والشعار والمحتوى من هنا أو أثناء إنشاء المحتوى مباشرة"
        />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6">
            {items.map((m) => (
              <div
                key={m.id}
                className={cn(
                  "group relative overflow-hidden rounded-xl border-2 bg-white transition",
                  selected.has(m.id) ? "border-brand-600 ring-2 ring-brand-600/20" : "border-transparent hover:border-stone-300",
                )}
              >
                <button onClick={() => toggleSelect(m.id)} className="relative block aspect-square w-full cursor-pointer" aria-label={`تحديد ${m.name}`}>
                  <Image src={m.url} alt={m.name} fill className="object-cover" sizes="200px" />
                  {selected.has(m.id) && (
                    <span className="absolute inset-0 flex items-center justify-center bg-brand-900/40">
                      <Check className="h-7 w-7 text-white" />
                    </span>
                  )}
                </button>
                <div className="absolute inset-x-0 bottom-0 flex items-center justify-between gap-1 bg-gradient-to-t from-black/80 to-transparent p-2 opacity-0 transition group-hover:opacity-100">
                  <span className="min-w-0 flex-1 truncate text-[10px] font-bold text-white">{m.name}</span>
                  <button onClick={() => copyUrl(m.url, m.id)} className="cursor-pointer rounded-md bg-white/90 p-1.5 text-ink hover:bg-white" title="نسخ الرابط">
                    {copied === m.id ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                  </button>
                </div>
              </div>
            ))}
          </div>

          {pages > 1 && (
            <div className="flex justify-center gap-1.5">
              {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
                <button
                  key={n}
                  onClick={() => load(n)}
                  className={cn(
                    "h-8 w-8 cursor-pointer rounded-lg text-xs font-black transition",
                    n === page ? "bg-brand-700 text-white" : "border border-stone-200 bg-white text-ink hover:border-brand-400",
                  )}
                >
                  {n}
                </button>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
