"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter, useSearchParams } from "next/navigation";
import { Eye, Pencil, Star, Trash2, Search, Building2, EyeOff, ExternalLink } from "lucide-react";
import { Badge, Button, EmptyState, Input, Select, toast } from "@/components/ui";
import { formatPrice, formatDate, cn } from "@/lib/utils";

export type PropertyRow = {
  id: string;
  title: string;
  slug: string;
  listingType: string;
  price: string | null;
  currency: string;
  location: string;
  status: string;
  featured: boolean;
  mainImage: string;
  createdAt: string | Date;
  typeName: string | null;
};

export function PropertiesTable({
  rows,
  types,
  page,
  pages,
  total,
}: {
  rows: PropertyRow[];
  types: { id: string; name: string }[];
  page: number;
  pages: number;
  total: number;
}) {
  const router = useRouter();
  const params = useSearchParams();
  const [q, setQ] = useState(params.get("q") ?? "");
  const [busy, setBusy] = useState<string | null>(null);

  function applyFilter(key: string, value: string) {
    const sp = new URLSearchParams(params.toString());
    if (value) sp.set(key, value);
    else sp.delete(key);
    sp.delete("page");
    router.push(`/admin/properties?${sp.toString()}`);
  }

  function search(e: React.FormEvent) {
    e.preventDefault();
    applyFilter("q", q.trim());
  }

  async function patch(id: string, data: Record<string, unknown>) {
    setBusy(id);
    try {
      const res = await fetch(`/api/admin/properties/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) {
        toast("فشل تنفيذ العملية", "error");
        return;
      }
      router.refresh();
    } finally {
      setBusy(null);
    }
  }

  async function remove(id: string, title: string) {
    if (!window.confirm(`حذف العقار «${title}» نهائيًا؟ لا يمكن التراجع.`)) return;
    setBusy(id);
    try {
      const res = await fetch(`/api/admin/properties/${id}`, { method: "DELETE" });
      if (!res.ok) {
        toast("فشل حذف العقار", "error");
        return;
      }
      toast("تم حذف العقار");
      router.refresh();
    } finally {
      setBusy(null);
    }
  }

  return (
    <div>
      {/* Filters */}
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <form onSubmit={search} className="relative min-w-52 flex-1">
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث بالعنوان أو الموقع..." className="!pe-9" />
          <button type="submit" className="absolute end-2.5 top-1/2 -translate-y-1/2 cursor-pointer text-stone-400 hover:text-brand-600" aria-label="بحث">
            <Search className="h-4.5 w-4.5" />
          </button>
        </form>
        <Select value={params.get("status") ?? ""} onChange={(e) => applyFilter("status", e.target.value)} className="!w-auto">
          <option value="">كل الحالات</option>
          <option value="published">منشور</option>
          <option value="draft">مسودة</option>
        </Select>
        <Select value={params.get("listing") ?? ""} onChange={(e) => applyFilter("listing", e.target.value)} className="!w-auto">
          <option value="">بيع + إيجار</option>
          <option value="sale">بيع</option>
          <option value="rent">إيجار</option>
        </Select>
        <Select value={params.get("type") ?? ""} onChange={(e) => applyFilter("type", e.target.value)} className="!w-auto">
          <option value="">كل الأنواع</option>
          {types.map((t) => (
            <option key={t.id} value={t.id}>{t.name}</option>
          ))}
        </Select>
      </div>

      {rows.length === 0 ? (
        <EmptyState
          icon={<Building2 className="h-7 w-7" />}
          title="لا توجد عقارات مطابقة"
          description="أضف أول عقار ليظهر على الموقع العام بعد نشره"
          action={
            <Link href="/admin/properties/new">
              <Button>إضافة عقار جديد</Button>
            </Link>
          }
        />
      ) : (
        <>
          <div className="overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-card">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-right">
                <thead>
                  <tr className="border-b border-stone-100 bg-stone-50/60 text-xs font-black text-stone-500">
                    <th className="px-4 py-3.5">العقار</th>
                    <th className="px-4 py-3.5">النوع</th>
                    <th className="px-4 py-3.5">السعر</th>
                    <th className="px-4 py-3.5">الحالة</th>
                    <th className="px-4 py-3.5">أضيف</th>
                    <th className="px-4 py-3.5 text-center">إجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100">
                  {rows.map((p) => (
                    <tr key={p.id} className={cn("transition hover:bg-stone-50/60", busy === p.id && "opacity-50")}>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="relative h-12 w-16 shrink-0 overflow-hidden rounded-lg bg-stone-100">
                            {p.mainImage ? (
                              <Image src={p.mainImage} alt={p.title} fill className="object-cover" sizes="64px" />
                            ) : (
                              <div className="flex h-full items-center justify-center text-stone-300">
                                <Building2 className="h-5 w-5" />
                              </div>
                            )}
                          </div>
                          <div className="min-w-0">
                            <p className="max-w-56 truncate text-sm font-bold text-ink">{p.title}</p>
                            <p className="max-w-56 truncate text-xs text-stone-400">{p.location || "—"}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-col gap-1">
                          <span className="text-xs font-bold text-ink">{p.typeName ?? "—"}</span>
                          <Badge tone={p.listingType === "sale" ? "brand" : "blue"}>
                            {p.listingType === "sale" ? "بيع" : "إيجار"}
                          </Badge>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm font-bold text-brand-800 whitespace-nowrap">
                        {formatPrice(p.price, p.currency)}
                      </td>
                      <td className="px-4 py-3">
                        <Badge tone={p.status === "published" ? "green" : "stone"}>
                          {p.status === "published" ? "منشور" : "مسودة"}
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-xs text-stone-400 whitespace-nowrap">{formatDate(p.createdAt)}</td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            title={p.featured ? "إزالة من المميزة" : "تمييز العقار"}
                            onClick={() => patch(p.id, { featured: !p.featured })}
                            className={cn("cursor-pointer rounded-lg p-2 transition", p.featured ? "text-gold-500 hover:bg-gold-50" : "text-stone-300 hover:bg-stone-100 hover:text-gold-500")}
                          >
                            <Star className={cn("h-4.5 w-4.5", p.featured && "fill-current")} />
                          </button>
                          <button
                            title={p.status === "published" ? "إلغاء النشر" : "نشر"}
                            onClick={() => patch(p.id, { status: p.status === "published" ? "draft" : "published" })}
                            className={cn("cursor-pointer rounded-lg p-2 transition", p.status === "published" ? "text-emerald-600 hover:bg-emerald-50" : "text-stone-400 hover:bg-stone-100")}
                          >
                            {p.status === "published" ? <Eye className="h-4.5 w-4.5" /> : <EyeOff className="h-4.5 w-4.5" />}
                          </button>
                          {p.status === "published" && (
                            <Link href={`/properties/${p.slug}`} target="_blank" title="معاينة" className="rounded-lg p-2 text-stone-400 transition hover:bg-stone-100 hover:text-brand-700">
                              <ExternalLink className="h-4.5 w-4.5" />
                            </Link>
                          )}
                          <Link href={`/admin/properties/${p.id}`} title="تعديل" className="rounded-lg p-2 text-stone-400 transition hover:bg-stone-100 hover:text-brand-700">
                            <Pencil className="h-4.5 w-4.5" />
                          </Link>
                          <button title="حذف" onClick={() => remove(p.id, p.title)} className="cursor-pointer rounded-lg p-2 text-stone-400 transition hover:bg-red-50 hover:text-red-600">
                            <Trash2 className="h-4.5 w-4.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Pagination */}
          <div className="mt-4 flex items-center justify-between text-sm">
            <span className="text-xs font-semibold text-stone-400">{total} عقار</span>
            {pages > 1 && (
              <div className="flex items-center gap-1.5">
                {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
                  <button
                    key={n}
                    onClick={() => {
                      const sp = new URLSearchParams(params.toString());
                      sp.set("page", String(n));
                      router.push(`/admin/properties?${sp.toString()}`);
                    }}
                    className={cn(
                      "h-8 w-8 cursor-pointer rounded-lg text-xs font-black transition",
                      n === page ? "bg-brand-700 text-white" : "bg-white text-ink border border-stone-200 hover:border-brand-400",
                    )}
                  >
                    {n}
                  </button>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
