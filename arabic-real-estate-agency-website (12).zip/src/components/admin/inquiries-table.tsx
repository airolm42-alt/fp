"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Inbox, Mail, Phone, Trash2, MessageSquare, Search } from "lucide-react";
import { Badge, EmptyState, Input, Select, toast } from "@/components/ui";
import { formatDate, cn } from "@/lib/utils";
import type { Inquiry } from "@/db/schema";

const STATUS = {
  new: { label: "جديد", tone: "gold" as const },
  contacted: { label: "تم التواصل", tone: "blue" as const },
  closed: { label: "مغلق", tone: "green" as const },
};

export function InquiriesTable({ rows, page, pages, total }: { rows: Inquiry[]; page: number; pages: number; total: number }) {
  const router = useRouter();
  const params = useSearchParams();
  const [q, setQ] = useState(params.get("q") ?? "");
  const [busy, setBusy] = useState<string | null>(null);

  function applyFilter(key: string, value: string) {
    const sp = new URLSearchParams(params.toString());
    if (value) sp.set(key, value);
    else sp.delete(key);
    sp.delete("page");
    router.push(`/admin/inquiries?${sp.toString()}`);
  }

  async function setStatus(id: string, status: string) {
    setBusy(id);
    try {
      const res = await fetch(`/api/admin/inquiries/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) return toast("فشل تحديث الحالة", "error");
      router.refresh();
    } finally { setBusy(null); }
  }

  async function remove(id: string) {
    if (!window.confirm("حذف هذا الاستفسار نهائيًا؟")) return;
    setBusy(id);
    try {
      const res = await fetch(`/api/admin/inquiries/${id}`, { method: "DELETE" });
      if (!res.ok) return toast("فشل الحذف", "error");
      toast("تم حذف الاستفسار");
      router.refresh();
    } finally { setBusy(null); }
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-2">
        <form
          onSubmit={(e) => { e.preventDefault(); applyFilter("q", q.trim()); }}
          className="relative min-w-52 flex-1"
        >
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="بحث بالاسم أو الهاتف..." className="!pe-9" />
          <button type="submit" className="absolute end-2.5 top-1/2 -translate-y-1/2 cursor-pointer text-stone-400 hover:text-brand-600" aria-label="بحث">
            <Search className="h-4.5 w-4.5" />
          </button>
        </form>
        <Select value={params.get("status") ?? ""} onChange={(e) => applyFilter("status", e.target.value)} className="!w-auto">
          <option value="">كل الحالات</option>
          <option value="new">جديد</option>
          <option value="contacted">تم التواصل</option>
          <option value="closed">مغلق</option>
        </Select>
      </div>

      {rows.length === 0 ? (
        <EmptyState
          icon={<Inbox className="h-7 w-7" />}
          title="لا توجد استفسارات"
          description="رسائل العملاء من نماذج التواصل بالموقع ستظهر هنا فور وصولها"
        />
      ) : (
        <>
          <div className="space-y-3">
            {rows.map((inq) => (
              <div key={inq.id} className={cn("rounded-2xl border border-stone-200 bg-white p-4 shadow-card transition sm:p-5", busy === inq.id && "opacity-50")}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-brand-700 text-sm font-black text-white">
                      {inq.name.slice(0, 1)}
                    </span>
                    <div>
                      <p className="text-sm font-extrabold text-ink">{inq.name}</p>
                      <p className="text-xs text-stone-400">{formatDate(inq.createdAt)}</p>
                    </div>
                  </div>
                  <Badge tone={STATUS[inq.status].tone}>{STATUS[inq.status].label}</Badge>
                </div>

                <p className="mt-3 rounded-xl bg-stone-50 p-3.5 text-sm leading-relaxed text-ink-soft">
                  {inq.propertyTitle && (
                    <span className="mb-1.5 block text-xs font-black text-brand-700">بخصوص عقار: {inq.propertyTitle}</span>
                  )}
                  <MessageSquare className="me-1.5 inline h-3.5 w-3.5 text-stone-300" />
                  {inq.message}
                </p>

                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <a href={`tel:${inq.phone}`} className="inline-flex items-center gap-1.5 rounded-lg bg-brand-50 px-3 py-1.5 text-xs font-bold text-brand-800 hover:bg-brand-100" dir="ltr">
                    <Phone className="h-3.5 w-3.5" /> {inq.phone}
                  </a>
                  {inq.email && (
                    <a href={`mailto:${inq.email}`} className="inline-flex items-center gap-1.5 rounded-lg bg-stone-100 px-3 py-1.5 text-xs font-bold text-stone-600 hover:bg-stone-200" dir="ltr">
                      <Mail className="h-3.5 w-3.5" /> {inq.email}
                    </a>
                  )}
                  <div className="ms-auto flex items-center gap-2">
                    <Select
                      value={inq.status}
                      onChange={(e) => setStatus(inq.id, e.target.value)}
                      className="!w-auto !py-1.5 !text-xs"
                    >
                      <option value="new">جديد</option>
                      <option value="contacted">تم التواصل</option>
                      <option value="closed">مغلق</option>
                    </Select>
                    <button onClick={() => remove(inq.id)} className="cursor-pointer rounded-lg p-2 text-stone-400 hover:bg-red-50 hover:text-red-600" aria-label="حذف">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 flex items-center justify-between text-sm">
            <span className="text-xs font-semibold text-stone-400">{total} استفسار</span>
            {pages > 1 && (
              <div className="flex items-center gap-1.5">
                {Array.from({ length: pages }, (_, i) => i + 1).map((n) => (
                  <button
                    key={n}
                    onClick={() => {
                      const sp = new URLSearchParams(params.toString());
                      sp.set("page", String(n));
                      router.push(`/admin/inquiries?${sp.toString()}`);
                    }}
                    className={cn(
                      "h-8 w-8 cursor-pointer rounded-lg text-xs font-black transition",
                      n === page ? "bg-brand-700 text-white" : "border border-stone-200 bg-white text-ink hover:border-brand-400",
                    )}
                  >
                    {n}
                  </button>
                ))}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
