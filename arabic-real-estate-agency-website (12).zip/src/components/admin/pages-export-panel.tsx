"use client";
import { useState } from "react";
import { ArrowUpRight, Download, Info, Loader2 } from "lucide-react";
import { Button, Field, Input, toast } from "@/components/ui";

export function PagesExportPanel({ backendOrigin, canManage }: { backendOrigin: string; canManage: boolean }) {
  const [apiUrl, setApiUrl] = useState(backendOrigin);
  const [siteUrl, setSiteUrl] = useState("");
  const [busy, setBusy] = useState(false);
  async function download(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true);
    try {
      const response = await fetch("/api/admin/publishing/pages", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ apiUrl, siteUrl }) });
      if (!response.ok) { const data = await response.json().catch(() => null); return toast(data?.error || "تعذّر بناء واجهة Pages", "error"); }
      if (!response.headers.get("content-type")?.includes("application/zip")) return toast("رد غير صالح للتنزيل", "error");
      const url = URL.createObjectURL(await response.blob());
      const anchor = document.createElement("a"); anchor.href = url; anchor.download = "real-estate-pages-static.zip";
      document.body.appendChild(anchor); anchor.click(); anchor.remove(); window.setTimeout(() => URL.revokeObjectURL(url), 30000);
      toast("واجهة Pages جاهزة. الخادم الحي وقائمة أصول الاستفسارات ما زالا مطلوبين.");
    } catch { toast("تعذّر الاتصال أثناء بناء الواجهة", "error"); }
    finally { setBusy(false); }
  }
  return <section id="github-pages-build" className="scroll-mt-24 rounded-2xl border border-brand-200 bg-white p-5 shadow-card sm:p-6" aria-labelledby="github-pages-build-title">
    <span className="mb-3 inline-flex rounded-full bg-brand-50 px-3 py-1 text-xs font-bold text-brand-700">واجهة ثابتة متصلة بالخادم الحقيقي</span>
    <h2 id="github-pages-build-title" className="text-lg font-extrabold">نسخة جاهزة لرفعها إلى Pages</h2>
    <p className="mt-2 text-sm leading-loose text-stone-600">تضم الصفحة الرئيسية والعقارات والتفاصيل ومن نحن والخدمات والتواصل والسياسات. قراءة المنشور والبحث وحفظ الاستفسارات تستخدم API حقيقيًا، والإدارة تُفتح على خادم Next.js المحمي. لا توجد كلمات مرور أو مفاتيح قاعدة بيانات في ZIP الواجهة.</p>
    <div className="my-4 flex items-start gap-2 rounded-xl border border-gold-200 bg-gold-50 p-3.5 text-xs leading-loose text-gold-900"><Info className="mt-1 h-4 w-4 shrink-0" /><p>هذا يجعل الواجهة قابلة للبناء لاستضافة ثابتة؛ لا ينقل الخادم إلى GitHub. تحتاج استضافة حية للـAPI وقاعدة البيانات والصور، وتفعيل PAGES_ALLOWED_ORIGINS على الخادم. راجع شروط GitHub Pages للاستخدام التجاري والمعاملات الحساسة؛ التوافق التقني ليس موافقة استعمال.</p></div>
    {canManage ? <form onSubmit={download} className="space-y-4">
      <Field label="عنوان خادم API العام" hint="نطاق الخادم الحقيقي فقط، دون /api أو /admin. رابط e2b معاينة متغيرة، وليس خلفية إنتاج دائمة."><Input required value={apiUrl} onChange={(e) => setApiUrl(e.target.value)} dir="ltr" className="text-left" placeholder="https://your-backend.example" maxLength={2048} /></Field>
      <Field label="رابط واجهة Pages (اختياري)" hint="مثل https://OWNER.github.io/REPOSITORY/ بعد إصداره من حسابك. يستخدم للـcanonical والخريطة، ولا يحجز عنوانًا."><Input value={siteUrl} onChange={(e) => setSiteUrl(e.target.value)} dir="ltr" className="text-left" placeholder="https://OWNER.github.io/REPOSITORY/" maxLength={2048} /></Field>
      <Button type="submit" loading={busy}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />} تنزيل ZIP الواجهة الثابتة</Button>
    </form> : <p className="text-xs font-bold text-stone-500">تنزيل الحزمة المخصصة متاح للمالك فقط.</p>}
    <p className="mt-5 text-xs leading-loose text-stone-500">للنشر التلقائي: حمّل المصدر الكامل وارفعه لمستودعك، واضبط Repository Variable باسم PAGES_API_URL، ثم Settings → Pages → GitHub Actions. ملف .github/workflows/github-pages.yml يرفع out-pages فقط. يتوقف البناء بوضوح لو لم تضبط خادم البيانات.</p>
    <a className="mt-4 inline-flex items-center gap-1.5 text-sm font-bold text-brand-700" href="https://docs.github.com/en/pages/getting-started-with-github-pages/using-custom-workflows-with-github-pages" target="_blank" rel="noopener noreferrer">طريقة تفعيل GitHub Actions لـPages <ArrowUpRight className="h-4 w-4" /></a>
  </section>;
}
