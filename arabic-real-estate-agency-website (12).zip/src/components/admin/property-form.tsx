"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Plus, X, Sparkles, MapPin, Search as SearchIcon } from "lucide-react";
import { Button, Card, Field, Input, Select, Switch, Textarea, toast } from "@/components/ui";
import { ImageUpload, type UploadedImage } from "@/components/admin/image-upload";
import { slugify } from "@/lib/utils";
import type { PropertyType } from "@/db/schema";

export type PropertyFormInitial = {
  id?: string;
  title: string;
  slug: string;
  description: string;
  typeId: string;
  listingType: "sale" | "rent";
  price: string;
  currency: string;
  location: string;
  address: string;
  area: string;
  bedrooms: string;
  bathrooms: string;
  floor: string;
  finishing: string;
  features: string[];
  images: UploadedImage[];
  googleMapsUrl: string;
  whatsappMessage: string;
  status: "draft" | "published";
  featured: boolean;
  metaTitle: string;
  metaDescription: string;
};

export const EMPTY_PROPERTY: PropertyFormInitial = {
  title: "",
  slug: "",
  description: "",
  typeId: "",
  listingType: "sale",
  price: "",
  currency: "ج.م",
  location: "",
  address: "",
  area: "",
  bedrooms: "",
  bathrooms: "",
  floor: "",
  finishing: "",
  features: [],
  images: [],
  googleMapsUrl: "",
  whatsappMessage: "",
  status: "draft",
  featured: false,
  metaTitle: "",
  metaDescription: "",
};

const FINISHING_OPTIONS = ["سوبر لوكس", "لوكس", "نص تشطيب", "تشطيب كامل", "على الطوب", "بدون تشطيب"];

export function PropertyForm({ initial, types }: { initial: PropertyFormInitial; types: PropertyType[] }) {
  const router = useRouter();
  const [form, setForm] = useState<PropertyFormInitial>(initial);
  const [saving, setSaving] = useState(false);
  const [featureInput, setFeatureInput] = useState("");
  const [seoOpen, setSeoOpen] = useState(false);

  const isEdit = !!initial.id;

  function set<K extends keyof PropertyFormInitial>(key: K, value: PropertyFormInitial[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function addFeature() {
    const v = featureInput.trim();
    if (!v) return;
    if (form.features.includes(v)) return;
    set("features", [...form.features, v]);
    setFeatureInput("");
  }

  async function submit(status?: "draft" | "published") {
    if (!form.title.trim()) {
      toast("أدخل عنوان العقار", "error");
      return;
    }
    setSaving(true);
    try {
      const payload = {
        title: form.title.trim(),
        slug: form.slug,
        description: form.description,
        typeId: form.typeId || null,
        listingType: form.listingType,
        price: form.price === "" ? null : Number(form.price),
        currency: form.currency || "ج.م",
        location: form.location,
        address: form.address,
        area: form.area === "" ? null : Number(form.area),
        bedrooms: form.bedrooms === "" ? null : Number(form.bedrooms),
        bathrooms: form.bathrooms === "" ? null : Number(form.bathrooms),
        floor: form.floor,
        finishing: form.finishing,
        features: form.features,
        mainImage: form.images[0]?.url ?? "",
        images: form.images.map((i) => ({ url: i.url, alt: i.alt ?? form.title })),
        googleMapsUrl: form.googleMapsUrl,
        whatsappMessage: form.whatsappMessage,
        status: status ?? form.status,
        featured: form.featured,
        metaTitle: form.metaTitle,
        metaDescription: form.metaDescription,
      };

      const res = await fetch(isEdit ? `/api/admin/properties/${initial.id}` : "/api/admin/properties", {
        method: isEdit ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        toast(data.error ?? "فشل حفظ العقار", "error");
        return;
      }
      toast(isEdit ? "تم حفظ التعديلات بنجاح" : "تم إضافة العقار بنجاح");
      router.push("/admin/properties");
      router.refresh();
    } catch {
      toast("حدث خطأ في الاتصال", "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      {/* Main column */}
      <div className="space-y-6 lg:col-span-2">
        <Card className="p-5 sm:p-6">
          <h2 className="mb-5 text-base font-extrabold text-ink">البيانات الأساسية</h2>
          <div className="space-y-4">
            <Field label="عنوان العقار" hint="مثال: شقة 150م بموقع متميز">
              <Input value={form.title} onChange={(e) => set("title", e.target.value)} placeholder="اكتب عنوانًا واضحًا وجذابًا" />
            </Field>

            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="رابط العقار (Slug)" hint="يظهر في عنوان الصفحة">
                <div className="flex gap-2">
                  <Input value={form.slug} onChange={(e) => set("slug", e.target.value)} placeholder="يُنشأ تلقائيًا" dir="ltr" className="text-left" />
                  <Button type="button" variant="outline" size="md" onClick={() => set("slug", slugify(form.title))} title="توليد من العنوان">
                    <Sparkles className="h-4 w-4" />
                  </Button>
                </div>
              </Field>
              <Field label="نوع العقار">
                <Select value={form.typeId} onChange={(e) => set("typeId", e.target.value)}>
                  <option value="">اختر النوع</option>
                  {types.map((t) => (
                    <option key={t.id} value={t.id}>{t.name}</option>
                  ))}
                </Select>
              </Field>
            </div>

            <div className="grid gap-4 sm:grid-cols-3">
              <Field label="الغرض">
                <div className="grid grid-cols-2 gap-2">
                  {(["sale", "rent"] as const).map((v) => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => set("listingType", v)}
                      className={`cursor-pointer rounded-xl border px-3 py-2.5 text-sm font-bold transition ${
                        form.listingType === v
                          ? "border-brand-600 bg-brand-700 text-white shadow-sm"
                          : "border-stone-300 bg-white text-ink-soft hover:border-brand-400"
                      }`}
                    >
                      {v === "sale" ? "بيع" : "إيجار"}
                    </button>
                  ))}
                </div>
              </Field>
              <Field label="السعر">
                <Input type="number" min={0} value={form.price} onChange={(e) => set("price", e.target.value)} placeholder="يظهر «السعر عند الطلب» إن تُرك فارغًا" dir="ltr" className="text-right" />
              </Field>
              <Field label="العملة">
                <Input value={form.currency} onChange={(e) => set("currency", e.target.value)} placeholder="ج.م" />
              </Field>
            </div>

            <Field label="الوصف">
              <Textarea
                value={form.description}
                onChange={(e) => set("description", e.target.value)}
                placeholder="اكتب وصفًا تفصيليًا للعقار: الموقع، المميزات، التشطيب، التفاصيل المهمة للعميل..."
                rows={7}
              />
            </Field>
          </div>
        </Card>

        <Card className="p-5 sm:p-6">
          <h2 className="mb-5 text-base font-extrabold text-ink">الموقع والتفاصيل</h2>
          <div className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="المنطقة / المدينة" hint="مثال: التجمع الخامس، القاهرة الجديدة">
                <Input value={form.location} onChange={(e) => set("location", e.target.value)} placeholder="المنطقة" />
              </Field>
              <Field label="العنوان التفصيلي (اختياري)">
                <Input value={form.address} onChange={(e) => set("address", e.target.value)} placeholder="اسم الشارع، رقم العقار..." />
              </Field>
            </div>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
              <Field label="المساحة (م²)">
                <Input type="number" min={0} value={form.area} onChange={(e) => set("area", e.target.value)} dir="ltr" className="text-right" />
              </Field>
              <Field label="غرف النوم">
                <Input type="number" min={0} value={form.bedrooms} onChange={(e) => set("bedrooms", e.target.value)} dir="ltr" className="text-right" />
              </Field>
              <Field label="الحمامات">
                <Input type="number" min={0} value={form.bathrooms} onChange={(e) => set("bathrooms", e.target.value)} dir="ltr" className="text-right" />
              </Field>
              <Field label="الدور">
                <Input value={form.floor} onChange={(e) => set("floor", e.target.value)} placeholder="مثال: الثالث" />
              </Field>
            </div>
            <Field label="التشطيب">
              <Input value={form.finishing} onChange={(e) => set("finishing", e.target.value)} placeholder="اختر أو اكتب حالة التشطيب" list="finishing-options" />
              <datalist id="finishing-options">
                {FINISHING_OPTIONS.map((o) => (
                  <option key={o} value={o} />
                ))}
              </datalist>
            </Field>

            <Field label="مميزات العقار" hint="اكتب الميزة ثم اضغط إضافة أو Enter">
              <div className="flex gap-2">
                <Input
                  value={featureInput}
                  onChange={(e) => setFeatureInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addFeature();
                    }
                  }}
                  placeholder="مثال: أسانسير، عداد كهرباء، واجهة بحرية..."
                />
                <Button type="button" variant="outline" onClick={addFeature}>
                  <Plus className="h-4 w-4" /> إضافة
                </Button>
              </div>
              {form.features.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {form.features.map((f) => (
                    <span key={f} className="inline-flex items-center gap-1.5 rounded-full bg-brand-50 py-1 pe-2 ps-3 text-xs font-bold text-brand-800 ring-1 ring-brand-600/15">
                      {f}
                      <button type="button" onClick={() => set("features", form.features.filter((x) => x !== f))} className="cursor-pointer text-brand-400 hover:text-red-600" aria-label={`حذف ${f}`}>
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </Field>

            <Field label="رابط الموقع على خرائط Google (اختياري)" hint="الصق رابط «تضمين» Embed لعرض الخريطة داخل الصفحة">
              <div className="relative">
                <Input value={form.googleMapsUrl} onChange={(e) => set("googleMapsUrl", e.target.value)} placeholder="https://www.google.com/maps/embed?..." dir="ltr" className="pl-9 text-left" />
                <MapPin className="absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400" />
              </div>
            </Field>
          </div>
        </Card>

        <Card className="p-5 sm:p-6">
          <h2 className="mb-2 text-base font-extrabold text-ink">صور العقار</h2>
          <p className="mb-4 text-xs text-stone-500">الصورة الأولى هي الصورة الرئيسية. يمكنك إعادة الترتيب بالأسهم.</p>
          <ImageUpload value={form.images} onChange={(imgs) => set("images", imgs)} />
        </Card>
      </div>

      {/* Sidebar column */}
      <div className="space-y-6">
        <Card className="p-5 sm:p-6">
          <h2 className="mb-5 text-base font-extrabold text-ink">النشر</h2>
          <div className="space-y-5">
            <div className="flex items-center justify-between">
              <span className="text-sm font-bold text-ink">الحالة</span>
              <span className={`rounded-full px-3 py-1 text-xs font-black ${form.status === "published" ? "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-600/20" : "bg-stone-100 text-stone-500"}`}>
                {form.status === "published" ? "منشور" : "مسودة"}
              </span>
            </div>
            <Switch checked={form.featured} onChange={(v) => set("featured", v)} label="عقار مميز (يظهر في الرئيسية)" />

            <Field label="رسالة الواتساب المخصصة (اختياري)" hint="عند تركها فارغة يُرسل: مرحبًا، أنا مهتم بالعقار: [العنوان]">
              <Textarea
                rows={3}
                value={form.whatsappMessage}
                onChange={(e) => set("whatsappMessage", e.target.value)}
                placeholder={`مرحبًا، أنا مهتم بالعقار: ${form.title || "[عنوان العقار]"}`}
              />
            </Field>

            <div className="grid grid-cols-2 gap-2 border-t border-stone-100 pt-4">
              {form.status === "published" ? (
                <>
                  <Button type="button" variant="outline" loading={saving} onClick={() => submit("draft")}>
                    حفظ كمسودة
                  </Button>
                  <Button type="button" loading={saving} onClick={() => submit("published")}>
                    تحديث النشر
                  </Button>
                </>
              ) : (
                <>
                  <Button type="button" variant="outline" loading={saving} onClick={() => submit("draft")}>
                    حفظ كمسودة
                  </Button>
                  <Button type="button" loading={saving} onClick={() => submit("published")}>
                    نشر العقار
                  </Button>
                </>
              )}
            </div>
            <Link href="/admin/properties" className="block text-center text-xs font-bold text-stone-400 hover:text-ink">
              إلغاء والعودة للقائمة
            </Link>
          </div>
        </Card>

        <Card className="p-5 sm:p-6">
          <button
            type="button"
            onClick={() => setSeoOpen((v) => !v)}
            className="flex w-full cursor-pointer items-center justify-between"
          >
            <span className="flex items-center gap-2 text-base font-extrabold text-ink">
              <SearchIcon className="h-4.5 w-4.5 text-brand-600" /> إعدادات SEO للعقار
            </span>
            <span className="text-xs font-bold text-brand-700">{seoOpen ? "إخفاء" : "إظهار"}</span>
          </button>
          {seoOpen && (
            <div className="mt-4 space-y-4">
              <Field label="عنوان الصفحة (Meta Title)">
                <Input value={form.metaTitle} onChange={(e) => set("metaTitle", e.target.value)} placeholder={form.title || "عنوان العقار"} />
              </Field>
              <Field label="وصف الصفحة (Meta Description)">
                <Textarea rows={3} value={form.metaDescription} onChange={(e) => set("metaDescription", e.target.value)} placeholder="وصف مختصر يظهر في نتائج البحث" />
              </Field>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
