"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button, Card, Field, Input, toast, FormAlert } from "@/components/ui";

export function ProfileForm({ initialName, initialEmail }: { initialName: string; initialEmail: string }) {
  const [name, setName] = useState(initialName);
  const [email, setEmail] = useState(initialEmail);
  const [saving, setSaving] = useState(false);

  async function save() {
    if (name.trim().length < 2) return toast("أدخل اسمًا صحيحًا", "error");
    setSaving(true);
    try {
      const res = await fetch("/api/admin/account", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "profile", data: { name: name.trim(), email: email.trim() } }),
      });
      const data = await res.json();
      if (!res.ok) return toast(data.error ?? "فشل الحفظ", "error");
      toast("تم تحديث بيانات الحساب");
    } finally { setSaving(false); }
  }

  return (
    <Card className="p-5 sm:p-6">
      <h2 className="mb-5 text-base font-extrabold text-ink">بيانات الحساب</h2>
      <div className="space-y-4">
        <Field label="الاسم">
          <Input value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="البريد الإلكتروني" hint="يُستخدم لتسجيل الدخول للوحة">
          <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} dir="ltr" className="text-left" />
        </Field>
        <Button onClick={save} loading={saving}>حفظ البيانات</Button>
      </div>
    </Card>
  );
}

export function PasswordForm() {
  const router = useRouter();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  async function save() {
    if (next.length < 12) return toast("كلمة المرور الجديدة 12 حرفًا على الأقل وتشمل حروفًا وأرقامًا", "error");
    if (next !== confirm) return toast("تأكيد كلمة المرور غير متطابق", "error");
    setSaving(true);
    try {
      const res = await fetch("/api/admin/account", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "password", data: { currentPassword: current, newPassword: next } }),
      });
      const data = await res.json();
      if (!res.ok) return toast(data.error ?? "فشل تغيير كلمة المرور", "error");
      setDone(true);
      setCurrent(""); setNext(""); setConfirm("");
      toast("تم تغيير كلمة المرور وإبطال الجلسات القديمة");
      router.refresh();
    } finally { setSaving(false); }
  }

  return (
    <Card className="p-5 sm:p-6">
      <h2 className="mb-5 text-base font-extrabold text-ink">تغيير كلمة المرور</h2>
      <div className="space-y-4">
        {done && <FormAlert type="success" message="تم التحديث — استخدم كلمة المرور الجديدة في الدخول القادم" />}
        <Field label="كلمة المرور الحالية">
          <Input type="password" value={current} onChange={(e) => setCurrent(e.target.value)} autoComplete="current-password" dir="ltr" className="text-left" />
        </Field>
        <Field label="كلمة المرور الجديدة" hint="12 حرفًا على الأقل وتشمل حروفًا لاتينية وأرقامًا">
          <Input type="password" value={next} onChange={(e) => setNext(e.target.value)} autoComplete="new-password" dir="ltr" className="text-left" />
        </Field>
        <Field label="تأكيد كلمة المرور الجديدة">
          <Input type="password" value={confirm} onChange={(e) => setConfirm(e.target.value)} autoComplete="new-password" dir="ltr" className="text-left" />
        </Field>
        <Button onClick={save} loading={saving} disabled={!current || !next}>تغيير كلمة المرور</Button>
      </div>
    </Card>
  );
}
