"use client";

import { useCallback, useState, type ReactNode } from "react";
import { useDialog } from "@/components/use-dialog";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  Building2,
  PlusCircle,
  Shapes,
  Inbox,
  Store,
  Info,
  Briefcase,
  MapPin,
  Images,
  Star,
  Settings2,
  Search,
  Users,
  UserCircle,
  LogOut,
  Menu,
  X,
  ExternalLink,
  ChevronDown,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Toaster, toast } from "@/components/ui";

const NAV = [
  { href: "/admin/dashboard", label: "لوحة التحكم", icon: LayoutDashboard },
  { href: "/admin/properties", label: "العقارات", icon: Building2 },
  { href: "/admin/properties/new", label: "إضافة عقار", icon: PlusCircle },
  { href: "/admin/types", label: "أنواع العقارات", icon: Shapes },
  { href: "/admin/inquiries", label: "الاستفسارات", icon: Inbox },
  { href: "/admin/business", label: "بيانات النشاط", icon: Store },
  { href: "/admin/about", label: "صفحة من نحن", icon: Info },
  { href: "/admin/services", label: "الخدمات", icon: Briefcase },
  { href: "/admin/areas", label: "المناطق", icon: MapPin },
  { href: "/admin/media", label: "مكتبة الوسائط", icon: Images },
  { href: "/admin/reviews", label: "تقييمات Google", icon: Star },
  { href: "/admin/settings", label: "إعدادات الموقع", icon: Settings2 },
  { href: "/admin/seo", label: "إعدادات SEO", icon: Search },
  { href: "/admin/publishing", label: "النشر والروابط", icon: ExternalLink },
  { href: "/admin/diagnostics", label: "فحص الموقع", icon: Settings2 },
  { href: "/admin/team", label: "فريق الإدارة", icon: Users },
];

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  return (
    <nav className="flex flex-col gap-1 px-3">
      {NAV.map((item) => {
        const active =
          item.href === "/admin/properties"
            ? pathname === item.href
            : pathname === item.href || pathname.startsWith(item.href + "/");
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={cn(
              "flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-bold transition-colors",
              active
                ? "bg-gold-400/15 text-gold-300"
                : "text-brand-100/70 hover:bg-white/5 hover:text-white",
            )}
          >
            <item.icon className={cn("h-[18px] w-[18px]", active && "text-gold-400")} />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

export function AdminShell({ children, adminName, adminEmail }: { children: ReactNode; adminName: string; adminEmail: string }) {
  const [open, setOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const router = useRouter();
  const closeDrawer = useCallback(() => setOpen(false), []);
  const drawer = useDialog(open, closeDrawer);

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    toast("تم تسجيل الخروج");
    router.replace("/admin/login");
    router.refresh();
  }

  const sidebarContent = (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between px-5 py-5">
        <Link href="/admin/dashboard" className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gold-400 text-brand-950">
            <Building2 className="h-5 w-5" />
          </span>
          <span className="text-lg font-black text-white">لوحة الإدارة</span>
        </Link>
        <button className="cursor-pointer text-white/60 hover:text-white lg:hidden" onClick={() => setOpen(false)} aria-label="إغلاق القائمة">
          <X className="h-5 w-5" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto pb-4">
        <NavLinks onNavigate={() => setOpen(false)} />
      </div>
      <div className="border-t border-white/10 p-3">
        <Link
          href="/admin/account"
          onClick={() => setOpen(false)}
          className="flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-bold text-brand-100/70 hover:bg-white/5 hover:text-white"
        >
          <UserCircle className="h-[18px] w-[18px]" />
          حسابي
        </Link>
        <button
          onClick={logout}
          className="flex w-full cursor-pointer items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-bold text-red-300/90 hover:bg-red-500/10 hover:text-red-300"
        >
          <LogOut className="h-[18px] w-[18px]" />
          تسجيل الخروج
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-stone-100">
      {/* Desktop sidebar (right side in RTL) */}
      <aside className="fixed inset-y-0 start-0 z-40 hidden w-64 bg-brand-950 lg:block">
        {sidebarContent}
      </aside>

      {/* Mobile drawer */}
      {open && (
        <div ref={drawer} role="dialog" aria-modal="true" aria-label="قائمة الإدارة" className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 start-0 w-72 max-w-[85vw] bg-brand-950 shadow-2xl animate-rise">
            {sidebarContent}
          </aside>
        </div>
      )}

      <div className="lg:ms-64">
        {/* Topbar */}
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b border-stone-200 bg-white/85 px-4 backdrop-blur-lg sm:px-6">
          <div className="flex items-center gap-3">
            <button
              className="cursor-pointer rounded-lg p-2 text-ink hover:bg-stone-100 lg:hidden"
              onClick={() => setOpen(true)}
              aria-label="فتح القائمة"
            >
              <Menu className="h-5 w-5" />
            </button>
            <Link
              href="/"
              target="_blank"
              className="hidden items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-bold text-brand-700 hover:bg-brand-50 sm:inline-flex"
            >
              معاينة الموقع
              <ExternalLink className="h-3.5 w-3.5" />
            </Link>
          </div>

          <div className="relative">
            <button
              onClick={() => setMenuOpen((v) => !v)}
              className="flex cursor-pointer items-center gap-2.5 rounded-xl px-2 py-1.5 hover:bg-stone-100"
            >
              <span className="flex h-9 w-9 items-center justify-center rounded-full bg-brand-700 text-sm font-black text-white">
                {adminName?.slice(0, 1) || "م"}
              </span>
              <span className="hidden text-start sm:block">
                <span className="block text-sm font-bold text-ink leading-tight">{adminName}</span>
                <span className="block text-xs text-stone-400 leading-tight">{adminEmail}</span>
              </span>
              <ChevronDown className="h-4 w-4 text-stone-400" />
            </button>
            {menuOpen && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setMenuOpen(false)} />
                <div className="absolute end-0 z-20 mt-2 w-44 overflow-hidden rounded-xl border border-stone-200 bg-white py-1 shadow-lg">
                  <Link
                    href="/admin/account"
                    onClick={() => setMenuOpen(false)}
                    className="flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-ink hover:bg-stone-50"
                  >
                    <UserCircle className="h-4 w-4" /> حسابي
                  </Link>
                  <button
                    onClick={logout}
                    className="flex w-full cursor-pointer items-center gap-2 px-4 py-2.5 text-sm font-semibold text-red-600 hover:bg-red-50"
                  >
                    <LogOut className="h-4 w-4" /> تسجيل الخروج
                  </button>
                </div>
              </>
            )}
          </div>
        </header>

        <main className="p-4 pb-20 sm:p-6 lg:p-8">{children}</main>
      </div>
      <Toaster />
    </div>
  );
}

export function PageHeader({ title, description, action }: { title: string; description?: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="text-2xl font-black text-ink">{title}</h1>
        {description && <p className="mt-1 text-sm text-stone-500">{description}</p>}
      </div>
      {action}
    </div>
  );
}
