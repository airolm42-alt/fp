"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Mail, Lock, Eye, EyeOff, Building2 } from "lucide-react";
import { Button, FormAlert, Input, Label, Modal } from "@/components/ui";

export function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);

  const displayedError = error || (params.get("expired") ? "انتهت صلاحية الجلسة. سجّل الدخول مرة أخرى" : "");

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "فشل تسجيل الدخول");
        return;
      }
      // Verify the session cookie was actually stored by the browser. Some
      // embedded/iframe or strict privacy contexts silently drop cookies.
      const check = await fetch("/api/admin/session", { cache: "no-store" });
      if (!check.ok) {
        setError(
          "تم التحقق من بياناتك لكن المتصفح منع حفظ ملف الجلسة. افتح الموقع في تبويب جديد مستقل ثم سجّل الدخول مرة أخرى.",
        );
        return;
      }

      const next = params.get("next");
      router.replace(data.mustChangePassword ? "/admin/account" : next && /^\/admin(?:\/|$)/.test(next) ? next : "/admin/dashboard");
      router.refresh();
    } catch {
      setError("حدث خطأ في الاتصال. حاول مرة أخرى");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="w-full max-w-md">
      <div className="rounded-3xl border border-white/10 bg-white/[0.06] p-8 shadow-2xl backdrop-blur-xl sm:p-10">
        <div className="mb-8 text-center">
          <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gold-400 text-brand-950 shadow-lg">
            <Building2 className="h-7 w-7" />
          </div>
          <h1 className="text-2xl font-black text-white">لوحة الإدارة</h1>
          <p className="mt-1.5 text-sm text-brand-100/60">سجّل الدخول لإدارة موقعك العقاري</p>
        </div>

        <form onSubmit={submit} className="space-y-5">
          {displayedError && <FormAlert type="error" message={displayedError} />}

          <div>
            <Label htmlFor="admin-login-email" className="!text-brand-100/90">البريد الإلكتروني</Label>
            <div className="relative">
              <Input
                id="admin-login-email"
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@example.com"
                className="border-white/15 bg-white/10 !pr-10 text-white placeholder:text-white/30 focus:border-gold-400 focus:ring-gold-400/20"
                dir="ltr"
              />
              <Mail className="pointer-events-none absolute end-3 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-white/40" />
            </div>
          </div>

          <div>
            <Label htmlFor="admin-login-password" className="!text-brand-100/90">كلمة المرور</Label>
            <div className="relative">
              <Input
                id="admin-login-password"
                type={showPassword ? "text" : "password"}
                required
                autoComplete="current-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="border-white/15 bg-white/10 !pr-10 !pl-10 text-white placeholder:text-white/30 focus:border-gold-400 focus:ring-gold-400/20"
                dir="ltr"
              />
              <Lock className="pointer-events-none absolute end-3 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-white/40" />
              <button
                type="button"
                onClick={() => setShowPassword((v) => !v)}
                className="absolute start-3 top-1/2 -translate-y-1/2 cursor-pointer text-white/40 hover:text-white"
                aria-label="إظهار كلمة المرور"
              >
                {showPassword ? <EyeOff className="h-4.5 w-4.5" /> : <Eye className="h-4.5 w-4.5" />}
              </button>
            </div>
          </div>

          <Button variant="gold" size="lg" className="w-full" loading={loading}>
            تسجيل الدخول
          </Button>

          <button
            type="button"
            onClick={() => setForgotOpen(true)}
            className="w-full cursor-pointer text-center text-sm font-semibold text-brand-100/60 hover:text-gold-300"
          >
            نسيت كلمة المرور؟
          </button>
        </form>
      </div>

      <Modal open={forgotOpen} onClose={() => setForgotOpen(false)} title="استعادة كلمة المرور">
        <div className="space-y-4 text-sm leading-relaxed text-ink-soft">
          <p>
            لأمان بياناتك، لا يتم إرسال روابط الاستعادة عبر البريد تلقائيًا في هذه النسخة.
            لإعادة تعيين كلمة المرور اتبع إحدى الطرق التالية:
          </p>
          <ol className="list-decimal space-y-2 pr-5">
            <li>إذا كنت مشرفًا، اطلب من مالك الموقع إعادة تعيين كلمة مرورك من «فريق الإدارة».</li>
            <li>إذا كنت المالك، استخدم لوحة الاستضافة لضبط بريد المالك وكلمة مرور جديدة قوية في المتغيرات الخاصة، وفعّل RESET_ADMIN_PASSWORD=true ثم شغّل scripts/seed.ts من طرفية الخادم. ألغِ هذا المتغير فور إتمام الاستعادة.</li>
            <li>لا ترسل أسرار الاستضافة أو كلمات المرور في نموذج التواصل العام. الاستعادة الآلية بالبريد تحتاج خدمة بريد أو Supabase Auth مهيأة؛ هذه النسخة لا تدّعي توفرها.</li>
          </ol>
          <p className="rounded-xl bg-brand-50 p-3 text-xs font-semibold text-brand-800">
            بعد تسجيل الدخول يمكنك تغيير بريدك وكلمة مرورك في أي وقت من صفحة «حسابي».
          </p>
          <Button className="w-full" onClick={() => setForgotOpen(false)}>
            فهمت
          </Button>
        </div>
      </Modal>
    </div>
  );
}
