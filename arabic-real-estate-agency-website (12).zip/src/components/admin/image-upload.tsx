"use client";
import { useRef, useState } from "react";
import Image from "next/image";
import { ImagePlus, Loader2, Trash2, Star, ArrowRight, ArrowLeft, Images } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button, EmptyState, Modal, toast } from "@/components/ui";
export type UploadedImage = { url: string; alt?: string };

export function ImageUpload({ value, onChange, multiple = true, label = "اختر الصور أو اسحبها هنا", aspect = "aspect-[4/3]" }: {
  value: UploadedImage[]; onChange: (images: UploadedImage[]) => void; multiple?: boolean; label?: string; aspect?: string;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [libraryOpen, setLibraryOpen] = useState(false);
  const [loadingLibrary, setLoadingLibrary] = useState(false);
  const [library, setLibrary] = useState<{ id: string; url: string; name: string }[]>([]);
  const [libraryPage, setLibraryPage] = useState(1);
  const [libraryPages, setLibraryPages] = useState(1);

  async function handleFiles(list: FileList | null) {
    if (!list?.length || uploading) return;
    const files = Array.from(list);
    if (!multiple && files.length > 1) return toast("اختر صورة واحدة فقط", "error");
    if (files.length > 10 || (multiple && value.length + files.length > 40)) return toast("حد الرفع 10 صور في المرة، ومعرض العقار حتى 40 صورة", "error");
    if (files.some((file) => file.size > 8 * 1024 * 1024) || files.reduce((size, file) => size + file.size, 0) > 24 * 1024 * 1024) return toast("حتى 8MB للصورة و24MB للدفعة. ارفع الصور على دفعات أصغر.", "error");
    setUploading(true);
    try {
      const form = new FormData(); files.forEach((file) => form.append("files", file));
      const response = await fetch("/api/admin/upload", { method: "POST", body: form });
      const data = await response.json();
      if (!response.ok) return toast(data.error ?? "تعذّر رفع الصور", "error");
      const added = (data.files as { url: string }[]).map((file) => ({ url: file.url }));
      onChange(multiple ? [...value, ...added] : added.slice(0, 1));
      toast("تم رفع الصور وضغطها بنجاح");
    } catch { toast("تعذّر الاتصال أثناء الرفع", "error"); }
    finally { setUploading(false); if (input.current) input.current.value = ""; }
  }
  async function loadLibrary(page: number) {
    setLibraryOpen(true); setLoadingLibrary(true);
    try {
      const response = await fetch(`/api/admin/media?page=${page}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) return toast(data.error ?? "تعذّر فتح المكتبة", "error");
      setLibrary(data.items); setLibraryPage(data.page); setLibraryPages(data.pages);
    } catch { toast("تعذّر تحميل المكتبة", "error"); }
    finally { setLoadingLibrary(false); }
  }
  function choose(url: string) {
    if (multiple && value.some((image) => image.url === url)) return toast("الصورة موجودة بالفعل");
    if (multiple && value.length >= 40) return toast("وصلت إلى حد صور المعرض", "error");
    onChange(multiple ? [...value, { url }] : [{ url }]);
    if (!multiple) setLibraryOpen(false);
    toast("تم اختيار الصورة من المكتبة");
  }
  function move(index: number, delta: number) {
    const target = index + delta; if (target < 0 || target >= value.length) return;
    const next = [...value]; [next[index], next[target]] = [next[target], next[index]]; onChange(next);
  }
  return <div>
    <input ref={input} type="file" accept="image/jpeg,image/png,image/webp,image/avif" multiple={multiple} className="hidden" aria-label="ملفات الصور" onChange={(e) => handleFiles(e.target.files)} />
    <button type="button" disabled={uploading} onClick={() => input.current?.click()} onDragOver={(e) => { e.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={(e) => { e.preventDefault(); setDragging(false); handleFiles(e.dataTransfer.files); }}
      className={cn("flex w-full cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed px-4 py-8 text-sm font-bold transition disabled:opacity-60", dragging ? "border-brand-600 bg-brand-50 text-brand-700" : "border-stone-300 bg-stone-50 text-stone-500 hover:border-brand-400 hover:bg-brand-50")}>
      {uploading ? <><Loader2 className="h-6 w-6 animate-spin" /> جاري رفع الصور وضغطها...</> : <><ImagePlus className="h-6 w-6" />{label}<span className="text-xs font-medium text-stone-400">JPG / PNG / WebP / AVIF حتى 8MB للصورة — ضغط تلقائي</span></>}
    </button>
    <Button type="button" variant="outline" size="sm" className="mt-3" onClick={() => loadLibrary(1)}><Images className="h-4 w-4" /> اختيار من مكتبة الصور</Button>
    {value.length > 0 && <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">{value.map((image, index) => <div key={image.url + index} className="group relative overflow-hidden rounded-xl border border-stone-200 bg-white">
      <div className={cn("relative w-full", aspect)}><Image src={image.url} alt={image.alt || `صورة ${index + 1}`} fill className="object-cover" sizes="200px" /></div>
      {index === 0 && multiple && <span className="absolute top-2 start-2 flex items-center gap-1 rounded-full bg-gold-500 px-2 py-0.5 text-[10px] font-black text-brand-950"><Star className="h-3 w-3 fill-current" />رئيسية</span>}
      <div className="absolute inset-x-0 bottom-0 flex items-center justify-center gap-1 bg-gradient-to-t from-black/70 to-transparent p-2 sm:opacity-0 sm:group-hover:opacity-100 sm:focus-within:opacity-100 transition">
        {index > 0 && <button type="button" title="تعيين كصورة رئيسية" aria-label={`تعيين صورة ${index + 1} رئيسية`} className="cursor-pointer rounded-md bg-white/90 p-1.5 text-brand-800" onClick={() => onChange([value[index], ...value.filter((_, i) => i !== index)])}><Star className="h-3.5 w-3.5" /></button>}
        {multiple && <><button type="button" aria-label="تحريك الصورة لاحقًا" onClick={() => move(index, 1)} className="cursor-pointer rounded-md bg-white/90 p-1.5"><ArrowRight className="h-3.5 w-3.5" /></button><button type="button" aria-label="تحريك الصورة سابقًا" onClick={() => move(index, -1)} className="cursor-pointer rounded-md bg-white/90 p-1.5"><ArrowLeft className="h-3.5 w-3.5" /></button></>}
        <button type="button" aria-label={`إزالة صورة ${index + 1} من المحتوى`} onClick={() => onChange(value.filter((_, i) => i !== index))} className="cursor-pointer rounded-md bg-red-600/90 p-1.5 text-white"><Trash2 className="h-3.5 w-3.5" /></button>
      </div>
    </div>)}</div>}
    <Modal open={libraryOpen} onClose={() => setLibraryOpen(false)} title="اختر صورة موجودة في المكتبة" wide>
      {loadingLibrary ? <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-brand-600" /></div> : !library.length ? <EmptyState title="المكتبة فارغة" description="ارفع صورك أولًا من هذا النموذج أو صفحة الوسائط" /> : <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">{library.map((image) => <button type="button" key={image.id} onClick={() => choose(image.url)} className="group overflow-hidden rounded-xl border border-stone-200 text-start hover:border-brand-500 cursor-pointer" aria-label={`اختيار ${image.name}`}><div className="relative aspect-[4/3]"><Image src={image.url} alt={image.name} fill className="object-cover" sizes="200px" /></div><p className="truncate px-2 py-2 text-xs font-bold">{image.name}</p></button>)}</div>}
      {libraryPages > 1 && <div className="mt-4 flex items-center justify-center gap-3"><Button variant="outline" size="sm" disabled={libraryPage <= 1 || loadingLibrary} onClick={() => loadLibrary(libraryPage - 1)}>السابق</Button><span className="text-xs">{libraryPage} / {libraryPages}</span><Button variant="outline" size="sm" disabled={libraryPage >= libraryPages || loadingLibrary} onClick={() => loadLibrary(libraryPage + 1)}>التالي</Button></div>}
    </Modal>
  </div>;
}
