"use client";

import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { Pencil, Trash2, Plus, MapPin, Briefcase, Shapes, GripVertical } from "lucide-react";
import { Badge, Button, Card, EmptyState, Field, Input, Modal, Switch, Textarea, Select, toast } from "@/components/ui";
import { ImageUpload, type UploadedImage } from "@/components/admin/image-upload";
import type { Service, Area, PropertyType } from "@/db/schema";

const ICON_OPTIONS = [
  { value: "", label: "بدون أيقونة" },
  { value: "building", label: "مبنى" },
  { value: "home", label: "منزل" },
  { value: "key", label: "مفتاح" },
  { value: "chart", label: "تسويق" },
  { value: "document", label: "تعاقدات" },
  { value: "compass", label: "استشارات" },
  { value: "wallet", label: "تمويل/تقييم" },
  { value: "shield", label: "أمان/موثوقية" },
  { value: "map", label: "مناطق" },
];

/* ------------------------------- Services ------------------------------- */
type ServiceForm = { title: string; description: string; icon: string; image: string; published: boolean; sort: number };
const emptyService: ServiceForm = { title: "", description: "", icon: "", image: "", published: false, sort: 0 };

export function ServicesManager({ items }: { items: Service[] }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Service | null>(null);
  const [form, setForm] = useState<ServiceForm>(emptyService);
  const [saving, setSaving] = useState(false);

  function openNew() {
    setEditing(null);
    setForm(emptyService);
    setOpen(true);
  }
  function openEdit(s: Service) {
    setEditing(s);
    setForm({ title: s.title, description: s.description, icon: s.icon, image: s.image, published: s.published, sort: s.sort });
    setOpen(true);
  }

  async function save() {
    if (!form.title.trim()) return toast("أدخل عنوان الخدمة", "error");
    setSaving(true);
    try {
      const res = await fetch(editing ? `/api/admin/services/${editing.id}` : "/api/admin/services", {
        method: editing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) return toast("فشل حفظ الخدمة", "error");
      toast(editing ? "تم تحديث الخدمة" : "تمت إضافة الخدمة");
      setOpen(false);
      router.refresh();
    } finally {
      setSaving(false);
    }
  }

  async function remove(s: Service) {
    if (!window.confirm(`حذف خدمة «${s.title}»؟`)) return;
    const res = await fetch(`/api/admin/services/${s.id}`, { method: "DELETE" });
    if (!res.ok) return toast("فشل الحذف", "error");
    toast("تم حذف الخدمة");
    router.refresh();
  }

  async function togglePublish(s: Service) {
    const res = await fetch(`/api/admin/services/${s.id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title: s.title, description: s.description, icon: s.icon, image: s.image, sort: s.sort, published: !s.published }),
    });
    if (!res.ok) return toast("فشل تحديث الحالة", "error");
    router.refresh();
  }

  return (
    <div>
      {items.length === 0 ? (
        <EmptyState
          icon={<Briefcase className="h-7 w-7" />}
          title="لم تُضف خدمات بعد"
          description="أضف الخدمات التي يقدمها نشاطك فعليًا — تظهر الخدمات المنشورة في الصفحة الرئيسية وصفحة الخدمات"
          action={<Button onClick={openNew}><Plus className="h-4 w-4" /> إضافة خدمة</Button>}
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {items.map((s) => (
            <Card key={s.id} className="flex flex-col p-5">
              <div className="mb-3 flex items-start justify-between">
                <div className="relative h-12 w-12 overflow-hidden rounded-xl bg-brand-50 text-brand-700">
                  {s.image ? (
                    <Image src={s.image} alt={s.title} fill className="object-cover" sizes="48px" />
                  ) : (
                    <span className="flex h-full items-center justify-center"><Briefcase className="h-5 w-5" /></span>
                  )}
                </div>
                <Badge tone={s.published ? "green" : "stone"}>{s.published ? "منشورة" : "مخفية"}</Badge>
              </div>
              <h3 className="text-sm font-extrabold text-ink">{s.title}</h3>
              <p className="mt-1 line-clamp-2 flex-1 text-xs leading-relaxed text-stone-500">{s.description || "بدون وصف"}</p>
              <div className="mt-4 flex items-center justify-between border-t border-stone-100 pt-3">
                <Switch checked={s.published} onChange={() => togglePublish(s)} label="عرض بالموقع" />
                <div className="flex gap-1">
                  <button onClick={() => openEdit(s)} className="cursor-pointer rounded-lg p-2 text-stone-400 hover:bg-stone-100 hover:text-brand-700" aria-label="تعديل"><Pencil className="h-4 w-4" /></button>
                  <button onClick={() => remove(s)} className="cursor-pointer rounded-lg p-2 text-stone-400 hover:bg-red-50 hover:text-red-600" aria-label="حذف"><Trash2 className="h-4 w-4" /></button>
                </div>
              </div>
            </Card>
          ))}
          <button onClick={openNew} className="flex min-h-44 cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-stone-300 text-sm font-bold text-stone-400 transition hover:border-brand-400 hover:text-brand-700">
            <Plus className="h-6 w-6" /> إضافة خدمة جديدة
          </button>
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? "تعديل الخدمة" : "إضافة خدمة"} wide>
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="اسم الخدمة">
              <Input value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} placeholder="مثال: بيع وتسويق العقارات" />
            </Field>
            <Field label="الأيقونة">
              <Select value={form.icon} onChange={(e) => setForm((f) => ({ ...f, icon: e.target.value }))}>
                {ICON_OPTIONS.map((o) => (<option key={o.value} value={o.value}>{o.label}</option>))}
              </Select>
            </Field>
          </div>
          <Field label="الوصف">
            <Textarea rows={4} value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} placeholder="اشرح الخدمة بوضواح وإيجاز..." />
          </Field>
          <Field label="صورة الخدمة (اختياري)">
            <ImageUpload
              value={form.image ? [{ url: form.image }] : []}
              onChange={(imgs: UploadedImage[]) => setForm((f) => ({ ...f, image: imgs[0]?.url ?? "" }))}
              multiple={false}
              label="ارفع صورة توضيحية"
            />
          </Field>
          <div className="flex items-center justify-between rounded-xl bg-stone-50 px-4 py-3">
            <Switch checked={form.published} onChange={(v) => setForm((f) => ({ ...f, published: v }))} label="نشر الخدمة على الموقع" />
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-stone-500">الترتيب</span>
              <Input type="number" value={form.sort} onChange={(e) => setForm((f) => ({ ...f, sort: Number(e.target.value) || 0 }))} className="!w-20 !py-1.5 text-center" dir="ltr" />
            </div>
          </div>
          <Button className="w-full" size="lg" loading={saving} onClick={save}>{editing ? "حفظ التعديلات" : "إضافة الخدمة"}</Button>
        </div>
      </Modal>
    </div>
  );
}

/* --------------------------------- Areas ---------------------------------- */
type AreaForm = { name: string; description: string; image: string; published: boolean; sort: number };
const emptyArea: AreaForm = { name: "", description: "", image: "", published: true, sort: 0 };

export function AreasManager({ items }: { items: Area[] }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<Area | null>(null);
  const [form, setForm] = useState<AreaForm>(emptyArea);
  const [saving, setSaving] = useState(false);

  function openNew() { setEditing(null); setForm(emptyArea); setOpen(true); }
  function openEdit(a: Area) {
    setEditing(a);
    setForm({ name: a.name, description: a.description, image: a.image, published: a.published, sort: a.sort });
    setOpen(true);
  }

  async function save() {
    if (!form.name.trim()) return toast("أدخل اسم المنطقة", "error");
    setSaving(true);
    try {
      const res = await fetch(editing ? `/api/admin/areas/${editing.id}` : "/api/admin/areas", {
        method: editing ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      if (!res.ok) return toast("فشل حفظ المنطقة", "error");
      toast(editing ? "تم تحديث المنطقة" : "تمت إضافة المنطقة");
      setOpen(false);
      router.refresh();
    } finally { setSaving(false); }
  }

  async function remove(a: Area) {
    if (!window.confirm(`حذف منطقة «${a.name}»؟`)) return;
    const res = await fetch(`/api/admin/areas/${a.id}`, { method: "DELETE" });
    if (!res.ok) return toast("فشل الحذف", "error");
    toast("تم حذف المنطقة");
    router.refresh();
  }

  return (
    <div>
      {items.length === 0 ? (
        <EmptyState
          icon={<MapPin className="h-7 w-7" />}
          title="لم تُضف مناطق بعد"
          description="أضف المناطق التي يغطيها نشاطك (أحياء، مدن، مناطق ساحلية...) لتظهر في قسم «مناطق نخدمها» بالصفحة الرئيسية"
          action={<Button onClick={openNew}><Plus className="h-4 w-4" /> إضافة منطقة</Button>}
        />
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {items.map((a) => (
            <Card key={a.id} className="overflow-hidden">
              <div className="relative h-32 bg-brand-50">
                {a.image ? (
                  <Image src={a.image} alt={a.name} fill className="object-cover" sizes="400px" />
                ) : (
                  <span className="flex h-full items-center justify-center text-brand-300"><MapPin className="h-8 w-8" /></span>
                )}
                <span className="absolute top-2.5 end-2.5"><Badge tone={a.published ? "green" : "stone"}>{a.published ? "ظاهرة" : "مخفية"}</Badge></span>
              </div>
              <div className="p-4">
                <h3 className="text-sm font-extrabold text-ink">{a.name}</h3>
                <p className="mt-1 line-clamp-2 min-h-8 text-xs text-stone-500">{a.description || "بدون وصف"}</p>
                <div className="mt-3 flex justify-end gap-1 border-t border-stone-100 pt-3">
                  <button onClick={() => openEdit(a)} className="cursor-pointer rounded-lg p-2 text-stone-400 hover:bg-stone-100 hover:text-brand-700" aria-label="تعديل"><Pencil className="h-4 w-4" /></button>
                  <button onClick={() => remove(a)} className="cursor-pointer rounded-lg p-2 text-stone-400 hover:bg-red-50 hover:text-red-600" aria-label="حذف"><Trash2 className="h-4 w-4" /></button>
                </div>
              </div>
            </Card>
          ))}
          <button onClick={openNew} className="flex min-h-52 cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-stone-300 text-sm font-bold text-stone-400 transition hover:border-brand-400 hover:text-brand-700">
            <Plus className="h-6 w-6" /> إضافة منطقة جديدة
          </button>
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? "تعديل المنطقة" : "إضافة منطقة"}>
        <div className="space-y-4">
          <Field label="اسم المنطقة">
            <Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="مثال: التجمع الخامس" />
          </Field>
          <Field label="وصف مختصر (اختياري)">
            <Textarea rows={3} value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} placeholder="لماذا هذه المنطقة مميزة؟" />
          </Field>
          <Field label="صورة المنطقة (اختياري)">
            <ImageUpload
              value={form.image ? [{ url: form.image }] : []}
              onChange={(imgs) => setForm((f) => ({ ...f, image: imgs[0]?.url ?? "" }))}
              multiple={false}
              label="ارفع صورة للمنطقة"
              aspect="aspect-video"
            />
          </Field>
          <div className="flex items-center justify-between rounded-xl bg-stone-50 px-4 py-3">
            <Switch checked={form.published} onChange={(v) => setForm((f) => ({ ...f, published: v }))} label="إظهار بالموقع" />
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-stone-500">الترتيب</span>
              <Input type="number" value={form.sort} onChange={(e) => setForm((f) => ({ ...f, sort: Number(e.target.value) || 0 }))} className="!w-20 !py-1.5 text-center" dir="ltr" />
            </div>
          </div>
          <Button className="w-full" size="lg" loading={saving} onClick={save}>{editing ? "حفظ التعديلات" : "إضافة المنطقة"}</Button>
        </div>
      </Modal>
    </div>
  );
}

/* ------------------------------ Property types ----------------------------- */
export function TypesManager({ items }: { items: PropertyType[] }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState("");

  async function add() {
    if (!name.trim()) return;
    setSaving(true);
    try {
      const res = await fetch("/api/admin/types", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim() }),
      });
      const data = await res.json();
      if (!res.ok) return toast(data.error ?? "فشل الإضافة", "error");
      toast("تمت إضافة النوع");
      setName("");
      router.refresh();
    } finally { setSaving(false); }
  }

  async function rename(id: string) {
    if (!editName.trim()) return;
    const res = await fetch(`/api/admin/types/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: editName.trim() }),
    });
    if (!res.ok) return toast("فشل الحفظ", "error");
    toast("تم الحفظ");
    setEditingId(null);
    router.refresh();
  }

  async function remove(id: string, n: string) {
    if (!window.confirm(`حذف نوع «${n}»؟ سيصبح بلا نوع لدى العقارات المرتبطة به.`)) return;
    const res = await fetch(`/api/admin/types/${id}`, { method: "DELETE" });
    if (!res.ok) return toast("فشل الحذف", "error");
    toast("تم الحذف");
    router.refresh();
  }

  return (
    <div className="max-w-2xl space-y-6">
      <Card className="p-5">
        <h2 className="mb-4 text-base font-extrabold text-ink">إضافة نوع جديد</h2>
        <div className="flex gap-2">
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثال: عيادة، رووف، مبنى كامل..." onKeyDown={(e) => e.key === "Enter" && add()} />
          <Button onClick={add} loading={saving}><Plus className="h-4 w-4" /> إضافة</Button>
        </div>
      </Card>

      <Card>
        <div className="border-b border-stone-100 px-5 py-4">
          <h2 className="text-base font-extrabold text-ink">الأنواع الحالية ({items.length})</h2>
        </div>
        {items.length === 0 ? (
          <p className="px-5 py-10 text-center text-sm text-stone-400">لا توجد أنواع بعد</p>
        ) : (
          <ul className="divide-y divide-stone-100">
            {items.map((t) => (
              <li key={t.id} className="flex items-center gap-3 px-5 py-3">
                <GripVertical className="h-4 w-4 text-stone-300" />
                {editingId === t.id ? (
                  <>
                    <Input value={editName} onChange={(e) => setEditName(e.target.value)} className="!py-1.5" onKeyDown={(e) => e.key === "Enter" && rename(t.id)} autoFocus />
                    <Button size="sm" onClick={() => rename(t.id)}>حفظ</Button>
                    <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>إلغاء</Button>
                  </>
                ) : (
                  <>
                    <span className="flex-1 text-sm font-bold text-ink">{t.name}</span>
                    <span className="text-xs text-stone-300" dir="ltr">{t.slug}</span>
                    <button onClick={() => { setEditingId(t.id); setEditName(t.name); }} className="cursor-pointer rounded-lg p-2 text-stone-400 hover:bg-stone-100 hover:text-brand-700" aria-label="إعادة تسمية">
                      <Pencil className="h-4 w-4" />
                    </button>
                    <button onClick={() => remove(t.id, t.name)} className="cursor-pointer rounded-lg p-2 text-stone-400 hover:bg-red-50 hover:text-red-600" aria-label="حذف">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </>
                )}
              </li>
            ))}
          </ul>
        )}
      </Card>

      <div className="flex items-start gap-3 rounded-2xl border border-brand-200 bg-brand-50 p-4 text-xs leading-relaxed text-brand-800">
        <Shapes className="mt-0.5 h-4 w-4 shrink-0" />
        أنواع العقارات تُستخدم في تصنيف العقارات وفي فلاتر البحث بالموقع العام. أضف فقط الأنواع التي تتعامل فيها فعليًا.
      </div>
    </div>
  );
}
