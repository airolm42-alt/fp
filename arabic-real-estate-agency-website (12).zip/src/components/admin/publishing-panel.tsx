"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowUpRight, Check, CheckCircle2, Copy, Download, Globe2, Info, Link2, LockKeyhole, Server, TriangleAlert } from "lucide-react";
import { Button, Card, EmptyState, Field, Input, toast } from "@/components/ui";
import { SITE_LINKS, configuredProductionOrigin, siteLink } from "@/lib/site-origin";
import { PagesExportPanel } from "@/components/admin/pages-export-panel";

export type PublishingCheck = { label: string; ready: boolean; description: string };

type Props = {
  baseUrl: string;
  configuredUrl: string;
  backendOrigin: string;
  kind: "preview" | "local" | "public";
  canManage: boolean;
  checks: PublishingCheck[];
};

const STEPS = [
  { title: "انشر ملفات الموقع", text: "ارفع مشروعك إلى مستودع GitHub خاص، ثم اختر New Project ← Deploy from GitHub repo في Railway. لا ترفع ملف البيئة أو مفاتيح الدخول." },
  { title: "احتفظ ببياناتك وصورك", text: "أضف PostgreSQL، واربط DATABASE_URL بخدمة الموقع. اربط أيضًا Volume للصور واضبط UPLOAD_DIR إلى مسار التخزين الدائم. تفعيل الرابط وحده لا يحفظ البيانات." },
  { title: "ولّد رابط الإنتاج مرة واحدة", text: "بعد نجاح النشر: افتح خدمة الموقع ← Settings ← Networking ← Public Networking ← Generate Domain. أبقِ نفس الخدمة والنطاق عند تحديث الموقع." },
  { title: "اربط دومينك إن أردت", text: "من نفس القسم اختر Custom Domain، ثم أضف سجلات DNS التي تعرضها الاستضافة في حساب الدومين. حافظ على تجديد الدومين وخطة الاستضافة." },
  { title: "احفظ العنوان النهائي هنا", text: "بعد أن يفتح الدومين موقعك بالفعل، احفظه هنا. رابط الإدارة دائمًا هو نفس الدومين متبوعًا بـ /admin، وليس موقعًا منفصلًا." },
];

export function PublishingPanel({ baseUrl, configuredUrl, backendOrigin, kind, canManage, checks }: Props) {
  const [domain, setDomain] = useState(configuredUrl);
  const [saving, setSaving] = useState(false);
  const [downloadingSource, setDownloadingSource] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const router = useRouter();
  const isPreview = kind !== "public";
  const productionUrl = configuredProductionOrigin(configuredUrl);

  async function copy(text: string, key: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      window.setTimeout(() => setCopied((current) => current === key ? null : current), 1800);
      toast("تم نسخ الرابط");
    } catch {
      toast("تعذّر النسخ تلقائيًا. حدّد الرابط وانسخه من الحقل.", "error");
    }
  }

  async function downloadSource() {
    setDownloadingSource(true);
    try {
      const response = await fetch("/api/admin/publishing/source", { cache: "no-store" });
      if (!response.ok) {
        const data = await response.json().catch(() => null);
        return toast(data?.error ?? "تعذّر تنزيل مصدر المشروع", "error");
      }
      if (!response.headers.get("Content-Type")?.includes("application/zip")) {
        return toast("رد التنزيل ليس حزمة ZIP صالحة", "error");
      }
      const count = response.headers.get("X-Source-File-Count");
      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = "arabic-real-estate-source.zip";
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
      toast(count ? `حزمة ${count} ملفًا جاهزة. افحص قائمة البصمات بعد فك الضغط.` : "الحزمة جاهزة. افحصها بعد فك الضغط.");
    } catch {
      toast("تعذّر الاتصال أو تنزيل الملف. حاول مرة أخرى.", "error");
    } finally {
      setDownloadingSource(false);
    }
  }

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch("/api/admin/publishing", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ siteUrl: domain }),
      });
      const data = await res.json();
      if (!res.ok) return toast(data.error ?? "تعذّر حفظ الرابط", "error");
      setDomain(data.siteUrl ?? "");
      toast("تم حفظ العنوان. هذا يحدّث الروابط ولا يقوم بالنشر أو ربط DNS.");
      router.refresh();
    } catch {
      toast("تعذّر الاتصال بالخادم", "error");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="max-w-5xl space-y-6">
      <section className="relative overflow-hidden rounded-3xl bg-brand-950 p-6 text-white pattern-arabesque sm:p-8">
        <div className="relative flex flex-col items-start justify-between gap-5 sm:flex-row">
          <div>
            <span className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-gold-400 text-brand-950"><Link2 className="h-6 w-6" /></span>
            <h2 className="text-2xl font-black">عنوان واحد. كل روابطك.</h2>
            <p className="mt-2 max-w-xl text-sm leading-loose text-brand-100/70">انشر الموقع مرة واحدة، ثم احتفظ بنفس الدومين. تحديث المحتوى والكود لا يتطلب تغيير عنوان الموقع أو عنوان الإدارة.</p>
          </div>
          <span className={`shrink-0 rounded-full px-3 py-1.5 text-xs font-bold ${isPreview ? "bg-gold-400/15 text-gold-200" : "bg-white/10 text-white"}`}>
            {isPreview ? "عنوان معاينة — ليس نشرًا دائمًا" : configuredUrl ? "عنوان إنتاج محفوظ — تحقق من فتحه" : "عنوان عام مكتشف"}
          </span>
        </div>
        <p className="relative mt-5 break-all rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-left text-sm font-semibold text-gold-200" dir="ltr">{baseUrl}</p>
      </section>

      {isPreview && (
        <div className="flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-relaxed text-amber-900">
          <TriangleAlert className="mt-0.5 h-5 w-5 shrink-0" />
          <p>العنوان الحالي للمعاينة فقط. لا يوجد حتى الآن ما يثبت نشر النسخة على استضافة دائمة. لا ترسل هذا العنوان لجوجل باعتباره الدومين النهائي.</p>
        </div>
      )}

      <Card className="p-5 sm:p-6">
        <section id="complete-source" aria-labelledby="complete-source-title" className="scroll-mt-24">
          <div className="mb-4 flex items-start gap-3">
            <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-brand-700 text-gold-300"><Download className="h-5 w-5" /></span>
            <div>
              <h2 id="complete-source-title" className="text-lg font-extrabold">تحميل المشروع كاملًا ZIP</h2>
              <p className="mt-1 text-xs leading-relaxed text-stone-500">مصدر الموقع والإدارة والـAPI في حزمة واحدة للمالك، مع فحص كامل لكل ملف بعد التنزيل.</p>
            </div>
          </div>
          <div className="rounded-2xl border border-gold-200 bg-gold-50/60 p-4 text-sm leading-loose text-ink-soft">
            <p className="font-bold text-brand-900">مش لاقي index.html؟ ده طبيعي هنا.</p>
            <p>المشروع Next.js، والصفحة الرئيسية في <span dir="ltr" className="font-mono text-xs">src/app/(site)/page.tsx</span>. HTML يتولد من الخادم. فتح ملف بالنقر المزدوج أو رفع الملفات لاستضافة ثابتة لا يشغّل قاعدة البيانات أو تسجيل الدخول.</p>
          </div>
          <ul className="mt-4 space-y-2 text-xs leading-loose text-stone-600">
            <li>الحزمة تضم كل <span dir="ltr" className="font-mono">src/</span> و<span dir="ltr" className="font-mono">public/</span> و<span dir="ltr" className="font-mono">scripts/</span>، وملفات الإعداد وملف القفل والقوالب المخفية الآمنة.</li>
            <li>فك الضغط بالكامل، وافتح <span dir="ltr" className="font-mono">START-HERE.html</span> للدليل. هذا الملف للتعليمات فقط، وليس نسخة ثابتة من الموقع.</li>
            <li>من داخل مجلد المشروع نفّذ <span dir="ltr" className="font-mono">node scripts/verify-download.mjs</span> قبل التعديل؛ يتحقق من كل ملف وبصمته في <span dir="ltr" className="font-mono">PROJECT-MANIFEST.json</span>.</li>
            <li>قائمة <span dir="ltr" className="font-mono">PROJECT-FILES.json</span> تحدد كل ملفات التسليم والمسارات المطلوبة، حتى الصفحات غير المستوردة. بعد تثبيت الحزم نفّذ <span dir="ltr" className="font-mono">node scripts/check-source.mjs</span> لفحص الاستيرادات وتبعيات الكود.</li>
          </ul>
          <p className="mt-4 rounded-xl bg-stone-50 px-4 py-3 text-xs leading-loose text-stone-500">لأمانك لا تضم الحزمة أسرار <span dir="ltr" className="font-mono">.env</span> أو قاعدة العملاء أو الصور المرفوعة. ولا تضم <span dir="ltr" className="font-mono">node_modules</span> و<span dir="ltr" className="font-mono">.next</span>؛ يتولدان عند التثبيت والبناء. نقل بيانات العمل يحتاج نسخة احتياطية مستقلة.</p>
          <div className="mt-5 flex flex-wrap items-center gap-3">
            {canManage ? <Button onClick={downloadSource} loading={downloadingSource}><Download className="h-4 w-4" /> تنزيل المصدر كاملًا ZIP</Button> : <p className="flex items-center gap-2 text-xs font-semibold text-stone-500"><LockKeyhole className="h-4 w-4" /> تنزيل المصدر متاح للمالك فقط.</p>}
            <a href="/api/admin/publishing/guide" className="text-sm font-bold text-brand-700 hover:text-brand-900">تحميل دليل النشر</a>
          </div>
        </section>
      </Card>

      <PagesExportPanel backendOrigin={backendOrigin} canManage={canManage} />

      <Card className="p-5 sm:p-6">
        <section id="github-pages-compatibility" aria-labelledby="github-pages-title" className="scroll-mt-24">
          <span className="mb-3 inline-flex items-center gap-1.5 rounded-full bg-gold-50 px-3 py-1 text-xs font-bold text-gold-800"><Info className="h-3.5 w-3.5" /> توضيح قبل اختيار الاستضافة</span>
          <h2 id="github-pages-title" className="text-lg font-extrabold">GitHub Pages للواجهة، والخادم للبيانات</h2>
          <p className="mt-2 text-sm leading-loose text-stone-600">أُضيفت واجهة عامة ثابتة منفصلة في github-pages وتُبنى إلى out-pages. تعرض المنشور وتبحث وتقرأ التفاصيل من API الخادم، وترسل الاستفسارات بعد تفعيل أصل الواجهة. النسخة الكاملة والإدارة لا تتحولان إلى HTML؛ يبقيان على خادم Next.js وقاعدة PostgreSQL وتخزين دائم.</p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border border-brand-200 bg-brand-50/50 p-4"><h3 className="text-sm font-bold text-brand-900">المسار المناسب</h3><p className="mt-2 text-xs leading-loose text-stone-600">نزّل المصدر الكامل، وارفع محتويات المجلد إلى مستودع GitHub خاص بحيث يكون package.json في الجذر، ثم اربطه باستضافة تدعم Node.js. لا ترفع .env أو أسرار الحسابات.</p></div>
            <div className="rounded-2xl border border-stone-200 bg-stone-50 p-4"><h3 className="text-sm font-bold text-ink">ارفع out-pages فقط، وليس المستودع كله</h3><p className="mt-2 text-xs leading-loose text-stone-600">ملف GitHub Actions المرفق يبني الواجهة المنفصلة ويحمّل المخرجات الثابتة فقط. اضبط PAGES_API_URL واربط استضافتك؛ لا تضف أسرار .env للواجهة. لا تُغيّر إعداد Next.js إلى output: export. شروط Pages للاستخدام التجاري والمعاملات الحساسة ما زالت واجبة المراجعة.</p></div>
          </div>
          <div className="mt-4 flex flex-wrap gap-x-5 gap-y-3 text-sm font-bold">
            <a href="https://github.com/new" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-brand-700 hover:text-brand-900">إنشاء مستودع GitHub <ArrowUpRight className="h-4 w-4" /></a>
            <a href="https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-ink-soft hover:text-brand-700">ما الذي تدعمه Pages؟ <ArrowUpRight className="h-4 w-4" /></a>
            <a href="/api/admin/publishing/guide" className="inline-flex items-center gap-1 text-ink-soft hover:text-brand-700"><Download className="h-4 w-4" /> دليل GitHub والاستضافة الكاملة</a>
          </div>
        </section>
      </Card>

      <Card className="p-5 sm:p-6">
        <section id="without-custom-domain" aria-labelledby="without-custom-domain-title" className="scroll-mt-24">
          <span className="mb-3 inline-flex items-center gap-1.5 rounded-full bg-brand-50 px-3 py-1 text-xs font-bold text-brand-700"><Globe2 className="h-3.5 w-3.5" /> شراء دومين خاص اختياري</span>
          <h2 id="without-custom-domain-title" className="text-lg font-extrabold">معندكش دومين؟ تقدر تنشر برابط الاستضافة</h2>
          <p className="mt-2 text-sm leading-loose text-stone-600">Railway يوفر عنوانًا لخدمة الإنتاج ينتهي بـ <span dir="ltr" className="font-mono text-brand-800">.up.railway.app</span>. لا تحتاج شراء دومين منفصل أو إعداد DNS لهذا العنوان. لكنه ليس رابطًا تم إنشاؤه لهذا المشروع حتى الآن.</p>
          <ol className="mt-5 space-y-3 text-sm leading-relaxed">
            <li className="flex items-start gap-3"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-gold-100 text-xs font-black text-gold-800">1</span><p>صدّر ملفات المشروع إلى جهازك وارفعها إلى مستودع GitHub خاص، من غير ملف البيئة أو الأسرار.</p></li>
            <li className="flex items-start gap-3"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-gold-100 text-xs font-black text-gold-800">2</span><p>في Railway اختر <span dir="ltr" className="font-semibold">New Project → Deploy from GitHub repo</span>. جهّز قاعدة PostgreSQL وتخزين الصور الدائم ومتغيرات البيئة والجداول كما هو موضّح في دليل النشر.</p></li>
            <li className="flex items-start gap-3"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-gold-100 text-xs font-black text-gold-800">3</span><p>بعد نجاح النشر افتح خدمة الموقع، وليس خدمة قاعدة البيانات، ثم <span dir="ltr" className="font-semibold">Settings → Networking → Public Networking → Generate Domain</span>. هذا هو المكان الذي يصدر رابطك.</p></li>
            <li className="flex items-start gap-3"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-gold-100 text-xs font-black text-gold-800">4</span><p>افتح الرابط الناتج وتأكد من عمل الموقع والدخول، ثم احفظه في «عنوان الإنتاج» بالأسفل. رابط الإدارة هو نفس الرابط مع إضافة <span dir="ltr" className="font-mono">/admin</span>. لا تحذف النطاق أو تعِد توليده مع كل تحديث.</p></li>
          </ol>
          <div className="mt-5 rounded-xl border border-gold-200 bg-gold-50 p-3.5 text-xs leading-loose text-gold-900">عدم شراء دومين لا يعني أن تشغيل الموقع مجاني. Railway يحاسب على الخطة والموارد؛ اختر ما يناسبك من صفحة الأسعار. بقاء الرابط يعمل يحتاج خدمة نشطة وتخزينًا مستمرًا، وليس تجربة منتهية أو خدمة محذوفة.</div>
          <div className="mt-4 flex flex-wrap gap-x-5 gap-y-3 text-sm font-bold">
            <a href="https://railway.com/new" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-brand-700 hover:text-brand-900">إنشاء مشروع في Railway <ArrowUpRight className="h-4 w-4" /></a>
            <a href="https://railway.com/pricing" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 text-ink-soft hover:text-brand-700">راجع الأسعار قبل النشر <ArrowUpRight className="h-4 w-4" /></a>
            <a href="/api/admin/publishing/guide" className="inline-flex items-center gap-1 text-ink-soft hover:text-brand-700"><Download className="h-4 w-4" /> دليل إعداد قاعدة البيانات والصور</a>
          </div>
        </section>
      </Card>

      <Card className="p-5 sm:p-6">
        <section id="platform-publishing" aria-labelledby="platform-publishing-title" className="scroll-mt-24">
          <div className="mb-4 flex items-start gap-3">
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-700"><Info className="h-5 w-5" /></span>
            <div>
              <h2 id="platform-publishing-title" className="text-base font-extrabold">هل يمكن النشر من هذه المنصة؟</h2>
              <p className="mt-1 text-xs leading-relaxed text-stone-500">هناك فرق بين منصة إنشاء المشروع ولوحة إدارة موقعك.</p>
            </div>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-2xl border border-stone-200 bg-stone-50/60 p-4">
              <h3 className="text-sm font-bold text-brand-900">من صفحة المشروع في المنصة</h3>
              <p className="mt-2 text-xs leading-loose text-stone-600">إذا كانت منصتك تعرض خيار «نشر» أو Publish أو Deploy، افتحه واتبع تعليماتها لإصدار عنوان إنتاج ثابت. لا يمكن لهذا الموقع التأكد من توفر الزر أو مكانه في واجهة المنصة، ولا يصدر رابطًا دائمًا من تشغيل المعاينة وحده.</p>
            </div>
            <div className="rounded-2xl border border-gold-200 bg-gold-50/60 p-4">
              <h3 className="text-sm font-bold text-gold-800">من لوحة إدارة الموقع</h3>
              <p className="mt-2 text-xs leading-loose text-stone-600">هذه الصفحة تحفظ الدومين الذي نشرته بالفعل، وتجهّز روابط الموقع والإدارة ومحركات البحث. لا يوجد اتصال مخوّل بحساب استضافة لإصدار نطاق جديد أو شراء دومين من داخل اللوحة.</p>
            </div>
          </div>
          <details className="mt-4 rounded-xl border border-stone-200 px-4 py-3">
            <summary className="cursor-pointer text-sm font-bold text-brand-800">إذا لم يظهر خيار نشر في المنصة؟</summary>
            <p className="mt-3 text-xs leading-loose text-stone-600">راجع تعليمات المنصة أو دعمها للتأكد أنها توفر نشرًا دائمًا. إذا كانت للمعاينة فقط، استخدم الاستضافة المذكورة في الدليل بالأسفل. لا تحفظ عنوان المعاينة باعتباره دومين الإنتاج.</p>
          </details>
        </section>
      </Card>

      <Card className="p-5 sm:p-6">
        <h2 className="mb-1 flex items-center gap-2 text-base font-extrabold"><Globe2 className="h-5 w-5 text-brand-600" /> عنوان الإنتاج</h2>
        <p className="mb-5 text-sm leading-relaxed text-stone-500">استخدم الرابط الذي أصدرته الاستضافة بعد النشر، أو دومينك الخاص إن كان لديك. شراء دومين ليس مطلوبًا. الكتابة هنا تحفظ العنوان فقط؛ لا تنشئ خدمة استضافة ولا تنشر الموقع.</p>
        <form onSubmit={save} className="space-y-4">
          <Field label="الدومين الذي نشرته بالفعل" hint="يمكن استخدام نطاق Railway المولّد دون شراء دومين. أدخل العنوان دون /admin أو مسار آخر، أو اتركه فارغًا للاكتشاف التلقائي.">
            <Input aria-label="الدومين الذي نشرته بالفعل" value={domain} onChange={(e) => setDomain(e.target.value)} disabled={!canManage} placeholder="https://your-domain.com — مثال فقط" dir="ltr" className="text-left" maxLength={2048} />
          </Field>
          {canManage ? <Button type="submit" loading={saving}>حفظ عنوان الإنتاج</Button> : <p className="flex items-center gap-2 text-xs font-semibold text-stone-500"><LockKeyhole className="h-4 w-4" /> تعديل الدومين متاح للمالك فقط.</p>}
        </form>
      </Card>

      <section aria-labelledby="production-links-title">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 id="production-links-title" className="text-lg font-extrabold">روابط الإنتاج</h2>
            <p className="mt-1 text-xs leading-relaxed text-stone-500">
              {productionUrl
                ? "روابط مولّدة من الدومين المضبوط. لم تتحقق هذه الصفحة من DNS أو نشر الموقع عليه؛ افتحها وتأكد قبل إرسالها للعملاء."
                : "لن تظهر عناوين المعاينة المؤقتة في قائمة روابط الإنتاج."}
            </p>
          </div>
          {productionUrl && (
            <Button variant="outline" size="sm" onClick={() => copy(SITE_LINKS.map((item) => `${item.label}: ${siteLink(productionUrl, item.path)}`).join("\n"), "all")}>
              <Copy className="h-4 w-4" /> نسخ روابط الدومين المضبوط
            </Button>
          )}
        </div>
        {productionUrl ? (
          <div className="grid gap-3 sm:grid-cols-2">
            {SITE_LINKS.map((item) => {
              const url = siteLink(productionUrl, item.path);
              return <Card key={item.path} className="p-4">
                <div className="mb-3 flex items-center justify-between"><p className="text-sm font-bold">{item.label}</p><a href={url} target="_blank" rel="noopener noreferrer" aria-label={`فتح ${item.label}`} className="rounded-lg p-1.5 text-stone-400 hover:bg-brand-50 hover:text-brand-700"><ArrowUpRight className="h-4 w-4" /></a></div>
                <div className="flex items-center gap-2"><Input readOnly value={url} dir="ltr" aria-label={`رابط ${item.label}`} className="min-w-0 bg-stone-50 !py-2 text-left !text-xs" onFocus={(e) => e.target.select()} /><Button variant="outline" size="icon" onClick={() => copy(url, item.path)} aria-label={`نسخ رابط ${item.label}`}>{copied === item.path ? <Check className="h-4 w-4 text-brand-600" /> : <Copy className="h-4 w-4" />}</Button></div>
              </Card>;
            })}
          </div>
        ) : (
          <EmptyState
            icon={<Link2 className="h-7 w-7" />}
            title="لا توجد روابط نهائية حتى الآن"
            description="لم يُضبط دومين إنتاج لهذا المشروع. يلزم نشر الموقع على استضافة ثابتة وربط الدومين أولًا. تشغيل المعاينة أو حفظ اسم دومين لا يقوم بالنشر."
          />
        )}
      </section>

      <div className="grid gap-6 lg:grid-cols-5">
        <Card className="p-5 sm:p-6 lg:col-span-3">
          <div className="mb-5 flex items-center gap-2"><Server className="h-5 w-5 text-brand-600" /><h2 className="text-base font-extrabold">الطريقة المقترحة: Railway</h2></div>
          <ol className="space-y-5">{STEPS.map((step, i) => <li key={step.title} className="flex items-start gap-3"><span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-gold-100 text-xs font-black text-gold-800">{i + 1}</span><div><h3 className="text-sm font-bold">{step.title}</h3><p className="mt-1 text-xs leading-loose text-stone-500">{step.text}</p></div></li>)}</ol>
          <div className="mt-6 flex flex-wrap gap-3 border-t border-stone-100 pt-5"><a href="https://railway.com/new" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1.5 text-sm font-bold text-brand-700">فتح حساب الاستضافة <ArrowUpRight className="h-4 w-4" /></a><a href="/api/admin/publishing/guide" className="inline-flex items-center gap-1.5 text-sm font-bold text-ink-soft"><Download className="h-4 w-4" /> تحميل دليل النشر</a></div>
        </Card>

        <div className="space-y-4 lg:col-span-2">
          <Card className="p-5 sm:p-6"><h2 className="mb-4 text-base font-extrabold">قبل اعتماد الدومين</h2><ul className="space-y-4">{checks.map((check) => <li key={check.label} className="flex items-start gap-2.5">{check.ready ? <CheckCircle2 className="mt-0.5 h-4.5 w-4.5 shrink-0 text-brand-600" /> : <Info className="mt-0.5 h-4.5 w-4.5 shrink-0 text-gold-600" />}<div><p className="text-xs font-bold">{check.label}</p><p className="mt-1 text-[11px] leading-relaxed text-stone-500">{check.description}</p></div></li>)}</ul></Card>
          <div className="rounded-2xl border border-stone-200 bg-white p-5 text-xs leading-loose text-stone-600">هذه فحوص إعدادات محلية، وليست إثباتًا لملكية الدومين أو اتصال DNS. الاستضافة قد تكون مدفوعة، ويظل الرابط فعالًا ما دامت الخدمة والدومين نشطين.</div>
          <Link href="/admin/seo" className="block rounded-2xl bg-brand-50 px-5 py-4 text-sm font-bold text-brand-800">بعد النشر: إعدادات SEO وتوثيق Google ←</Link>
        </div>
      </div>
    </div>
  );
}
