"use client";

import { useCallback, useEffect, useState } from "react";
import {
  UserPlus,
  Trash2,
  KeyRound,
  ShieldCheck,
  Crown,
  Loader2,
  Copy,
  Check,
  Lock,
} from "lucide-react";
import { Badge, Button, Card, EmptyState, Field, Input, Modal, Switch, toast, FormAlert } from "@/components/ui";
import { formatDate } from "@/lib/utils";

type TeamMember = {
  id: string;
  name: string;
  email: string;
  isOwner: boolean;
  mustChangePassword: boolean;
  lastLoginAt: string | null;
  createdAt: string;
};

function generatePassword() {
  const chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ";
  const digits = "23456789";
  const random = crypto.getRandomValues(new Uint32Array(16));
  let out = "";
  for (let i = 0; i < 12; i++) out += chars[random[i] % chars.length];
  for (let i = 12; i < 16; i++) out += digits[random[i] % digits.length];
  return out;
}

export function TeamManager() {
  const [items, setItems] = useState<TeamMember[]>([]);
  const [currentId, setCurrentId] = useState("");
  const [isOwner, setIsOwner] = useState(false);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", password: "", mustChangePassword: true });
  const [resetFor, setResetFor] = useState<TeamMember | null>(null);
  const [resetPassword, setResetPassword] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/admin/team", { cache: "no-store" });
      const data = await res.json();
      if (res.ok) {
        setItems(data.items);
        setCurrentId(data.currentId);
        setIsOwner(data.isOwner);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { const timer = window.setTimeout(() => { void load(); }, 0); return () => window.clearTimeout(timer); }, [load]);

  function openNew() {
    setForm({ name: "", email: "", password: generatePassword(), mustChangePassword: true });
    setCopied(false);
    setOpen(true);
  }

  async function create() {
    if (!form.name.trim() || !form.email.trim() || !form.password) {
      return toast("أكمل جميع الحقول", "error");
    }
    setSaving(true);
    try {
      const res = await fetch("/api/admin/team", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) return toast(data.error ?? "فشل إضافة المشرف", "error");
      toast("تم إنشاء حساب المشرف بنجاح");
      setOpen(false);
      load();
    } finally { setSaving(false); }
  }

  async function remove(m: TeamMember) {
    if (!window.confirm(`إلغاء صلاحية المشرف «${m.name}» (${m.email})؟ لن يتمكن من الدخول بعد الآن.`)) return;
    const res = await fetch(`/api/admin/team/${m.id}`, { method: "DELETE" });
    const data = await res.json();
    if (!res.ok) return toast(data.error ?? "فشل الحذف", "error");
    toast("تم إلغاء صلاحية المشرف");
    load();
  }

  async function doReset() {
    if (!resetFor) return;
    if (resetPassword.length < 12) return toast("كلمة المرور 12 حرفًا على الأقل", "error");
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/team/${resetFor.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: resetPassword }),
      });
      const data = await res.json();
      if (!res.ok) return toast(data.error ?? "فشل إعادة التعيين", "error");
      toast("تم تعيين كلمة مرور جديدة — سلّمها للمشرف");
      setResetFor(null);
      load();
    } finally { setSaving(false); }
  }

  async function copyCredentials() {
    try {
      await navigator.clipboard.writeText(
        `رابط الدخول: ${location.origin}/admin\nالبريد: ${form.email}\nكلمة المرور: ${form.password}`,
      );
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      toast("تم نسخ بيانات الدخول");
    } catch {
      toast("تعذر النسخ", "error");
    }
  }

  if (loading) {
    return <div className="flex justify-center py-20 text-brand-600"><Loader2 className="h-8 w-8 animate-spin" /></div>;
  }

  return (
    <div className="max-w-4xl space-y-6">
      {!isOwner && (
        <div className="flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs leading-relaxed font-semibold text-amber-800">
          <Lock className="mt-0.5 h-4 w-4 shrink-0" />
          أنت مشرف عادي — يمكنك الاطلاع على الفريق فقط. إضافة أو إزالة المشرفين صلاحية حصرية للمالك الأساسي.
        </div>
      )}

      <Card>
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-stone-100 px-5 py-4">
          <div>
            <h2 className="text-base font-extrabold text-ink">فريق الإدارة ({items.length})</h2>
            <p className="mt-0.5 text-xs text-stone-500">الحسابات التي يمكنها الدخول للوحة التحكم</p>
          </div>
          {isOwner && (
            <Button onClick={openNew}>
              <UserPlus className="h-4 w-4" /> إضافة مشرف
            </Button>
          )}
        </div>

        {items.length === 0 ? (
          <EmptyState title="لا يوجد مشرفون" />
        ) : (
          <ul className="divide-y divide-stone-100">
            {items.map((m) => (
              <li key={m.id} className="flex flex-wrap items-center gap-3 px-5 py-4">
                <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-black text-white ${m.isOwner ? "bg-gold-500 text-brand-950" : "bg-brand-700"}`}>
                  {m.name.slice(0, 1)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="flex flex-wrap items-center gap-2 text-sm font-extrabold text-ink">
                    {m.name}
                    {m.isOwner && <Badge tone="gold"><Crown className="h-3 w-3" /> المالك</Badge>}
                    {m.id === currentId && <Badge tone="brand">أنت</Badge>}
                    {m.mustChangePassword && !m.isOwner && <Badge tone="stone">بانتظار تغيير كلمة المرور</Badge>}
                  </p>
                  <p className="mt-0.5 truncate text-xs text-stone-500" dir="ltr">{m.email}</p>
                  <p className="mt-0.5 text-[11px] text-stone-400">
                    {m.lastLoginAt ? `آخر دخول: ${formatDate(m.lastLoginAt)}` : "لم يسجّل الدخول بعد"}
                  </p>
                </div>
                {isOwner && !m.isOwner && m.id !== currentId && (
                  <div className="flex gap-1">
                    <button
                      onClick={() => { setResetFor(m); setResetPassword(generatePassword()); }}
                      title="إعادة تعيين كلمة المرور"
                      className="cursor-pointer rounded-lg p-2 text-stone-400 transition hover:bg-stone-100 hover:text-brand-700"
                    >
                      <KeyRound className="h-4.5 w-4.5" />
                    </button>
                    <button
                      onClick={() => remove(m)}
                      title="إلغاء الصلاحية"
                      className="cursor-pointer rounded-lg p-2 text-stone-400 transition hover:bg-red-50 hover:text-red-600"
                    >
                      <Trash2 className="h-4.5 w-4.5" />
                    </button>
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </Card>

      <div className="flex items-start gap-3 rounded-2xl border border-brand-200 bg-brand-50 p-4 text-xs leading-relaxed text-brand-800">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
        <span>
          حساب <span className="font-black">المالك</span> لا يمكن حذفه أو تعديله من أي مشرف آخر، وهو وحده من يملك صلاحية
          إضافة وإزالة المشرفين. سلّم بيانات الدخول يدويًا للمشرف الجديد واطلب منه تغيير كلمة المرور بعد أول دخول.
        </span>
      </div>

      {/* Create modal */}
      <Modal open={open} onClose={() => setOpen(false)} title="إضافة مشرف جديد">
        <div className="space-y-4">
          <FormAlert type="success" message="سيتم إنشاء الحساب فورًا — انسخ البيانات وسلّمها للمشرف." />
          <Field label="اسم المشرف">
            <Input value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="مثال: محمد علي" />
          </Field>
          <Field label="البريد الإلكتروني">
            <Input type="email" value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="name@example.com" dir="ltr" className="text-left" />
          </Field>
          <Field label="كلمة المرور المبدئية" hint="12 حرفًا على الأقل وتحتوي حرفًا ورقمًا">
            <div className="flex gap-2">
              <Input value={form.password} onChange={(e) => setForm((f) => ({ ...f, password: e.target.value }))} dir="ltr" className="text-left font-mono" />
              <Button type="button" variant="outline" onClick={() => setForm((f) => ({ ...f, password: generatePassword() }))}>
                توليد
              </Button>
            </div>
          </Field>
          <div className="rounded-xl bg-stone-50 px-4 py-3">
            <Switch
              checked={form.mustChangePassword}
              onChange={(v) => setForm((f) => ({ ...f, mustChangePassword: v }))}
              label="مطالبته بتغيير كلمة المرور بعد أول دخول"
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline" className="flex-1" onClick={copyCredentials} type="button">
              {copied ? <Check className="h-4 w-4 text-emerald-600" /> : <Copy className="h-4 w-4" />}
              نسخ البيانات
            </Button>
            <Button className="flex-1" loading={saving} onClick={create}>
              إنشاء الحساب
            </Button>
          </div>
        </div>
      </Modal>

      {/* Reset password modal */}
      <Modal open={!!resetFor} onClose={() => setResetFor(null)} title={`إعادة تعيين كلمة مرور: ${resetFor?.name ?? ""}`}>
        <div className="space-y-4">
          <Field label="كلمة المرور الجديدة">
            <div className="flex gap-2">
              <Input value={resetPassword} onChange={(e) => setResetPassword(e.target.value)} dir="ltr" className="text-left font-mono" />
              <Button type="button" variant="outline" onClick={() => setResetPassword(generatePassword())}>توليد</Button>
            </div>
          </Field>
          <Button className="w-full" loading={saving} onClick={doReset}>تأكيد إعادة التعيين</Button>
        </div>
      </Modal>
    </div>
  );
}
