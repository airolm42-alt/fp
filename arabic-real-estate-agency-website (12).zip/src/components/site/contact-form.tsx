"use client";

import { useState } from "react";
import { Send, CheckCircle2 } from "lucide-react";
import { Button, Field, FormAlert, Input, Textarea } from "@/components/ui";

export function ContactForm({
  propertyId,
  propertyTitle,
  compact,
}: {
  propertyId?: string;
  propertyTitle?: string;
  compact?: boolean;
}) {
  const [form, setForm] = useState({ name: "", phone: "", email: "", message: "" });
  const [error, setError] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setSending(true);
    try {
      const res = await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, propertyId: propertyId ?? null, website: (new FormData(e.currentTarget as HTMLFormElement).get("website") as string) ?? "" }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "حدث خطأ — حاول مرة أخرى");
        return;
      }
      setSent(true);
    } catch {
      setError("حدث خطأ في الاتصال — حاول مرة أخرى");
    } finally {
      setSending(false);
    }
  }

  if (sent) {
    return (
      <div className="flex flex-col items-center rounded-2xl border border-emerald-200 bg-emerald-50 px-6 py-10 text-center">
        <CheckCircle2 className="mb-3 h-12 w-12 text-emerald-600" />
        <p className="text-lg font-black text-emerald-800">تم إرسال رسالتك بنجاح</p>
        <p className="mt-1.5 text-sm text-emerald-700/80">سيتواصل معك فريقنا في أقرب وقت ممكن</p>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div aria-hidden="true" className="sr-only">
        <label htmlFor={`contact-website-${propertyId ?? "general"}`}>اترك هذا الحقل فارغًا</label>
        <input id={`contact-website-${propertyId ?? "general"}`} type="text" name="website" tabIndex={-1} autoComplete="off" />
      </div>
      {error && <FormAlert type="error" message={error} />}
      {propertyTitle && (
        <div className="rounded-xl bg-brand-50 px-4 py-3 text-sm font-bold text-brand-800 ring-1 ring-brand-600/15">
          استفسار عن عقار: {propertyTitle}
        </div>
      )}
      <div className={compact ? "space-y-4" : "grid gap-4 sm:grid-cols-2"}>
        <Field label="الاسم بالكامل">
          <Input required minLength={2} maxLength={120} value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="اكتب اسمك" />
        </Field>
        <Field label="رقم الهاتف">
          <Input required minLength={6} maxLength={30} value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} placeholder="01xxxxxxxxx" dir="ltr" className="text-right" inputMode="tel" />
        </Field>
      </div>
      <Field label="البريد الإلكتروني (اختياري)">
        <Input type="email" maxLength={200} value={form.email} onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} placeholder="you@example.com" dir="ltr" className="text-right" />
      </Field>
      <Field label="رسالتك">
        <Textarea
          required
          minLength={5}
          maxLength={3000}
          rows={compact ? 4 : 5}
          value={form.message}
          onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))}
          placeholder={propertyTitle ? `مرحبًا، أنا مهتم بهذا العقار وأريد معرفة المزيد من التفاصيل...` : "كيف يمكننا مساعدتك؟"}
        />
      </Field>
      <Button type="submit" size="lg" className="w-full" loading={sending}>
        <Send className="h-4.5 w-4.5" />
        إرسال الرسالة
      </Button>
    </form>
  );
}
