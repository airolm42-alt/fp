import Image from "next/image";
import QRCode from "qrcode";
import { Star, ExternalLink, Settings2 } from "lucide-react";

export async function ReviewsSection({ googleReviewsUrl }: { googleReviewsUrl: string }) {
  let qr: string | null = null;
  if (googleReviewsUrl) {
    try {
      qr = await QRCode.toDataURL(googleReviewsUrl, {
        width: 480,
        margin: 2,
        color: { dark: "#113329", light: "#ffffff" },
      });
    } catch {
      qr = null;
    }
  }

  return (
    <section className="border-y border-stone-200/70 bg-white py-16 sm:py-20">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-gold-100 text-gold-600">
            <Star className="h-7 w-7 fill-current" />
          </div>
          <h2 className="text-2xl font-black text-brand-950 sm:text-3xl">رأي عملائنا يهمنا</h2>
          <p className="mt-3 text-sm leading-relaxed text-ink-soft sm:text-base">
            {googleReviewsUrl ? "يمكنك قراءة التقييمات المنشورة أو مشاركة تجربتك على Google." : "لم يُضف رابط التقييمات بعد؛ لا نعرض تقييمات أو أرقامًا غير موثقة."}
          </p>

          {qr && googleReviewsUrl ? (
            <div className="mt-8 flex flex-col items-center gap-5">
              <div className="rounded-3xl border border-stone-200 bg-white p-4 shadow-card">
                <Image src={qr} alt="QR code لتقييم نشاطنا على Google" width={180} height={180} unoptimized />
              </div>
              <p className="text-sm font-semibold text-ink-soft">امسح الرمز بكاميرا هاتفك لقراءة التقييمات أو إضافة تقييمك</p>
              <a
                href={googleReviewsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-xl bg-brand-700 px-6 py-3 text-sm font-black text-white shadow-sm transition hover:bg-brand-800"
              >
                عرض التقييمات على Google
                <ExternalLink className="h-4 w-4" />
              </a>
            </div>
          ) : (
            <div className="mt-8 flex items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-stone-200 bg-stone-50 px-6 py-8">
              <Settings2 className="h-6 w-6 shrink-0 text-stone-300" />
              <p className="text-sm font-bold text-stone-400">أضف رابط تقييمات Google من لوحة الإدارة ليظهر هنا QR code التقييم</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
