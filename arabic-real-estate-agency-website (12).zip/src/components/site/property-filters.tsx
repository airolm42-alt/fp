"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Search, SlidersHorizontal, X, RotateCcw } from "lucide-react";
import { cn } from "@/lib/utils";

export function PropertyFilters({
  types,
  locations,
  total,
}: {
  types: { id: string; name: string; slug: string }[];
  locations: string[];
  total: number;
}) {
  const router = useRouter();
  const params = useSearchParams();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState(params.get("q") ?? "");

  function apply(key: string, value: string) {
    if ((params.get(key) ?? "") === value) return;
    const sp = new URLSearchParams(params.toString());
    if (value) sp.set(key, value);
    else sp.delete(key);
    sp.delete("page");
    router.push(`/properties?${sp.toString()}`);
  }

  function reset() {
    router.push("/properties");
    setQ("");
  }

  const activeCount = ["listing", "type", "location", "minPrice", "maxPrice", "beds", "baths", "minArea", "maxArea", "featured"]
    .filter((k) => params.get(k))
    .length;

  const selectCls =
    "w-full cursor-pointer appearance-none rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm font-semibold text-ink outline-none transition focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15";
  const inputCls =
    "w-full rounded-xl border border-stone-200 bg-white px-3.5 py-2.5 text-sm font-semibold text-ink outline-none transition placeholder:text-stone-400 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15";

  return (
    <div className="mb-8">
      {/* Top bar */}
      <div className="flex flex-wrap items-center gap-2.5">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            apply("q", q.trim());
          }}
          className="relative min-w-56 flex-1"
        >
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ابحث بعنوان العقار أو المنطقة..."
            className={cn(inputCls, "pe-10")}
          />
          <button type="submit" className="absolute end-3 top-1/2 -translate-y-1/2 cursor-pointer text-stone-400 hover:text-brand-600" aria-label="بحث">
            <Search className="h-4.5 w-4.5" />
          </button>
        </form>

        <select value={params.get("sort") ?? ""} onChange={(e) => apply("sort", e.target.value)} className={cn(selectCls, "w-auto")} aria-label="ترتيب النتائج">
          <option value="">الأحدث أولًا</option>
          <option value="oldest">الأقدم أولًا</option>
          <option value="price_asc">السعر: من الأقل</option>
          <option value="price_desc">السعر: من الأعلى</option>
          <option value="area_desc">المساحة: الأكبر</option>
          <option value="area_asc">المساحة: الأصغر</option>
        </select>

        <button
          onClick={() => setOpen((v) => !v)}
          className={cn(
            "inline-flex cursor-pointer items-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-bold transition",
            open || activeCount > 0
              ? "border-brand-600 bg-brand-700 text-white"
              : "border-stone-200 bg-white text-ink hover:border-brand-400",
          )}
        >
          <SlidersHorizontal className="h-4 w-4" />
          فلاتر
          {activeCount > 0 && (
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-gold-400 text-[11px] font-black text-brand-950">
              {activeCount}
            </span>
          )}
        </button>

        <span className="hidden text-sm font-semibold text-stone-400 sm:block">{total} عقار</span>
      </div>

      {/* Expanded filters */}
      {open && (
        <div className="mt-3 rounded-2xl border border-stone-200 bg-white p-4 shadow-card animate-rise sm:p-5">
          <div key={params.toString()} className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <div>
              <label className="mb-1.5 block text-xs font-bold text-stone-500">الغرض</label>
              <select value={params.get("listing") ?? ""} onChange={(e) => apply("listing", e.target.value)} className={selectCls}>
                <option value="">بيع + إيجار</option>
                <option value="sale">بيع</option>
                <option value="rent">إيجار</option>
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-bold text-stone-500">نوع العقار</label>
              <select value={params.get("type") ?? ""} onChange={(e) => apply("type", e.target.value)} className={selectCls}>
                <option value="">كل الأنواع</option>
                {types.map((t) => (
                  <option key={t.id} value={t.slug}>{t.name}</option>
                ))}
              </select>
            </div>
            <div className="col-span-2">
              <label className="mb-1.5 block text-xs font-bold text-stone-500">المنطقة</label>
              <input
                list="filter-locations"
                defaultValue={params.get("location") ?? ""}
                onBlur={(e) => apply("location", e.target.value.trim())}
                onKeyDown={(e) => e.key === "Enter" && apply("location", (e.target as HTMLInputElement).value.trim())}
                placeholder="اكتب اسم المنطقة..."
                className={inputCls}
              />
              <datalist id="filter-locations">
                {locations.map((l) => (
                  <option key={l} value={l} />
                ))}
              </datalist>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-bold text-stone-500">أقل سعر</label>
              <input type="number" min={0} defaultValue={params.get("minPrice") ?? ""} onBlur={(e) => apply("minPrice", e.target.value)} placeholder="من" className={inputCls} dir="ltr" />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-bold text-stone-500">أعلى سعر</label>
              <input type="number" min={0} defaultValue={params.get("maxPrice") ?? ""} onBlur={(e) => apply("maxPrice", e.target.value)} placeholder="إلى" className={inputCls} dir="ltr" />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-bold text-stone-500">غرف النوم</label>
              <select value={params.get("beds") ?? ""} onChange={(e) => apply("beds", e.target.value)} className={selectCls}>
                <option value="">أي عدد</option>
                {[1, 2, 3, 4, 5, 6].map((n) => (
                  <option key={n} value={n}>{n}+</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-bold text-stone-500">الحمامات</label>
              <select value={params.get("baths") ?? ""} onChange={(e) => apply("baths", e.target.value)} className={selectCls}>
                <option value="">أي عدد</option>
                {[1, 2, 3, 4].map((n) => (
                  <option key={n} value={n}>{n}+</option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-bold text-stone-500">أقل مساحة (م²)</label>
              <input type="number" min={0} defaultValue={params.get("minArea") ?? ""} onBlur={(e) => apply("minArea", e.target.value)} placeholder="من" className={inputCls} dir="ltr" />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-bold text-stone-500">أعلى مساحة (م²)</label>
              <input type="number" min={0} defaultValue={params.get("maxArea") ?? ""} onBlur={(e) => apply("maxArea", e.target.value)} placeholder="إلى" className={inputCls} dir="ltr" />
            </div>
          </div>

          <label className="mt-4 flex cursor-pointer items-center gap-2 text-sm font-bold text-brand-800"><input type="checkbox" checked={params.get("featured") === "1"} onChange={(e) => apply("featured", e.target.checked ? "1" : "")} className="h-4 w-4 accent-brand-700" /> العقارات المميزة فقط</label>
          {activeCount > 0 && (
            <button onClick={reset} className="mt-4 inline-flex cursor-pointer items-center gap-1.5 text-sm font-bold text-red-600 hover:text-red-700">
              <RotateCcw className="h-3.5 w-3.5" /> مسح جميع الفلاتر
            </button>
          )}
        </div>
      )}

      {/* Active chips */}
      {activeCount > 0 && !open && (
        <div className="mt-3 flex flex-wrap items-center gap-2">
          {[
            ["listing", params.get("listing") === "sale" ? "بيع" : params.get("listing") === "rent" ? "إيجار" : null],
            ["type", types.find((t) => t.slug === params.get("type") || t.id === params.get("type"))?.name ?? null],
            ["location", params.get("location")],
            ["featured", params.get("featured") === "1" ? "المميزة فقط" : null],
            ["minPrice", params.get("minPrice") ? `من ${params.get("minPrice")}` : null],
            ["maxPrice", params.get("maxPrice") ? `إلى ${params.get("maxPrice")}` : null],
            ["beds", params.get("beds") ? `غرف ${params.get("beds")}+` : null],
            ["baths", params.get("baths") ? `حمامات ${params.get("baths")}+` : null],
            ["minArea", params.get("minArea") ? `مساحة من ${params.get("minArea")}م²` : null],
            ["maxArea", params.get("maxArea") ? `مساحة حتى ${params.get("maxArea")}م²` : null],
          ].map(([key, label]) =>
            label ? (
              <button
                key={key as string}
                onClick={() => apply(key as string, "")}
                className="inline-flex cursor-pointer items-center gap-1.5 rounded-full bg-brand-50 py-1 pe-2 ps-3 text-xs font-bold text-brand-800 ring-1 ring-brand-600/15 transition hover:bg-brand-100"
              >
                {label}
                <X className="h-3.5 w-3.5 text-brand-400" />
              </button>
            ) : null,
          )}
        </div>
      )}
    </div>
  );
}
