import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

export function SectionHeading({
  title,
  subtitle,
  linkHref,
  linkLabel,
  dark,
}: {
  title: string;
  subtitle?: string;
  linkHref?: string;
  linkLabel?: string;
  dark?: boolean;
}) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4 sm:mb-10">
      <div>
        <span className={cn("mb-2 block h-1 w-12 rounded-full", dark ? "bg-gold-400" : "bg-gold-500")} />
        <h2 className={cn("text-2xl font-black tracking-tight sm:text-3xl", dark ? "text-white" : "text-brand-950")}>{title}</h2>
        {subtitle && <p className={cn("mt-2 max-w-xl text-sm leading-relaxed sm:text-base", dark ? "text-white/60" : "text-ink-soft")}>{subtitle}</p>}
      </div>
      {linkHref && linkLabel && (
        <Link
          href={linkHref}
          className={cn(
            "group inline-flex items-center gap-1.5 text-sm font-bold transition",
            dark ? "text-gold-300 hover:text-gold-200" : "text-brand-700 hover:text-brand-800",
          )}
        >
          {linkLabel}
          <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-1" />
        </Link>
      )}
    </div>
  );
}
