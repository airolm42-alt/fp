import Link from "next/link";
import Image from "next/image";
import { BedDouble, Bath, Ruler, MapPin, Building2, Star, ArrowLeft } from "lucide-react";
import { formatPrice, formatNumber, whatsappLink, cn } from "@/lib/utils";
import type { PropertyWithType } from "@/lib/public-data";

export function PropertyCard({
  property,
  whatsapp,
}: {
  property: PropertyWithType;
  whatsapp?: string;
}) {
  const p = property;
  const waMsg = `مرحبًا، أنا مهتم بالعقار: ${p.title}`;

  return (
    <article className="group relative flex flex-col overflow-hidden rounded-2xl border border-stone-200/80 bg-white shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover">
      {/* Image */}
      <Link href={`/properties/${p.slug}`} className="relative block aspect-[4/3] overflow-hidden bg-sand-dark">
        {p.mainImage ? (
          <Image
            src={p.mainImage}
            alt={p.title}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-105"
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
            loading="lazy"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-brand-200">
            <Building2 className="h-14 w-14" />
          </div>
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/35 via-transparent to-transparent" />

        {/* Badges */}
        <div className="absolute top-3 start-3 flex flex-wrap gap-1.5">
          <span className={cn(
            "rounded-full px-3 py-1 text-xs font-black text-white shadow",
            p.listingType === "sale" ? "bg-brand-700/95" : "bg-gold-600/95",
          )}>
            {p.listingType === "sale" ? "للبيع" : "للإيجار"}
          </span>
          {p.typeName && (
            <span className="rounded-full bg-white/90 px-3 py-1 text-xs font-black text-brand-900 shadow">
              {p.typeName}
            </span>
          )}
        </div>
        {p.featured && (
          <span className="absolute top-3 end-3 flex items-center gap-1 rounded-full bg-gold-400 px-2.5 py-1 text-[11px] font-black text-brand-950 shadow">
            <Star className="h-3 w-3 fill-current" /> مميز
          </span>
        )}

        {/* Price overlay */}
        <div className="absolute bottom-3 start-3">
          <span className="rounded-xl bg-brand-950/85 px-3.5 py-1.5 text-base font-black text-gold-300 backdrop-blur-sm">
            {formatPrice(p.price, p.currency)}
          </span>
        </div>
      </Link>

      {/* Body */}
      <div className="flex flex-1 flex-col p-4 sm:p-5">
        <h3 className="line-clamp-1 text-base font-extrabold text-ink transition-colors group-hover:text-brand-700 sm:text-lg">
          <Link href={`/properties/${p.slug}`}>{p.title}</Link>
        </h3>
        <p className="mt-1.5 flex items-center gap-1.5 text-sm text-ink-soft">
          <MapPin className="h-4 w-4 shrink-0 text-brand-500" />
          <span className="line-clamp-1">{p.location || "—"}</span>
        </p>

        {(p.bedrooms != null || p.bathrooms != null || p.area) && (
          <div className="mt-3.5 flex flex-wrap items-center gap-x-4 gap-y-1.5 border-t border-stone-100 pt-3.5 text-sm font-semibold text-ink-soft">
            {p.bedrooms != null && (
              <span className="flex items-center gap-1.5">
                <BedDouble className="h-4.5 w-4.5 text-brand-500" />
                {p.bedrooms} غرف
              </span>
            )}
            {p.bathrooms != null && (
              <span className="flex items-center gap-1.5">
                <Bath className="h-4.5 w-4.5 text-brand-500" />
                {p.bathrooms} حمام
              </span>
            )}
            {p.area && (
              <span className="flex items-center gap-1.5">
                <Ruler className="h-4.5 w-4.5 text-brand-500" />
                {formatNumber(p.area)} م²
              </span>
            )}
          </div>
        )}

        <div className="mt-4 flex items-center gap-2 border-t border-stone-100 pt-4">
          <Link
            href={`/properties/${p.slug}`}
            className="inline-flex flex-1 items-center justify-center gap-1.5 rounded-xl bg-brand-700 py-2.5 text-sm font-bold text-white transition hover:bg-brand-800"
          >
            التفاصيل
            <ArrowLeft className="h-4 w-4 transition-transform group-hover:-translate-x-0.5" />
          </Link>
          {whatsapp && (
            <a
              href={whatsappLink(whatsapp, waMsg)}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="تواصل عبر واتساب"
              title="استفسر عبر واتساب"
              className="flex h-10.5 w-10.5 items-center justify-center rounded-xl border border-brand-200 text-brand-700 transition hover:border-brand-600 hover:bg-brand-50"
            >
              <WhatsAppGlyph className="h-5 w-5" />
            </a>
          )}
        </div>
      </div>
    </article>
  );
}

export function WhatsAppGlyph({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden="true">
      <path d="M17.47 14.38c-.3-.15-1.76-.87-2.03-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.64.07-.3-.15-1.26-.46-2.39-1.47-.88-.79-1.48-1.76-1.65-2.06-.17-.3-.02-.46.13-.61.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51-.17-.01-.37-.01-.57-.01-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.5 0 1.47 1.07 2.89 1.22 3.09.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.7.62.71.23 1.36.2 1.87.12.57-.08 1.76-.72 2.01-1.41.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35m-5.42 7.4h-.01a9.87 9.87 0 0 1-5.03-1.38l-.36-.21-3.74.98 1-3.65-.24-.37a9.85 9.85 0 0 1-1.51-5.26c0-5.45 4.44-9.88 9.9-9.88a9.82 9.82 0 0 1 6.99 2.9 9.82 9.82 0 0 1 2.9 7c0 5.45-4.45 9.88-9.9 9.88m8.42-18.29A11.82 11.82 0 0 0 12.04 0C5.5 0 .16 5.34.16 11.89c0 2.1.55 4.14 1.59 5.94L.06 24l6.3-1.65a11.88 11.88 0 0 0 5.68 1.44h.01c6.55 0 11.89-5.33 11.89-11.89 0-3.18-1.24-6.16-3.48-8.41" />
    </svg>
  );
}
