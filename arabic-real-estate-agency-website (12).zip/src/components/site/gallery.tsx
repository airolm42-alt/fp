"use client";

import { useState, useEffect, useCallback } from "react";
import Image from "next/image";
import { ChevronRight, ChevronLeft, X, Expand, Building2 } from "lucide-react";
import { cn } from "@/lib/utils";

export function PropertyGallery({ images, title }: { images: { url: string; alt: string }[]; title: string }) {
  const [index, setIndex] = useState(0);
  const [lightbox, setLightbox] = useState(false);

  const next = useCallback(() => setIndex((i) => (i + 1) % images.length), [images.length]);
  const prev = useCallback(() => setIndex((i) => (i - 1 + images.length) % images.length), [images.length]);

  useEffect(() => {
    if (!lightbox) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setLightbox(false);
      if (e.key === "ArrowLeft") next();
      if (e.key === "ArrowRight") prev();
    };
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [lightbox, next, prev]);

  if (images.length === 0) {
    return (
      <div className="flex aspect-[16/9] items-center justify-center rounded-2xl bg-sand-dark text-brand-200">
        <Building2 className="h-20 w-20" />
      </div>
    );
  }

  const current = images[index];

  return (
    <div>
      {/* Main */}
      <div className="group relative aspect-[16/10] overflow-hidden rounded-2xl bg-sand-dark sm:aspect-[16/9]">
        <Image
          src={current.url}
          alt={current.alt || title}
          fill
          priority
          className="object-cover"
          sizes="(max-width: 1024px) 100vw, 800px"
        />
        <button
          onClick={() => setLightbox(true)}
          className="absolute end-3 top-3 cursor-pointer rounded-xl bg-black/50 p-2.5 text-white opacity-0 backdrop-blur-sm transition group-hover:opacity-100"
          aria-label="تكبير الصورة"
        >
          <Expand className="h-5 w-5" />
        </button>
        {images.length > 1 && (
          <>
            <button onClick={prev} className="absolute start-3 top-1/2 -translate-y-1/2 cursor-pointer rounded-full bg-black/45 p-2.5 text-white backdrop-blur-sm transition hover:bg-black/70" aria-label="الصورة السابقة">
              <ChevronRight className="h-5 w-5" />
            </button>
            <button onClick={next} className="absolute end-3 top-1/2 -translate-y-1/2 cursor-pointer rounded-full bg-black/45 p-2.5 text-white backdrop-blur-sm transition hover:bg-black/70" aria-label="الصورة التالية">
              <ChevronLeft className="h-5 w-5" />
            </button>
            <span className="absolute bottom-3 end-3 rounded-full bg-black/55 px-3 py-1 text-xs font-black text-white backdrop-blur-sm" dir="ltr">
              {index + 1} / {images.length}
            </span>
          </>
        )}
      </div>

      {/* Thumbs */}
      {images.length > 1 && (
        <div className="mt-3 grid grid-cols-4 gap-2.5 sm:grid-cols-6">
          {images.slice(0, 6).map((img, i) => (
            <button
              key={img.url + i}
              onClick={() => setIndex(i)}
              className={cn(
                "relative aspect-[4/3] cursor-pointer overflow-hidden rounded-xl border-2 transition",
                i === index ? "border-gold-500 ring-2 ring-gold-500/25" : "border-transparent opacity-70 hover:opacity-100",
              )}
              aria-label={`صورة ${i + 1}`}
            >
              <Image src={img.url} alt={img.alt || `${title} — صورة ${i + 1}`} fill className="object-cover" sizes="140px" />
            </button>
          ))}
        </div>
      )}

      {/* Lightbox */}
      {lightbox && (
        <div className="fixed inset-0 z-[100] flex flex-col bg-black/95 backdrop-blur-sm" onClick={() => setLightbox(false)}>
          <button className="absolute end-4 top-4 z-10 cursor-pointer rounded-full bg-white/10 p-3 text-white hover:bg-white/20" aria-label="إغلاق" onClick={() => setLightbox(false)}>
            <X className="h-6 w-6" />
          </button>
          <div className="relative m-auto h-[78vh] w-full max-w-5xl px-4" onClick={(e) => e.stopPropagation()}>
            <Image src={current.url} alt={current.alt || title} fill className="object-contain" sizes="100vw" />
          </div>
          {images.length > 1 && (
            <div className="absolute inset-x-0 bottom-6 flex items-center justify-center gap-3" onClick={(e) => e.stopPropagation()}>
              <button onClick={prev} className="cursor-pointer rounded-full bg-white/10 p-2.5 text-white hover:bg-white/20" aria-label="السابق">
                <ChevronRight className="h-5 w-5" />
              </button>
              <span className="text-sm font-black text-white" dir="ltr">{index + 1} / {images.length}</span>
              <button onClick={next} className="cursor-pointer rounded-full bg-white/10 p-2.5 text-white hover:bg-white/20" aria-label="التالي">
                <ChevronLeft className="h-5 w-5" />
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
