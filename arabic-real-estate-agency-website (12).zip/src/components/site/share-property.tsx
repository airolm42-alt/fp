"use client";
import { useState } from "react";
import { Check, Share2 } from "lucide-react";
export function ShareProperty({ title }: { title: string }) {
  const [copied, setCopied] = useState(false);
  const [message, setMessage] = useState("");
  async function share() {
    try {
      if (navigator.share) await navigator.share({ title, url: window.location.href });
      else {
        await navigator.clipboard.writeText(window.location.href);
        setCopied(true); setMessage("تم نسخ رابط العقار");
        setTimeout(() => { setCopied(false); setMessage(""); }, 3000);
      }
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") return;
      setMessage("يمكنك نسخ الرابط من شريط المتصفح");
    }
  }
  return <div className="mt-4 border-t border-stone-100 pt-4 text-center"><button type="button" onClick={share} className="inline-flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2 text-xs font-bold text-brand-700 hover:bg-brand-50">{copied ? <Check className="h-4 w-4" /> : <Share2 className="h-4 w-4" />}{copied ? "تم نسخ الرابط" : "مشاركة العقار"}</button>{message && <p role="status" className="mt-1 text-xs text-stone-400">{message}</p>}</div>;
}
