"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Search, MapPin, Home, Banknote } from "lucide-react";
import { cn } from "@/lib/utils";

export function HeroSearch({
  types,
  locations,
}: {
  types: { id: string; name: string; slug: string }[];
  locations: string[];
}) {
  const router = useRouter();
  const [listing, setListing] = useState<"sale" | "rent">("sale");
  const [type, setType] = useState("");
  const [location, setLocation] = useState("");
  const [maxPrice, setMaxPrice] = useState("");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    const sp = new URLSearchParams();
    sp.set("listing", listing);
    if (type) sp.set("type", type);
    if (location) sp.set("location", location);
    if (maxPrice) sp.set("maxPrice", maxPrice);
    router.push(`/properties?${sp.toString()}`);
  }

  return (
    <form
      onSubmit={submit}
      className="w-full rounded-2xl bg-white p-3 shadow-[0_20px_60px_-15px_rgb(0_0_0/0.3)] sm:rounded-3xl sm:p-4"
    >
      {/* Tabs */}
      <div className="mb-3 flex gap-1.5 rounded-xl bg-stone-100 p-1 sm:w-fit">
        {(["sale", "rent"] as const).map((v) => (
          <button
            key={v}
            type="button"
            onClick={() => setListing(v)}
            className={cn(
              "flex-1 cursor-pointer rounded-lg px-6 py-2 text-sm font-black transition sm:flex-none",
              listing === v ? "bg-brand-700 text-white shadow-sm" : "text-ink-soft hover:text-ink",
            )}
          >
            {v === "sale" ? "شراء" : "إيجار"}
          </button>
        ))}
      </div>

      <div className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-[1fr_1fr_1fr_auto]">
        <div className="relative">
          <label className="sr-only">المنطقة</label>
          <input
            list="hero-locations"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            placeholder="ابحث باسم المنطقة أو المدينة..."
            className="w-full rounded-xl border border-stone-200 bg-stone-50/60 py-3 pe-10 ps-4 text-sm font-semibold text-ink outline-none transition placeholder:text-stone-400 focus:border-brand-500 focus:bg-white focus:ring-2 focus:ring-brand-500/15"
          />
          <MapPin className="pointer-events-none absolute end-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-brand-500" />
          <datalist id="hero-locations">
            {locations.map((l) => (
              <option key={l} value={l} />
            ))}
          </datalist>
        </div>

        <div className="relative">
          <label className="sr-only">نوع العقار</label>
          <select
            value={type}
            onChange={(e) => setType(e.target.value)}
            className="w-full cursor-pointer appearance-none rounded-xl border border-stone-200 bg-stone-50/60 py-3 pe-10 ps-4 text-sm font-semibold text-ink outline-none transition focus:border-brand-500 focus:bg-white focus:ring-2 focus:ring-brand-500/15"
          >
            <option value="">كل أنواع العقارات</option>
            {types.map((t) => (
              <option key={t.id} value={t.slug}>{t.name}</option>
            ))}
          </select>
          <Home className="pointer-events-none absolute end-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-brand-500" />
        </div>

        <div className="relative">
          <label className="sr-only">أقصى سعر</label>
          <input
            type="number"
            min={0}
            value={maxPrice}
            onChange={(e) => setMaxPrice(e.target.value)}
            placeholder="الميزانية (أقصى سعر)"
            className="w-full rounded-xl border border-stone-200 bg-stone-50/60 py-3 pe-10 ps-4 text-sm font-semibold text-ink outline-none transition placeholder:text-stone-400 focus:border-brand-500 focus:bg-white focus:ring-2 focus:ring-brand-500/15"
          />
          <Banknote className="pointer-events-none absolute end-3.5 top-1/2 h-4.5 w-4.5 -translate-y-1/2 text-brand-500" />
        </div>

        <button
          type="submit"
          className="inline-flex cursor-pointer items-center justify-center gap-2 rounded-xl bg-gold-500 px-8 py-3 text-sm font-black text-brand-950 shadow-sm transition hover:bg-gold-400 active:scale-[0.98]"
        >
          <Search className="h-4.5 w-4.5" />
          ابحث الآن
        </button>
      </div>
    </form>
  );
}
