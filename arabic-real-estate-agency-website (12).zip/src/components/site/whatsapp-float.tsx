import { whatsappLink } from "@/lib/utils";
import { WhatsAppGlyph } from "@/components/site/property-card";

export function WhatsAppFloat({ whatsapp }: { whatsapp: string }) {
  if (!whatsapp) return null;
  return (
    <a
      href={whatsappLink(whatsapp, "مرحبًا، أريد الاستفسار عن العقارات المتاحة")}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="تواصل معنا عبر واتساب"
      className="group fixed bottom-5 start-5 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#25d366] text-white shadow-[0_8px_30px_-4px_rgb(37_211_102/0.5)] transition hover:scale-105 active:scale-95"
    >
      <WhatsAppGlyph className="h-7 w-7" />
      <span className="absolute end-full me-2 hidden whitespace-nowrap rounded-lg bg-brand-950 px-3 py-1.5 text-xs font-bold text-white shadow-lg sm:block sm:opacity-0 sm:transition sm:group-hover:opacity-100">
        راسلنا واتساب
      </span>
    </a>
  );
}
