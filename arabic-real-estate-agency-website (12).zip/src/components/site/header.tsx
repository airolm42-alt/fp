"use client";
import { useCallback, useEffect, useState } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { Menu, X, Building2, MessageCircle, Phone } from "lucide-react";
import { cn, whatsappLink } from "@/lib/utils";
import { useDialog } from "@/components/use-dialog";
import type { BusinessSettings } from "@/lib/settings";
const NAV = [{ href: "/", label: "الرئيسية" }, { href: "/properties", label: "العقارات" }, { href: "/about", label: "من نحن" }, { href: "/services", label: "خدماتنا" }, { href: "/contact", label: "تواصل معنا" }];

export function SiteHeader({ business }: { business: BusinessSettings }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const pathname = usePathname();
  const close = useCallback(() => setOpen(false), []);
  const drawer = useDialog(open, close);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12); onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  const name = business.businessName || "موقع عقاري";
  const brand = <><span className="relative flex h-10 w-10 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-brand-800 text-gold-400">{business.logo ? <Image src={business.logo} alt={`شعار ${name}`} fill className="object-contain bg-white p-1" sizes="40px" /> : <Building2 className="h-5.5 w-5.5" />}</span><span className="min-w-0 max-w-44 truncate text-lg font-black tracking-tight text-brand-950 xl:max-w-56">{name}</span></>;
  const active = (href: string) => href === "/" ? pathname === "/" : pathname.startsWith(href);
  return <>
    <header className={cn("sticky top-0 z-50 transition-all duration-300", scrolled ? "bg-white/90 shadow-[0_2px_20px_-8px_rgb(16_34_28/0.15)] backdrop-blur-xl" : "bg-white/70 backdrop-blur-md")}>
      <a href="#main-content" className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:rounded-lg focus:bg-white focus:px-4 focus:py-2 focus:text-brand-800">تخطَّ إلى المحتوى</a>
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-4 sm:px-6 lg:h-[72px] lg:px-8">
        <Link href="/" className="flex min-w-0 items-center gap-2.5" title={name}>{brand}</Link>
        <nav aria-label="التنقل الرئيسي" className="hidden shrink-0 items-center gap-0.5 lg:flex">{NAV.map((item) => <Link key={item.href} href={item.href} aria-current={active(item.href) ? "page" : undefined} className={cn("relative rounded-lg px-3 py-2 text-sm font-bold transition-colors", active(item.href) ? "text-brand-800" : "text-ink-soft hover:text-brand-800")}>{item.label}{active(item.href) && <span className="absolute inset-x-3 -bottom-0.5 h-0.5 rounded-full bg-gold-500" />}</Link>)}</nav>
        <div className="flex shrink-0 items-center gap-2">
          {business.phone && <a href={`tel:${business.phone}`} dir="ltr" className="hidden items-center gap-2 rounded-xl border border-stone-200 px-3 py-2 text-sm font-bold text-ink hover:border-brand-500 xl:inline-flex"><Phone className="h-4 w-4" /><span>{business.phone}</span></a>}
          {business.whatsapp && <a href={whatsappLink(business.whatsapp, "مرحبًا، أريد الاستفسار عن العقارات المتاحة")} target="_blank" rel="noopener noreferrer" className="hidden items-center gap-2 rounded-xl bg-brand-700 px-3 py-2 text-sm font-bold text-white hover:bg-brand-800 lg:inline-flex"><MessageCircle className="h-4 w-4" />واتساب</a>}
          <button type="button" onClick={() => setOpen(true)} className="cursor-pointer rounded-xl p-2.5 text-ink hover:bg-stone-100 lg:hidden" aria-label="فتح القائمة" aria-expanded={open} aria-controls="mobile-navigation"><Menu className="h-6 w-6" /></button>
        </div>
      </div>
    </header>
    {open && createPortal(<div className="fixed inset-0 z-[80] lg:hidden">
      <div className="absolute inset-0 bg-brand-950/40 backdrop-blur-sm" onClick={close} />
      <div ref={drawer} id="mobile-navigation" role="dialog" aria-modal="true" aria-label="قائمة التنقل" className="absolute inset-y-0 end-0 flex w-80 max-w-[88vw] flex-col bg-white shadow-2xl">
        <div className="flex items-center justify-between gap-2 border-b border-stone-100 px-4 py-4"><span className="flex min-w-0 items-center gap-2">{brand}</span><button type="button" onClick={close} className="shrink-0 cursor-pointer rounded-lg p-2 text-stone-500 hover:bg-stone-100" aria-label="إغلاق القائمة"><X className="h-5 w-5" /></button></div>
        <nav aria-label="التنقل على الموبايل" className="flex flex-1 flex-col gap-1 overflow-y-auto p-4">{NAV.map((item) => <Link key={item.href} href={item.href} onClick={close} aria-current={active(item.href) ? "page" : undefined} className={cn("rounded-xl px-4 py-3.5 text-base font-bold", active(item.href) ? "bg-brand-50 text-brand-800" : "text-ink hover:bg-stone-50")}>{item.label}</Link>)}</nav>
        <div className="space-y-2.5 border-t border-stone-100 p-4">
          {business.phone && <a href={`tel:${business.phone}`} className="flex items-center justify-center gap-2 rounded-xl border border-stone-200 py-3 text-sm font-bold"><Phone className="h-4.5 w-4.5" /><span dir="ltr">{business.phone}</span></a>}
          {business.whatsapp && <a href={whatsappLink(business.whatsapp, "مرحبًا، أريد الاستفسار عن العقارات المتاحة")} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 rounded-xl bg-brand-700 py-3 text-sm font-bold text-white"><MessageCircle className="h-4.5 w-4.5" />تواصل عبر واتساب</a>}
        </div>
      </div>
    </div>, document.body)}
  </>;
}
