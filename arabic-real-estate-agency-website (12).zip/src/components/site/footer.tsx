import Link from "next/link";
import Image from "next/image";
import {
  Building2,
  Phone,
  MessageCircle,
  Mail,
  MapPin,
  Clock,
  Map,
} from "lucide-react";
import { FacebookIcon, InstagramIcon, TikTokIcon, YoutubeIcon } from "@/components/site/social-icons";
import { whatsappLink } from "@/lib/utils";
import type { BusinessSettings, SiteSettings } from "@/lib/settings";

export function SiteFooter({ business, site }: { business: BusinessSettings; site: SiteSettings }) {
  const year = new Date().getFullYear();
  const name = business.businessName || "موقع عقاري";
  const hasContact = business.phone || business.whatsapp || business.email || business.address || business.workingHours;
  const hasSocial = business.facebook || business.instagram || business.tiktok || business.youtube;

  return (
    <footer className="relative overflow-hidden bg-brand-950 text-brand-100/80 pattern-arabesque">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-2 lg:max-w-sm">
            <Link href="/" className="flex items-center gap-2.5">
              {business.logo ? (
                <span className="relative block h-11 w-11 overflow-hidden rounded-xl bg-white/10">
                  <Image src={business.logo} alt={`شعار ${name}`} fill className="object-contain p-1" sizes="44px" />
                </span>
              ) : (
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-gold-400 text-brand-950">
                  <Building2 className="h-6 w-6" />
                </span>
              )}
              <span className="text-xl font-black text-white">{name}</span>
            </Link>
            {site.footerAbout && <p className="mt-4 max-w-sm text-sm leading-relaxed text-brand-100/60">{site.footerAbout}</p>}
            {hasSocial && (
              <div className="mt-5 flex gap-2.5">
                {business.facebook && (
                  <a href={business.facebook} target="_blank" rel="noopener noreferrer" aria-label="فيسبوك" className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/8 text-white/80 transition hover:bg-gold-400 hover:text-brand-950">
                    <FacebookIcon className="h-4.5 w-4.5" />
                  </a>
                )}
                {business.instagram && (
                  <a href={business.instagram} target="_blank" rel="noopener noreferrer" aria-label="إنستجرام" className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/8 text-white/80 transition hover:bg-gold-400 hover:text-brand-950">
                    <InstagramIcon className="h-4.5 w-4.5" />
                  </a>
                )}
                {business.tiktok && (
                  <a href={business.tiktok} target="_blank" rel="noopener noreferrer" aria-label="تيك توك" className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/8 text-white/80 transition hover:bg-gold-400 hover:text-brand-950">
                    <TikTokIcon className="h-4.5 w-4.5" />
                  </a>
                )}
                {business.youtube && (
                  <a href={business.youtube} target="_blank" rel="noopener noreferrer" aria-label="يوتيوب" className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/8 text-white/80 transition hover:bg-gold-400 hover:text-brand-950">
                    <YoutubeIcon className="h-4.5 w-4.5" />
                  </a>
                )}
              </div>
            )}
          </div>

          {/* Links */}
          <div>
            <h3 className="mb-4 text-sm font-black uppercase tracking-wider text-gold-400">روابط سريعة</h3>
            <ul className="space-y-2.5 text-sm font-semibold">
              <li><Link href="/properties" className="transition hover:text-white">تصفح العقارات</Link></li>
              <li><Link href="/about" className="transition hover:text-white">من نحن</Link></li>
              <li><Link href="/services" className="transition hover:text-white">خدماتنا</Link></li>
              <li><Link href="/contact" className="transition hover:text-white">تواصل معنا</Link></li>
              <li><Link href="/privacy" className="transition hover:text-white">سياسة الخصوصية</Link></li>
              <li><Link href="/terms" className="transition hover:text-white">الشروط والأحكام</Link></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="mb-4 text-sm font-black uppercase tracking-wider text-gold-400">تواصل معنا</h3>
            {hasContact ? (
              <ul className="space-y-3 text-sm">
                {business.phone && (
                  <li>
                    <a href={`tel:${business.phone}`} className="flex items-center gap-2.5 font-semibold transition hover:text-white">
                      <Phone className="h-4 w-4 shrink-0 text-gold-400" />
                      <span dir="ltr">{business.phone}</span>
                    </a>
                  </li>
                )}
                {business.whatsapp && (
                  <li>
                    <a href={whatsappLink(business.whatsapp)} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2.5 font-semibold transition hover:text-white">
                      <MessageCircle className="h-4 w-4 shrink-0 text-gold-400" />
                      واتساب
                    </a>
                  </li>
                )}
                {business.email && (
                  <li>
                    <a href={`mailto:${business.email}`} className="flex items-center gap-2.5 font-semibold transition hover:text-white">
                      <Mail className="h-4 w-4 shrink-0 text-gold-400" />
                      <span dir="ltr">{business.email}</span>
                    </a>
                  </li>
                )}
                {business.address && (
                  <li className="flex items-start gap-2.5">
                    <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                    <span>{business.address}</span>
                  </li>
                )}
                {business.workingHours && (
                  <li className="flex items-start gap-2.5">
                    <Clock className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
                    <span>{business.workingHours}</span>
                  </li>
                )}
                {business.googleMapsUrl && (
                  <li>
                    <a href={business.googleMapsUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2.5 font-semibold text-gold-300 transition hover:text-gold-200">
                      <Map className="h-4 w-4 shrink-0" />
                      موقعنا على الخريطة
                    </a>
                  </li>
                )}
              </ul>
            ) : (
              <p className="rounded-xl border border-dashed border-white/15 p-3.5 text-xs leading-relaxed text-brand-100/50">
                بيانات التواصل تُضاف من لوحة الإدارة ← بيانات النشاط
              </p>
            )}
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-white/10 pt-6 text-xs text-brand-100/50 sm:flex-row">
          <p>© {year} {name} — جميع الحقوق محفوظة</p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link href="/privacy" className="transition hover:text-white">سياسة الخصوصية</Link>
            <Link href="/terms" className="transition hover:text-white">الشروط والأحكام</Link>
            {/* Discreet staff entrance — the dashboard itself is protected by auth */}
            <Link href="/admin" className="text-brand-100/35 transition hover:text-gold-300" aria-label="دخول الإدارة">
              دخول الإدارة
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
