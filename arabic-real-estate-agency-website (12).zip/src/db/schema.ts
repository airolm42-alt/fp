import {
  pgTable,
  pgEnum,
  uuid,
  text,
  integer,
  numeric,
  boolean,
  timestamp,
  jsonb,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";

export const listingTypeEnum = pgEnum("listing_type", ["sale", "rent"]);
export const propertyStatusEnum = pgEnum("property_status", ["draft", "published"]);
export const inquiryStatusEnum = pgEnum("inquiry_status", ["new", "contacted", "closed"]);

/* ------------------------------ Admin users ------------------------------ */
export const adminUsers = pgTable("admin_users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull().default("المدير"),
  /** Only the owner may create or remove other admin accounts. */
  isOwner: boolean("is_owner").notNull().default(false),
  /** Which admin created this account (audit trail). */
  createdBy: uuid("created_by"),
  /** Forces a password change on first login for invited admins. */
  mustChangePassword: boolean("must_change_password").notNull().default(false),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ----------------------------- Property types ----------------------------- */
export const propertyTypes = pgTable("property_types", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* ------------------------------- Properties ------------------------------- */
export const properties = pgTable(
  "properties",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    title: text("title").notNull(),
    slug: text("slug").notNull().unique(),
    description: text("description").notNull().default(""),
    typeId: uuid("type_id").references(() => propertyTypes.id, { onDelete: "set null" }),
    listingType: listingTypeEnum("listing_type").notNull().default("sale"),
    price: numeric("price", { precision: 15, scale: 2 }),
    currency: text("currency").notNull().default("ج.م"),
    location: text("location").notNull().default(""),
    address: text("address").notNull().default(""),
    area: numeric("area", { precision: 10, scale: 2 }),
    bedrooms: integer("bedrooms"),
    bathrooms: integer("bathrooms"),
    floor: text("floor").notNull().default(""),
    finishing: text("finishing").notNull().default(""),
    features: jsonb("features").$type<string[]>().notNull().default([]),
    mainImage: text("main_image").notNull().default(""),
    googleMapsUrl: text("google_maps_url").notNull().default(""),
    whatsappMessage: text("whatsapp_message").notNull().default(""),
    status: propertyStatusEnum("status").notNull().default("draft"),
    featured: boolean("featured").notNull().default(false),
    metaTitle: text("meta_title").notNull().default(""),
    metaDescription: text("meta_description").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("properties_status_idx").on(t.status),
    index("properties_featured_idx").on(t.featured),
    index("properties_listing_type_idx").on(t.listingType),
    index("properties_type_idx").on(t.typeId),
    index("properties_created_idx").on(t.createdAt),
    index("properties_price_idx").on(t.price),
  ],
);

/* ---------------------------- Property images ----------------------------- */
export const propertyImages = pgTable(
  "property_images",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    propertyId: uuid("property_id")
      .notNull()
      .references(() => properties.id, { onDelete: "cascade" }),
    url: text("url").notNull(),
    alt: text("alt").notNull().default(""),
    sort: integer("sort").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("property_images_property_idx").on(t.propertyId)],
);

/* -------------------------------- Services -------------------------------- */
export const services = pgTable("services", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  icon: text("icon").notNull().default(""),
  image: text("image").notNull().default(""),
  published: boolean("published").notNull().default(false),
  sort: integer("sort").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/* --------------------------------- Areas ---------------------------------- */
export const areas = pgTable("areas", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull().default(""),
  image: text("image").notNull().default(""),
  published: boolean("published").notNull().default(true),
  sort: integer("sort").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* -------------------------------- Inquiries ------------------------------- */
export const inquiries = pgTable(
  "inquiries",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: text("name").notNull(),
    phone: text("phone").notNull(),
    email: text("email").notNull().default(""),
    message: text("message").notNull(),
    propertyId: uuid("property_id").references(() => properties.id, { onDelete: "set null" }),
    propertyTitle: text("property_title").notNull().default(""),
    status: inquiryStatusEnum("status").notNull().default("new"),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("inquiries_status_idx").on(t.status),
    index("inquiries_created_idx").on(t.createdAt),
  ],
);

/* ---------------------------------- Media --------------------------------- */
export const mediaFiles = pgTable("media_files", {
  id: uuid("id").defaultRandom().primaryKey(),
  url: text("url").notNull(),
  name: text("name").notNull(),
  mime: text("mime").notNull(),
  size: integer("size").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/* Shared, bounded-time throttling across server restarts and replicas. */
export const securityLimits = pgTable("security_limits", {
  key: text("key").primaryKey(),
  hits: integer("hits").notNull().default(0),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
}, (t) => [index("security_limits_expiry_idx").on(t.expiresAt)]);

/* --------------------------- Settings (key-value) -------------------------- */
export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AdminUser = typeof adminUsers.$inferSelect;
export type Property = typeof properties.$inferSelect;
export type PropertyImage = typeof propertyImages.$inferSelect;
export type PropertyType = typeof propertyTypes.$inferSelect;
export type Service = typeof services.$inferSelect;
export type Area = typeof areas.$inferSelect;
export type Inquiry = typeof inquiries.$inferSelect;
export type MediaFile = typeof mediaFiles.$inferSelect;
