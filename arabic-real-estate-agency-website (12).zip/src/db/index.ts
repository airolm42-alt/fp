import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error("DATABASE_URL is required");
const globalForDb = globalThis as typeof globalThis & { __arenaNextJsPostgresqlPool?: Pool };
const configuredMax = Number(process.env.DB_POOL_MAX ?? "10");
export const pool = globalForDb.__arenaNextJsPostgresqlPool ?? new Pool({
  connectionString: databaseUrl,
  max: Number.isInteger(configuredMax) && configuredMax >= 1 && configuredMax <= 30 ? configuredMax : 10,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,
  statement_timeout: 15_000,
});
globalForDb.__arenaNextJsPostgresqlPool = pool;
export const db = drizzle(pool);
