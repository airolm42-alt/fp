import Image from "next/image";
import QRCode from "qrcode";
import { getBusinessSettings } from "@/lib/settings";
import { PageHeader } from "@/components/admin/admin-shell";
import { ReviewsForm } from "@/components/admin/settings-forms";
import { Card } from "@/components/ui";
import { Star, ExternalLink } from "lucide-react";

export const dynamic = "force-dynamic";
export const metadata = { title: "تقييمات Google — لوحة الإدارة" };

export default async function ReviewsAdminPage() {
  const business = await getBusinessSettings();

  let qr: string | null = null;
  if (business.googleReviewsUrl) {
    try {
      qr = await QRCode.toDataURL(business.googleReviewsUrl, {
        width: 480,
        margin: 2,
        color: { dark: "#113329", light: "#ffffff" },
      });
    } catch {
      qr = null;
    }
  }

  return (
    <div>
      <PageHeader title="تقييمات Google" description="اربط رابط تقييمات نشاطك ليظهر QR code حقيقي في الموقع العام" />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <ReviewsForm initial={business} />
        </div>
        <div>
          <Card className="p-6 text-center">
            <h3 className="mb-4 text-base font-extrabold text-ink">معاينة QR التقييم</h3>
            {qr && business.googleReviewsUrl ? (
              <>
                <div className="mx-auto w-fit rounded-2xl border border-stone-200 bg-white p-3 shadow-sm">
                  <Image src={qr} alt="QR code لرابط تقييمات Google" width={200} height={200} unoptimized />
                </div>
                <p className="mt-3 text-xs leading-relaxed text-stone-500">هذا الرمز يظهر في الموقع العام ويوجّه عملاءك لصفحة التقييم مباشرة</p>
                <a
                  href={business.googleReviewsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 inline-flex items-center gap-1.5 text-xs font-bold text-brand-700 hover:text-brand-800"
                >
                  تجربة الرابط <ExternalLink className="h-3.5 w-3.5" />
                </a>
              </>
            ) : (
              <div className="flex flex-col items-center rounded-xl border-2 border-dashed border-stone-200 px-5 py-10">
                <Star className="mb-3 h-8 w-8 text-stone-300" />
                <p className="text-sm font-bold text-ink">لا يوجد رابط تقييمات بعد</p>
                <p className="mt-1 max-w-56 text-xs leading-relaxed text-stone-400">
                  أضف رابط تقييمات Google Business وسيُنشأ QR code حقيقي تلقائيًا
                </p>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}
