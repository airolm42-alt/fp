import { getBusinessSettings } from "@/lib/settings";
import { PageHeader } from "@/components/admin/admin-shell";
import { BusinessForm } from "@/components/admin/settings-forms";

export const dynamic = "force-dynamic";
export const metadata = { title: "بيانات النشاط — لوحة الإدارة" };

export default async function BusinessPage() {
  const business = await getBusinessSettings();
  return (
    <div>
      <PageHeader title="بيانات النشاط التجاري" description="هذه البيانات تظهر تلقائيًا في الهيدر والفوتر وصفحات الموقع" />
      <BusinessForm initial={business} />
    </div>
  );
}
