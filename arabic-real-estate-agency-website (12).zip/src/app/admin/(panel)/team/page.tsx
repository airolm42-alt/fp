import { PageHeader } from "@/components/admin/admin-shell";
import { TeamManager } from "@/components/admin/team-manager";

export const dynamic = "force-dynamic";
export const metadata = { title: "فريق الإدارة — لوحة الإدارة" };

export default function TeamPage() {
  return (
    <div>
      <PageHeader
        title="فريق الإدارة"
        description="إدارة حسابات الدخول للوحة — الإضافة والإزالة بصلاحية المالك فقط"
      />
      <TeamManager />
    </div>
  );
}
