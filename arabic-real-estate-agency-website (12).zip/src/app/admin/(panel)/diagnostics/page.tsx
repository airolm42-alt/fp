import { redirect } from "next/navigation";
import Link from "next/link";
import { sql } from "drizzle-orm";
import { CheckCircle2, CircleAlert, ShieldCheck, Wrench } from "lucide-react";
import { db } from "@/db";
import { getCurrentAdmin } from "@/lib/auth";
import { getAllSettings } from "@/lib/settings";
import { getSiteUrlInfo } from "@/lib/site-url";
import { PageHeader } from "@/components/admin/admin-shell";

export const dynamic = "force-dynamic";
export const metadata = { title: "فحص الموقع — لوحة الإدارة", robots: { index: false, follow: false } };

export default async function DiagnosticsPage() {
  const admin = await getCurrentAdmin();
  if (!admin) redirect("/admin/login");
  if (!admin.isOwner) redirect("/admin/dashboard");
  const [configuration, url] = await Promise.all([getAllSettings(), getSiteUrlInfo()]);
  let databaseReady = false;
  let limitsReady = false;
  try { await db.execute(sql`select 1`); databaseReady = true;
    const result = await db.execute<{ exists: boolean }>(sql`select to_regclass('public.security_limits') is not null as exists`); limitsReady = !!result.rows[0]?.exists;
  } catch {}
  const checks = [
    { title: "اتصال قاعدة البيانات", ready: databaseReady, detail: "الاتصال يُفحص الآن. النسخ الاحتياطية وصلاحيات مستخدم الإنتاج تحتاج ضبطًا منفصلًا." },
    { title: "المصادقة وصلاحيات المالك", ready: true, detail: "وصلت لهذه الصفحة بجلسة مالك معتمدة. حذف الحساب أو تغيير بيانات الدخول يبطل الجلسات القديمة." },
    { title: "مفتاح الجلسة الخاص", ready: (process.env.AUTH_SECRET?.length ?? 0) >= 32, detail: "لا تُعرض قيمة المفتاح. يجب إعداده سرًا في الاستضافة قبل التشغيل." },
    { title: "حدود الطلبات المشتركة", ready: limitsReady, detail: "حدود الدخول والاستفسارات محفوظة في PostgreSQL. يجب على Reverse Proxy ضبط عنوان العميل الحقيقي." },
    { title: "دومين إنتاج مضبوط", ready: url.kind === "public" && !!url.configuredOrigin, detail: "رابط المعاينة ليس نشرًا نهائيًا. حفظ دومين لا يثبت DNS أو نجاح النشر." },
    { title: "مسار صور دائم محدد", ready: !!(process.env.UPLOAD_DIR || process.env.RAILWAY_VOLUME_MOUNT_PATH), detail: "وجود المتغير ليس إثباتًا لدوام التخزين؛ اربطه بـVolume فعلي واحتفظ بنسخة احتياطية." },
    { title: "بيانات النشاط الحقيقية", ready: !!configuration.business.businessName && !!(configuration.business.phone || configuration.business.email || configuration.business.whatsapp), detail: "لا يتم إنشاء شركة أو أرقام أو صور أو عقارات وهمية." },
    { title: "معلومات البحث وتوثيق Google", ready: !!configuration.seo.siteTitle && !!configuration.seo.siteDescription && !!configuration.seo.googleVerification, detail: "كود التوثيق يحتاج تأكيدًا في Search Console. لا يضمن ظهورًا أو ترتيبًا في Google." },
    { title: "Supabase Auth وStorage وRLS", ready: false, detail: "غير مطبّقة في هذه النسخة: تستخدم PostgreSQL/Drizzle ومصادقة خاصة وتخزين صور الخادم. وجود متغير Supabase وحده لا يفعّل التكامل." },
    { title: "استعادة كلمة المرور بالبريد", ready: false, detail: "غير مفعّلة؛ المشرف يستعيدها عبر المالك، والمالك عبر متغيرات الاستضافة وسكربت seed المخوّل." },
  ];
  return <div className="max-w-4xl"><PageHeader title="فحص الموقع" description="حالة فعلية للإعدادات — لا يُعتبر هذا شهادة أمان أو اختبار ضغط شامل" />
    <div className="mb-6 rounded-2xl bg-brand-950 p-6 text-white"><ShieldCheck className="mb-3 h-7 w-7 text-gold-400" /><h2 className="text-lg font-black">المعاينة والتشغيل النهائي شيئان مختلفان</h2><p className="mt-2 text-sm leading-loose text-brand-100/70">أكمل إعدادات الإنتاج قبل تسليم الموقع للعملاء. نتائج مراجعة الكود والاختبارات موضّحة في ملف AUDIT-REPORT-AR.md داخل حزمة المصدر.</p></div>
    <div className="space-y-3">{checks.map((check) => <section key={check.title} className="flex items-start gap-3 rounded-2xl border border-stone-200 bg-white p-5 shadow-card">{check.ready ? <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" /> : <CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-gold-600" />}<div className="min-w-0 flex-1"><h2 className="text-sm font-extrabold text-ink">{check.title}</h2><p className="mt-1 text-xs leading-loose text-stone-500">{check.detail}</p></div><span className={`shrink-0 rounded-full px-2 py-1 text-[10px] font-bold ${check.ready ? "bg-brand-50 text-brand-700" : "bg-gold-50 text-gold-800"}`}>{check.ready ? "مضبوط" : "مطلوب / غير مفعّل"}</span></section>)}</div>
    <Link href="/admin/publishing" className="mt-6 inline-flex items-center gap-2 rounded-xl bg-brand-700 px-5 py-3 text-sm font-bold text-white"><Wrench className="h-4 w-4" /> النشر وحزمة المصدر الكاملة</Link>
  </div>;
}
