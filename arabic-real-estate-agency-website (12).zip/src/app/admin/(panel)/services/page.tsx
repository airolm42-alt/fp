import { db } from "@/db";
import { services } from "@/db/schema";
import { asc } from "drizzle-orm";
import { PageHeader } from "@/components/admin/admin-shell";
import { ServicesManager } from "@/components/admin/managers";

export const dynamic = "force-dynamic";
export const metadata = { title: "الخدمات — لوحة الإدارة" };

export default async function ServicesAdminPage() {
  const items = await db.select().from(services).orderBy(asc(services.sort), asc(services.createdAt));
  return (
    <div>
      <PageHeader title="الخدمات" description="أضف وعدّل الخدمات التي تظهر على الموقع — انشر فقط ما تقدمه فعليًا" />
      <ServicesManager items={items} />
    </div>
  );
}
