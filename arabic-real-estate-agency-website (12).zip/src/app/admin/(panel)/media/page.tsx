import { PageHeader } from "@/components/admin/admin-shell";
import { MediaManager } from "@/components/admin/media-manager";

export const dynamic = "force-dynamic";
export const metadata = { title: "مكتبة الوسائط — لوحة الإدارة" };

export default function MediaPage() {
  return (
    <div>
      <PageHeader title="مكتبة الوسائط" description="جميع الصور المرفوعة — يتم ضغطها تلقائيًا (WebP) لسرعة الموقع" />
      <MediaManager />
    </div>
  );
}
