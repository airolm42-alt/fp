import { getAboutSettings } from "@/lib/settings";
import { PageHeader } from "@/components/admin/admin-shell";
import { AboutForm } from "@/components/admin/settings-forms";

export const dynamic = "force-dynamic";
export const metadata = { title: "صفحة من نحن — لوحة الإدارة" };

export default async function AboutAdminPage() {
  const about = await getAboutSettings();
  return (
    <div>
      <PageHeader title="إدارة صفحة «من نحن»" description="اكتب قصة نشاطك ورسالتك ورؤيتك — تظهر كما هي على الموقع" />
      <AboutForm initial={about} />
    </div>
  );
}
