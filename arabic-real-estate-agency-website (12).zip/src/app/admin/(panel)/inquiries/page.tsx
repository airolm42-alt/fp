import { db } from "@/db";
import { inquiries } from "@/db/schema";
import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { PageHeader } from "@/components/admin/admin-shell";
import { InquiriesTable } from "@/components/admin/inquiries-table";
import { likePattern, pageNumber } from "@/lib/input-safety";

export const dynamic = "force-dynamic";
export const metadata = { title: "الاستفسارات — لوحة الإدارة" };

export default async function InquiriesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const status = typeof sp.status === "string" ? sp.status : "";
  const q = typeof sp.q === "string" ? sp.q.trim() : "";
  const page = pageNumber(typeof sp.page === "string" ? sp.page : "1");
  const limit = 20;

  const conds = [];
  if (status === "new" || status === "contacted" || status === "closed") conds.push(eq(inquiries.status, status));
  if (q) conds.push(or(ilike(inquiries.name, likePattern(q)), ilike(inquiries.phone, likePattern(q)), ilike(inquiries.message, likePattern(q))));
  const where = conds.length ? and(...conds) : undefined;

  const [rows, countRows] = await Promise.all([
    db.select().from(inquiries).where(where).orderBy(desc(inquiries.createdAt)).limit(limit).offset((page - 1) * limit),
    db.select({ count: sql<number>`count(*)` }).from(inquiries).where(where),
  ]);
  const total = Number(countRows[0]?.count ?? 0);

  return (
    <div>
      <PageHeader title="الاستفسارات" description="رسائل العملاء الواردة من نماذج التواصل بالموقع" />
      <InquiriesTable rows={rows} page={page} pages={Math.max(1, Math.ceil(total / limit))} total={total} />
    </div>
  );
}
