import { db } from "@/db";
import { propertyTypes } from "@/db/schema";
import { asc } from "drizzle-orm";
import { PageHeader } from "@/components/admin/admin-shell";
import { TypesManager } from "@/components/admin/managers";

export const dynamic = "force-dynamic";
export const metadata = { title: "أنواع العقارات — لوحة الإدارة" };

export default async function TypesAdminPage() {
  const items = await db.select().from(propertyTypes).orderBy(asc(propertyTypes.name));
  return (
    <div>
      <PageHeader title="أنواع العقارات" description="تصنيفات تُستخدم عند إضافة العقارات وفي فلاتر البحث بالموقع" />
      <TypesManager items={items} />
    </div>
  );
}
