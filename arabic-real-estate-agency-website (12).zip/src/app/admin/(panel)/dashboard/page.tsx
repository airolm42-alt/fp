import Link from "next/link";
import { db } from "@/db";
import { properties, inquiries } from "@/db/schema";
import { eq, sql, desc } from "drizzle-orm";
import { getAllSettings } from "@/lib/settings";
import { PageHeader } from "@/components/admin/admin-shell";
import { Card, Badge } from "@/components/ui";
import {
  Building2,
  CheckCircle2,
  Circle,
  Eye,
  FileEdit,
  Star,
  Inbox,
  PlusCircle,
  Store,
  Settings2,
  ArrowLeft,
} from "lucide-react";
import { formatDate } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "لوحة التحكم" };

const STATUS_LABEL: Record<string, { label: string; tone: "gold" | "blue" | "green" }> = {
  new: { label: "جديد", tone: "gold" },
  contacted: { label: "تم التواصل", tone: "blue" },
  closed: { label: "مغلق", tone: "green" },
};

export default async function DashboardPage() {
  const [counts, recent, { business }] = await Promise.all([
    Promise.all([
      db.select({ count: sql<number>`count(*)` }).from(properties),
      db.select({ count: sql<number>`count(*)` }).from(properties).where(eq(properties.status, "published")),
      db.select({ count: sql<number>`count(*)` }).from(properties).where(eq(properties.status, "draft")),
      db.select({ count: sql<number>`count(*)` }).from(properties).where(eq(properties.featured, true)),
      db.select({ count: sql<number>`count(*)` }).from(inquiries).where(eq(inquiries.status, "new")),
    ]),
    db.select().from(inquiries).orderBy(desc(inquiries.createdAt)).limit(5),
    getAllSettings(),
  ]);

  const [total, published, drafts, featured, newInquiries] = counts.map((c) => Number(c[0]?.count ?? 0));

  const setup = [
    { label: "اسم النشاط التجاري", done: !!business.businessName, href: "/admin/business" },
    { label: "رقم الهاتف", done: !!business.phone, href: "/admin/business" },
    { label: "رقم الواتساب", done: !!business.whatsapp, href: "/admin/business" },
    { label: "البريد الإلكتروني", done: !!business.email, href: "/admin/business" },
    { label: "العنوان", done: !!business.address, href: "/admin/business" },
    { label: "أول عقار منشور", done: published > 0, href: "/admin/properties/new" },
  ];
  const doneCount = setup.filter((s) => s.done).length;

  const stats = [
    { label: "إجمالي العقارات", value: total, icon: Building2, color: "bg-brand-700" },
    { label: "عقارات منشورة", value: published, icon: Eye, color: "bg-emerald-600" },
    { label: "مسودات", value: drafts, icon: FileEdit, color: "bg-stone-500" },
    { label: "عقارات مميزة", value: featured, icon: Star, color: "bg-gold-500" },
    { label: "استفسارات جديدة", value: newInquiries, icon: Inbox, color: "bg-sky-600" },
  ];

  return (
    <div>
      <PageHeader
        title="لوحة التحكم"
        description="نظرة عامة على أداء موقعك العقاري"
        action={
          <div className="flex flex-wrap items-center gap-2">
            <Link href="/admin/publishing#platform-publishing" className="inline-flex items-center gap-2 rounded-xl border border-brand-200 bg-white px-4 py-2.5 text-sm font-bold text-brand-800 shadow-sm transition hover:border-brand-500 hover:bg-brand-50">
              النشر والروابط <ArrowLeft className="h-4 w-4" />
            </Link>
            <Link href="/admin/properties/new" className="inline-flex items-center gap-2 rounded-xl bg-brand-700 px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-brand-800">
              <PlusCircle className="h-4 w-4" /> إضافة عقار
            </Link>
          </div>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-5">
        {stats.map((s) => (
          <Card key={s.label} className="p-4 sm:p-5">
            <div className={`mb-3 flex h-10 w-10 items-center justify-center rounded-xl text-white ${s.color}`}>
              <s.icon className="h-5 w-5" />
            </div>
            <p className="text-2xl font-black text-ink sm:text-3xl">{s.value}</p>
            <p className="mt-0.5 text-xs font-semibold text-stone-500 sm:text-sm">{s.label}</p>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        {/* Recent inquiries */}
        <Card className="lg:col-span-3">
          <div className="flex items-center justify-between border-b border-stone-100 px-5 py-4">
            <h2 className="text-base font-extrabold text-ink">أحدث الاستفسارات</h2>
            <Link href="/admin/inquiries" className="inline-flex items-center gap-1 text-xs font-bold text-brand-700 hover:text-brand-800">
              عرض الكل <ArrowLeft className="h-3.5 w-3.5" />
            </Link>
          </div>
          {recent.length === 0 ? (
            <p className="px-5 py-10 text-center text-sm text-stone-400">
              لا توجد استفسارات بعد — ستظهر رسائل العملاء هنا فور وصولها
            </p>
          ) : (
            <ul className="divide-y divide-stone-100">
              {recent.map((inq) => (
                <li key={inq.id} className="flex flex-wrap items-center gap-3 px-5 py-3.5">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-50 text-sm font-black text-brand-700">
                    {inq.name.slice(0, 1)}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold text-ink">{inq.name} <span className="font-medium text-stone-400" dir="ltr">{inq.phone}</span></p>
                    <p className="truncate text-xs text-stone-500">{inq.propertyTitle || inq.message}</p>
                  </div>
                  <div className="flex flex-col items-end gap-1">
                    <Badge tone={STATUS_LABEL[inq.status].tone}>{STATUS_LABEL[inq.status].label}</Badge>
                    <span className="text-[10px] text-stone-400">{formatDate(inq.createdAt)}</span>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </Card>

        {/* Setup checklist */}
        <Card className="lg:col-span-2">
          <div className="border-b border-stone-100 px-5 py-4">
            <h2 className="text-base font-extrabold text-ink">دليل إعداد الموقع</h2>
            <p className="mt-0.5 text-xs text-stone-500">
              أكمل {doneCount} من {setup.length} خطوات
            </p>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-stone-100">
              <div className="h-full rounded-full bg-gradient-to-l from-brand-600 to-gold-500 transition-all" style={{ width: `${(doneCount / setup.length) * 100}%` }} />
            </div>
          </div>
          <ul className="divide-y divide-stone-100">
            {setup.map((s) => (
              <li key={s.label}>
                <Link href={s.href} className="flex items-center gap-3 px-5 py-3 text-sm font-semibold transition hover:bg-stone-50">
                  {s.done ? (
                    <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-600" />
                  ) : (
                    <Circle className="h-5 w-5 shrink-0 text-stone-300" />
                  )}
                  <span className={s.done ? "text-stone-400 line-through" : "text-ink"}>{s.label}</span>
                </Link>
              </li>
            ))}
          </ul>
          <div className="flex gap-2 border-t border-stone-100 p-4">
            <Link href="/admin/business" className="flex-1 rounded-xl border border-stone-200 px-3 py-2 text-center text-xs font-bold text-ink transition hover:border-brand-500 hover:text-brand-700">
              <Store className="mx-auto mb-1 h-4 w-4" /> بيانات النشاط
            </Link>
            <Link href="/admin/settings" className="flex-1 rounded-xl border border-stone-200 px-3 py-2 text-center text-xs font-bold text-ink transition hover:border-brand-500 hover:text-brand-700">
              <Settings2 className="mx-auto mb-1 h-4 w-4" /> إعدادات الموقع
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
