import { db } from "@/db";
import { areas } from "@/db/schema";
import { asc } from "drizzle-orm";
import { PageHeader } from "@/components/admin/admin-shell";
import { AreasManager } from "@/components/admin/managers";

export const dynamic = "force-dynamic";
export const metadata = { title: "المناطق — لوحة الإدارة" };

export default async function AreasAdminPage() {
  const items = await db.select().from(areas).orderBy(asc(areas.sort), asc(areas.createdAt));
  return (
    <div>
      <PageHeader title="المناطق" description="المناطق التي يغطيها نشاطك وتظهر في قسم «مناطق نخدمها» بالرئيسية" />
      <AreasManager items={items} />
    </div>
  );
}
