import { getSeoSettings } from "@/lib/settings";
import { PageHeader } from "@/components/admin/admin-shell";
import { SeoForm } from "@/components/admin/settings-forms";

export const dynamic = "force-dynamic";
export const metadata = { title: "إعدادات SEO — لوحة الإدارة" };

export default async function SeoPage() {
  const seo = await getSeoSettings();
  return (
    <div>
      <PageHeader title="إعدادات SEO" description="تحكم في ظهور موقعك بمحركات البحث ومواقع التواصل" />
      <SeoForm initial={seo} />
    </div>
  );
}
