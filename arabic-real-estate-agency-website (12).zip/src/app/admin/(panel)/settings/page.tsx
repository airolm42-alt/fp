import { getSiteSettings } from "@/lib/settings";
import { PageHeader } from "@/components/admin/admin-shell";
import { SiteSettingsForm } from "@/components/admin/settings-forms";

export const dynamic = "force-dynamic";
export const metadata = { title: "إعدادات الموقع — لوحة الإدارة" };

export default async function SiteSettingsPage() {
  const site = await getSiteSettings();
  return (
    <div>
      <PageHeader title="إعدادات الموقع" description="محتوى الواجهة الرئيسية والنصوص العامة" />
      <SiteSettingsForm initial={site} />
    </div>
  );
}
