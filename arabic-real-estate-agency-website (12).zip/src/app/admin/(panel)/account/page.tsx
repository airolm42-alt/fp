import { getCurrentAdmin } from "@/lib/auth";
import { redirect } from "next/navigation";
import { PageHeader } from "@/components/admin/admin-shell";
import { ProfileForm, PasswordForm } from "@/components/admin/account-forms";
import { ShieldCheck, KeyRound } from "lucide-react";

export const dynamic = "force-dynamic";
export const metadata = { title: "حسابي — لوحة الإدارة" };

export default async function AccountPage() {
  const admin = await getCurrentAdmin();
  if (!admin) redirect("/admin/login");

  return (
    <div>
      <PageHeader title="حسابي" description="إدارة بيانات الدخول وكلمة المرور" />
      {admin.mustChangePassword && (
        <div className="mb-6 flex max-w-4xl items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm font-bold leading-relaxed text-amber-800">
          <KeyRound className="mt-0.5 h-4.5 w-4.5 shrink-0" />
          لأمان حسابك، يُرجى تغيير كلمة المرور المبدئية التي استلمتها إلى كلمة مرور خاصة بك الآن.
        </div>
      )}
      <div className="grid max-w-4xl gap-6 lg:grid-cols-2">
        <ProfileForm initialName={admin.name} initialEmail={admin.email} />
        <PasswordForm />
      </div>
      <div className="mt-6 flex max-w-4xl items-start gap-3 rounded-2xl border border-brand-200 bg-brand-50 p-4 text-xs leading-relaxed text-brand-800">
        <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0" />
        جلستك محمية وتنتهي تلقائيًا بعد 7 أيام من تسجيل الدخول. لا تشارك بيانات الدخول مع أي شخص.
      </div>
    </div>
  );
}
