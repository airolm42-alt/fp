import { db } from "@/db";
import { propertyTypes } from "@/db/schema";
import { PageHeader } from "@/components/admin/admin-shell";
import { PropertyForm, EMPTY_PROPERTY } from "@/components/admin/property-form";

export const dynamic = "force-dynamic";
export const metadata = { title: "إضافة عقار — لوحة الإدارة" };

export default async function NewPropertyPage() {
  const types = await db.select().from(propertyTypes).orderBy(propertyTypes.name);
  return (
    <div>
      <PageHeader title="إضافة عقار جديد" description="املأ بيانات العقار ثم احفظه كمسودة أو انشره مباشرة" />
      <PropertyForm initial={EMPTY_PROPERTY} types={types} />
    </div>
  );
}
