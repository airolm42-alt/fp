import Link from "next/link";
import { db } from "@/db";
import { properties, propertyTypes } from "@/db/schema";
import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { PageHeader } from "@/components/admin/admin-shell";
import { PropertiesTable } from "@/components/admin/properties-table";
import { PlusCircle } from "lucide-react";
import { isUuid, likePattern, pageNumber } from "@/lib/input-safety";

export const dynamic = "force-dynamic";
export const metadata = { title: "العقارات — لوحة الإدارة" };

export default async function AdminPropertiesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const q = typeof sp.q === "string" ? sp.q.trim() : "";
  const status = typeof sp.status === "string" ? sp.status : "";
  const listing = typeof sp.listing === "string" ? sp.listing : "";
  const type = typeof sp.type === "string" ? sp.type : "";
  const page = pageNumber(typeof sp.page === "string" ? sp.page : "1");
  const limit = 15;

  const conds = [];
  if (q) conds.push(or(ilike(properties.title, likePattern(q)), ilike(properties.location, likePattern(q))));
  if (status === "draft" || status === "published") conds.push(eq(properties.status, status));
  if (listing === "sale" || listing === "rent") conds.push(eq(properties.listingType, listing));
  if (type) conds.push(isUuid(type) ? eq(properties.typeId, type) : sql`false`);
  const where = conds.length ? and(...conds) : undefined;

  const [rows, countRows, types] = await Promise.all([
    db
      .select({
        id: properties.id,
        title: properties.title,
        slug: properties.slug,
        listingType: properties.listingType,
        price: properties.price,
        currency: properties.currency,
        location: properties.location,
        status: properties.status,
        featured: properties.featured,
        mainImage: properties.mainImage,
        createdAt: properties.createdAt,
        typeName: propertyTypes.name,
      })
      .from(properties)
      .leftJoin(propertyTypes, eq(properties.typeId, propertyTypes.id))
      .where(where)
      .orderBy(desc(properties.createdAt))
      .limit(limit)
      .offset((page - 1) * limit),
    db.select({ count: sql<number>`count(*)` }).from(properties).where(where),
    db.select().from(propertyTypes).orderBy(propertyTypes.name),
  ]);

  const total = Number(countRows[0]?.count ?? 0);

  return (
    <div>
      <PageHeader
        title="العقارات"
        description="إدارة جميع عقاراتك: نشر، تمييز، تعديل وحذف"
        action={
          <Link
            href="/admin/properties/new"
            className="inline-flex items-center gap-2 rounded-xl bg-brand-700 px-4 py-2.5 text-sm font-bold text-white shadow-sm transition hover:bg-brand-800"
          >
            <PlusCircle className="h-4 w-4" /> إضافة عقار
          </Link>
        }
      />
      <PropertiesTable
        rows={rows.map((r) => ({ ...r, typeName: r.typeName ?? null }))}
        types={types}
        page={page}
        pages={Math.max(1, Math.ceil(total / limit))}
        total={total}
      />
    </div>
  );
}
