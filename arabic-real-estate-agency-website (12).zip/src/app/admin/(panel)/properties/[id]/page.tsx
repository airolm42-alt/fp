import { notFound } from "next/navigation";
import { db } from "@/db";
import { properties, propertyImages, propertyTypes } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { PageHeader } from "@/components/admin/admin-shell";
import { PropertyForm, type PropertyFormInitial } from "@/components/admin/property-form";
import { isUuid } from "@/lib/input-safety";
export const dynamic = "force-dynamic";
export const metadata = { title: "تعديل عقار — لوحة الإدارة" };
export default async function EditPropertyPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!isUuid(id)) notFound();
  const [rows, images, types] = await Promise.all([
    db.select().from(properties).where(eq(properties.id, id)).limit(1),
    db.select().from(propertyImages).where(eq(propertyImages.propertyId, id)).orderBy(asc(propertyImages.sort)),
    db.select().from(propertyTypes).orderBy(propertyTypes.name),
  ]);
  const p = rows[0]; if (!p) notFound();
  const gallery = images.map((image) => ({ url: image.url, alt: image.alt }));
  if (p.mainImage && !gallery.some((image) => image.url === p.mainImage)) gallery.unshift({ url: p.mainImage, alt: p.title });
  else if (p.mainImage) gallery.sort((a, b) => Number(b.url === p.mainImage) - Number(a.url === p.mainImage));
  const initial: PropertyFormInitial = {
    id: p.id, title: p.title, slug: p.slug, description: p.description, typeId: p.typeId ?? "", listingType: p.listingType,
    price: p.price ?? "", currency: p.currency, location: p.location, address: p.address, area: p.area ?? "",
    bedrooms: p.bedrooms == null ? "" : String(p.bedrooms), bathrooms: p.bathrooms == null ? "" : String(p.bathrooms),
    floor: p.floor, finishing: p.finishing, features: p.features ?? [], images: gallery,
    googleMapsUrl: p.googleMapsUrl, whatsappMessage: p.whatsappMessage, status: p.status, featured: p.featured,
    metaTitle: p.metaTitle, metaDescription: p.metaDescription,
  };
  return <div><PageHeader title="تعديل العقار" description={p.title} /><PropertyForm initial={initial} types={types} /></div>;
}
