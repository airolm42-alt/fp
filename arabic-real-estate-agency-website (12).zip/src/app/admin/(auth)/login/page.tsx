import { Suspense } from "react";
import type { Metadata } from "next";
import { LoginForm } from "@/components/admin/login-form";

export const metadata: Metadata = { title: "تسجيل الدخول — لوحة الإدارة", robots: { index: false } };

export default function LoginPage() {
  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-brand-950 px-4 py-10 pattern-arabesque">
      <div className="pointer-events-none absolute -top-40 start-1/2 h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-brand-600/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 end-0 h-[400px] w-[400px] rounded-full bg-gold-500/10 blur-3xl" />
      <div className="relative z-10 w-full max-w-md animate-rise">
        <Suspense fallback={null}>
          <LoginForm />
        </Suspense>
        <p className="mt-6 text-center text-xs text-brand-100/40">
          منطقة مخصصة لإدارة الموقع فقط — الدخول للمشرفين المعتمدين
        </p>
      </div>
    </div>
  );
}
