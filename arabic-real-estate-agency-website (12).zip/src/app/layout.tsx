import type { Metadata } from "next";
import type { ReactNode } from "react";
import { getSiteUrl } from "@/lib/site-url";
import "./globals.css";

// Fresh hosting databases are initialized after building; never query public
// content tables during prerendering before production migrations are applied.
export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const base = await getSiteUrl();
  return {
    metadataBase: new URL(base),
    title: { default: "موقع عقاري", template: "%s" },
    icons: { icon: [{ url: "/favicon.svg", type: "image/svg+xml" }] },
  };
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen bg-sand text-ink antialiased">{children}</body>
    </html>
  );
}
