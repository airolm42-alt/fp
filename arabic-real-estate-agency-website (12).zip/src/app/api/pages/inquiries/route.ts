import { NextRequest, NextResponse } from "next/server";
import { POST as saveInquiry } from "@/app/api/inquiries/route";
import { allowedPagesWrite, pagesHeaders } from "@/lib/pages-access";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function OPTIONS(req: NextRequest) {
  if (!allowedPagesWrite(req)) return NextResponse.json({ error: "أصل الواجهة غير مفعّل لإرسال الاستفسارات" }, { status: 403 });
  return new Response(null, { status: 204, headers: pagesHeaders(req.headers.get("origin")!) });
}
export async function POST(req: NextRequest) {
  if (!allowedPagesWrite(req)) return NextResponse.json({ error: "فعّل أصل واجهة Pages في PAGES_ALLOWED_ORIGINS على الخادم أو استخدم نموذج التواصل الآمن." }, { status: 403 });
  const response = await saveInquiry(req);
  const headers = new Headers(response.headers);
  pagesHeaders(req.headers.get("origin")!).forEach((value, key) => headers.set(key, value));
  return new Response(response.body, { status: response.status, headers });
}
