import { NextRequest } from "next/server";
import { getAllSettings } from "@/lib/settings";
import { getAllPropertyTypes, getDistinctLocations, getFeaturedProperties, getPropertyBySlug, getPublishedAreas, getPublishedProperties, getPublishedServices, getSimilarProperties } from "@/lib/public-data";
import { absoluteMedia, allowedPagesWrite, backendOrigin, publicPagesJson } from "@/lib/pages-access";
import type { PagesConfig, PagesDetails } from "@/lib/pages-contract";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Read-only public bridge. No draft content, admin profiles, inquiries or secrets. */
export async function GET(req: NextRequest) {
  try {
    const origin = backendOrigin(req);
    const sp = req.nextUrl.searchParams;
    const resource = sp.get("resource") || "config";
    if (resource === "config") {
      const [{ business, about, site, seo }, services, areas, types, locations, featured] = await Promise.all([
        getAllSettings(), getPublishedServices(), getPublishedAreas(), getAllPropertyTypes(), getDistinctLocations(), getFeaturedProperties(6),
      ]);
      const configuration: PagesConfig = {
        version: 1, backendOrigin: origin, adminUrl: `${origin}/admin`, contactUrl: `${origin}/contact`, inquiriesEnabled: allowedPagesWrite(req),
        business, about, site, seo: { siteTitle: seo.siteTitle, siteDescription: seo.siteDescription, keywords: seo.keywords, ogImage: seo.ogImage },
        services: services.map(({ id, title, description, icon, image }) => ({ id, title, description, icon, image })),
        areas: areas.map(({ id, name, description, image }) => ({ id, name, description, image })),
        types: types.map(({ id, name, slug }) => ({ id, name, slug })), locations, featured,
      };
      return publicPagesJson(absoluteMedia(configuration, origin));
    }
    if (resource === "properties") {
      const get = (key: string) => sp.get(key)?.slice(0, 300) || undefined;
      const result = await getPublishedProperties({ q: get("q"), listing: get("listing"), type: get("type"), location: get("location"), minPrice: get("minPrice"), maxPrice: get("maxPrice"), beds: get("beds"), baths: get("baths"), minArea: get("minArea"), maxArea: get("maxArea"), sort: get("sort"), page: Number(get("page") ?? 1), featuredOnly: get("featured") === "1" });
      return publicPagesJson(absoluteMedia(result, origin));
    }
    if (resource === "property") {
      const slug = sp.get("slug");
      if (!slug || slug.length > 120) return publicPagesJson({ error: "رابط العقار غير صالح" }, 400);
      const property = await getPropertyBySlug(slug);
      if (!property) return publicPagesJson({ error: "العقار غير متاح أو لم يعد منشورًا" }, 404);
      const similar = await getSimilarProperties(property);
      const result: PagesDetails = { property: {
        id: property.id, title: property.title, slug: property.slug, description: property.description,
        listingType: property.listingType, typeName: property.typeName, price: property.price, currency: property.currency,
        location: property.location, area: property.area, bedrooms: property.bedrooms, bathrooms: property.bathrooms,
        mainImage: property.mainImage, featured: property.featured, address: property.address, floor: property.floor,
        finishing: property.finishing, features: property.features, googleMapsUrl: property.googleMapsUrl,
        whatsappMessage: property.whatsappMessage, images: property.images.map(({ url, alt }) => ({ url, alt })),
      }, similar };
      return publicPagesJson(absoluteMedia(result, origin));
    }
    return publicPagesJson({ error: "المورد المطلوب غير موجود" }, 404);
  } catch (error) {
    console.error("Pages public read failed", error instanceof Error ? error.message : "unknown error");
    return publicPagesJson({ error: "تعذّر الاتصال ببيانات الموقع. حاول مرة أخرى لاحقًا." }, 503);
  }
}
export async function OPTIONS() { return new Response(null, { status: 204, headers: { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Methods": "GET, OPTIONS", "Access-Control-Allow-Headers": "Content-Type", "Vary": "Origin" } }); }
