import { NextResponse } from "next/server";
import { getCurrentAdmin } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Lightweight check used by the login form to confirm the cookie was stored. */
export async function GET() {
  const admin = await getCurrentAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  return NextResponse.json({ ok: true, name: admin.name, email: admin.email });
}
