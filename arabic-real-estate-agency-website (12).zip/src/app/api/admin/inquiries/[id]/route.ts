import { NextRequest, NextResponse } from "next/server";
import { apiError, readJsonBody } from "@/lib/http";
import { isUuid } from "@/lib/input-safety";
import { db } from "@/db";
import { inquiries } from "@/db/schema";
import { eq } from "drizzle-orm";
import { inquiryStatusSchema } from "@/lib/validators";
import { requireAdmin } from "@/lib/auth";
import { revalidatePath } from "next/cache";

export const runtime = "nodejs";

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await ctx.params;
  if (!isUuid(id)) return NextResponse.json({ error: "معرّف غير صالح" }, { status: 400 });
  const [exists] = await db.select({ id: inquiries.id }).from(inquiries).where(eq(inquiries.id, id)).limit(1);
  if (!exists) return NextResponse.json({ error: "العنصر غير موجود" }, { status: 404 });
  let body;
  try { body = await readJsonBody(req); } catch (error) { return apiError(error); }
  const parsed = inquiryStatusSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "بيانات غير صحيحة" }, { status: 400 });
  await db.update(inquiries).set({ status: parsed.data.status }).where(eq(inquiries.id, id));
  revalidatePath("/admin/dashboard", "page");
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await ctx.params;
  if (!isUuid(id)) return NextResponse.json({ error: "معرّف غير صالح" }, { status: 400 });
  const [exists] = await db.select({ id: inquiries.id }).from(inquiries).where(eq(inquiries.id, id)).limit(1);
  if (!exists) return NextResponse.json({ error: "العنصر غير موجود" }, { status: 404 });
  await db.delete(inquiries).where(eq(inquiries.id, id));
  revalidatePath("/admin/dashboard", "page");
  return NextResponse.json({ ok: true });
}
