import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { inquiries } from "@/db/schema";
import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { pageNumber, likePattern } from "@/lib/input-safety";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });

  const sp = req.nextUrl.searchParams;
  const status = sp.get("status") ?? "";
  const q = sp.get("q")?.trim() ?? "";
  const page = pageNumber(sp.get("page"));
  const limit = 20;

  const conds = [];
  if (status === "new" || status === "contacted" || status === "closed")
    conds.push(eq(inquiries.status, status));
  if (q)
    conds.push(
      or(
        ilike(inquiries.name, likePattern(q)),
        ilike(inquiries.phone, likePattern(q)),
        ilike(inquiries.message, likePattern(q)),
      ),
    );
  const where = conds.length ? and(...conds) : undefined;

  const [rows, countRows] = await Promise.all([
    db
      .select()
      .from(inquiries)
      .where(where)
      .orderBy(desc(inquiries.createdAt))
      .limit(limit)
      .offset((page - 1) * limit),
    db.select({ count: sql<number>`count(*)` }).from(inquiries).where(where),
  ]);

  return NextResponse.json({
    items: rows,
    total: Number(countRows[0]?.count ?? 0),
    page,
    pages: Math.max(1, Math.ceil(Number(countRows[0]?.count ?? 0) / limit)),
  });
}
