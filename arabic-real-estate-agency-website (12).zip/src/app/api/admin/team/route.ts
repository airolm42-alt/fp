import { NextRequest, NextResponse } from "next/server";
import { apiError, readJsonBody } from "@/lib/http";
import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { asc, eq } from "drizzle-orm";
import { createAdminSchema } from "@/lib/validators";
import { requireAdmin, hashPassword } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** List admin accounts. Any signed-in admin may view the team. */
export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });

  const rows = await db
    .select({
      id: adminUsers.id,
      name: adminUsers.name,
      email: adminUsers.email,
      isOwner: adminUsers.isOwner,
      mustChangePassword: adminUsers.mustChangePassword,
      lastLoginAt: adminUsers.lastLoginAt,
      createdAt: adminUsers.createdAt,
    })
    .from(adminUsers)
    .orderBy(asc(adminUsers.createdAt));

  return NextResponse.json({ items: rows, currentId: admin.id, isOwner: admin.isOwner });
}

/**
 * Create a new admin account.
 * Restricted to the owner account ("بأمر من الأدمن القديم").
 */
export async function POST(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  if (!admin.isOwner) {
    return NextResponse.json(
      { error: "لا تملك صلاحية إضافة مشرفين. هذه الصلاحية للمالك الأساسي فقط." },
      { status: 403 },
    );
  }

  let body;
  try { body = await readJsonBody(req); } catch (error) { return apiError(error); }
  const parsed = createAdminSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" },
      { status: 400 },
    );
  }

  const email = parsed.data.email.trim().toLowerCase();
  const exists = await db.select({ id: adminUsers.id }).from(adminUsers).where(eq(adminUsers.email, email)).limit(1);
  if (exists[0]) {
    return NextResponse.json({ error: "هذا البريد مسجّل بالفعل كمشرف" }, { status: 409 });
  }

  const [created] = await db
    .insert(adminUsers)
    .values({
      name: parsed.data.name.trim(),
      email,
      passwordHash: await hashPassword(parsed.data.password),
      isOwner: false,
      createdBy: admin.id,
      mustChangePassword: parsed.data.mustChangePassword,
    })
    .returning({ id: adminUsers.id });

  return NextResponse.json({ ok: true, id: created.id });
}
