import { NextRequest, NextResponse } from "next/server";
import { apiError, readJsonBody } from "@/lib/http";
import { isUuid } from "@/lib/input-safety";
import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { resetAdminPasswordSchema } from "@/lib/validators";
import { requireAdmin, hashPassword } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Owner-only: reset another admin's password. */
export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  if (!admin.isOwner) {
    return NextResponse.json({ error: "هذه الصلاحية للمالك الأساسي فقط" }, { status: 403 });
  }

  const { id } = await ctx.params;
  if (!isUuid(id)) return NextResponse.json({ error: "معرّف غير صالح" }, { status: 400 });
  if (id === admin.id) {
    return NextResponse.json(
      { error: "لتغيير كلمة مرورك الخاصة استخدم صفحة «حسابي»" },
      { status: 400 },
    );
  }

  const target = await db.select().from(adminUsers).where(eq(adminUsers.id, id)).limit(1);
  if (!target[0]) return NextResponse.json({ error: "المشرف غير موجود" }, { status: 404 });
  if (target[0].isOwner) {
    return NextResponse.json({ error: "لا يمكن تعديل حساب المالك" }, { status: 403 });
  }

  let body;
  try { body = await readJsonBody(req); } catch (error) { return apiError(error); }
  const parsed = resetAdminPasswordSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" },
      { status: 400 },
    );
  }

  await db
    .update(adminUsers)
    .set({
      passwordHash: await hashPassword(parsed.data.password),
      mustChangePassword: true,
      updatedAt: new Date(),
    })
    .where(eq(adminUsers.id, id));

  return NextResponse.json({ ok: true });
}

/** Owner-only: revoke an admin account. */
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  if (!admin.isOwner) {
    return NextResponse.json({ error: "هذه الصلاحية للمالك الأساسي فقط" }, { status: 403 });
  }

  const { id } = await ctx.params;
  if (!isUuid(id)) return NextResponse.json({ error: "معرّف غير صالح" }, { status: 400 });
  if (id === admin.id) {
    return NextResponse.json({ error: "لا يمكنك حذف حسابك الخاص" }, { status: 400 });
  }

  const target = await db.select().from(adminUsers).where(eq(adminUsers.id, id)).limit(1);
  if (!target[0]) return NextResponse.json({ error: "المشرف غير موجود" }, { status: 404 });
  if (target[0].isOwner) {
    return NextResponse.json({ error: "لا يمكن حذف حساب المالك الأساسي" }, { status: 403 });
  }

  await db.delete(adminUsers).where(eq(adminUsers.id, id));
  return NextResponse.json({ ok: true });
}
