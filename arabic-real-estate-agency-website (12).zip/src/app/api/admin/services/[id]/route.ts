import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { services } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { assertMediaReferences } from "@/lib/media-references";
import { serviceInputSchema } from "@/lib/validators";
import { requireAdmin } from "@/lib/auth";
import { apiError, readJsonBody } from "@/lib/http";
import { isUuid } from "@/lib/input-safety";
import { revalidatePath } from "next/cache";
export const runtime = "nodejs";
export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await ctx.params;
  if (!isUuid(id)) return NextResponse.json({ error: "معرّف غير صالح" }, { status: 400 });
  try {
    const parsed = serviceInputSchema.safeParse(await readJsonBody(req));
    if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" }, { status: 400 });
    const rows = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(7410032)`);
      await assertMediaReferences(parsed.data, tx);
      return tx.update(services).set({ ...parsed.data, updatedAt: new Date() }).where(eq(services.id, id)).returning({ id: services.id });
    });
    if (!rows.length) return NextResponse.json({ error: "الخدمة غير موجودة" }, { status: 404 });
    revalidatePath("/", "layout");
    return NextResponse.json({ ok: true });
  } catch (error) { return apiError(error, "تعذّر حفظ الخدمة"); }
}
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await ctx.params;
  if (!isUuid(id)) return NextResponse.json({ error: "معرّف غير صالح" }, { status: 400 });
  try {
    const rows = await db.delete(services).where(eq(services.id, id)).returning({ id: services.id });
    if (!rows.length) return NextResponse.json({ error: "الخدمة غير موجودة" }, { status: 404 });
    revalidatePath("/", "layout"); return NextResponse.json({ ok: true });
  } catch (error) { return apiError(error, "تعذّر حذف الخدمة"); }
}
