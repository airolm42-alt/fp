import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { eq } from "drizzle-orm";
import { loginSchema } from "@/lib/validators";
import { verifyPassword, createSessionToken, setSessionCookie } from "@/lib/auth";
import { ensureAdminExists } from "@/lib/ensure-admin";
import { clientIp, consumeLimit } from "@/lib/rate-limit";
import { apiError, readJsonBody } from "@/lib/http";

export async function POST(req: NextRequest) {
  try {
    const parsed = loginSchema.safeParse(await readJsonBody(req, 8 * 1024));
    if (!parsed.success) return NextResponse.json({ error: "بيانات الدخول غير صالحة" }, { status: 400 });
    const email = parsed.data.email.toLowerCase();
    const [byIp, byAccount] = await Promise.all([
      consumeLimit("login-ip", clientIp(req.headers), 60, 900),
      consumeLimit("login-account", email, 12, 900),
    ]);
    if (!byIp.allowed || !byAccount.allowed) return NextResponse.json({ error: "محاولات كثيرة؛ انتظر قليلًا ثم حاول مرة أخرى" }, { status: 429, headers: { "Retry-After": String(Math.max(byIp.retryAfter, byAccount.retryAfter)) } });
    await ensureAdminExists();
    const [admin] = await db.select().from(adminUsers).where(eq(adminUsers.email, email)).limit(1);
    // Equalize missing-account password comparison to avoid a fast email probe.
    const dummyHash = "$2b$12$IbIJXxR97lvPQBJxNnKMLe61BwKpt7ijJYmvbXArTKvc.81qS98b2";
    const ok = await verifyPassword(parsed.data.password, admin?.passwordHash ?? dummyHash);
    if (!ok || !admin) return NextResponse.json({ error: "البريد الإلكتروني أو كلمة المرور غير صحيحة" }, { status: 401 });
    await db.update(adminUsers).set({ lastLoginAt: new Date() }).where(eq(adminUsers.id, admin.id));
    await setSessionCookie(await createSessionToken(admin));
    return NextResponse.json({ ok: true, name: admin.name, mustChangePassword: admin.mustChangePassword });
  } catch (error) { return apiError(error, "تعذّر تسجيل الدخول. تحقق من إعدادات الخادم أو حاول مرة أخرى"); }
}
