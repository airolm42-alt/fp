import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { settings } from "@/db/schema";
import {
  businessSettingsSchema, aboutSettingsSchema, siteSettingsSchema, seoSettingsSchema,
  getSeoSettings, saveSetting,
} from "@/lib/settings";
import { requireAdmin } from "@/lib/auth";
import { normalizeSiteOrigin, siteOriginKind } from "@/lib/site-origin";
import { revalidatePath } from "next/cache";
import { assertMediaReferences } from "@/lib/media-references";
import { readJsonBody, apiError } from "@/lib/http";

export const runtime = "nodejs";
const bodySchema = z.discriminatedUnion("section", [
  z.object({ section: z.literal("business"), data: businessSettingsSchema }),
  z.object({ section: z.literal("about"), data: aboutSettingsSchema }),
  z.object({ section: z.literal("site"), data: siteSettingsSchema }),
  z.object({ section: z.literal("seo"), data: seoSettingsSchema }),
]);

export async function PUT(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  let body;
  try { body = await readJsonBody(req); } catch (error) { return apiError(error); }
  const parsed = bodySchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "بيانات غير صحيحة" }, { status: 400 });

  try {
    if (parsed.data.section === "seo") {
      const current = await getSeoSettings();
      const rawData = body && typeof body === "object" && "data" in body ? body.data : null;
      const suppliedDomain = !!rawData && typeof rawData === "object" && Object.prototype.hasOwnProperty.call(rawData, "siteUrl");
      const requestedDomain = suppliedDomain ? parsed.data.data.siteUrl.trim() : current.siteUrl;
      const normalized = requestedDomain ? normalizeSiteOrigin(requestedDomain) : "";
      if (requestedDomain && (!normalized || siteOriginKind(normalized) !== "public")) {
        return NextResponse.json({ error: "رابط الإنتاج يجب أن يكون دومينًا صالحًا، وليس عنوان معاينة" }, { status: 400 });
      }
      const oldNormalized = current.siteUrl ? normalizeSiteOrigin(current.siteUrl) : "";
      if (normalized !== oldNormalized && !admin.isOwner) {
        return NextResponse.json({ error: "تغيير عنوان الإنتاج متاح للمالك فقط" }, { status: 403 });
      }
      if (parsed.data.data.googleAnalyticsId && !/^G-[A-Z0-9]{4,32}$/.test(parsed.data.data.googleAnalyticsId)) {
        return NextResponse.json({ error: "معرّف Google Analytics غير صالح؛ استخدم صيغة G-XXXXXXXXXX" }, { status: 400 });
      }
      const seoData = { ...parsed.data.data, siteUrl: normalized };
      if (admin.isOwner) {
        await saveSetting("seo", seoData);
      } else {
        // Preserve the domain atomically, even if the owner changes it while a
        // staff member's older SEO form is still being saved.
        await db.transaction(async (tx) => {
          await tx.execute(sql`select pg_advisory_xact_lock(7410032)`);
          await assertMediaReferences(seoData, tx);
          await tx.insert(settings).values({ key: "seo", value: seoData, updatedAt: new Date() })
            .onConflictDoUpdate({ target: settings.key, set: {
              value: sql`(${JSON.stringify(seoData)}::jsonb - 'siteUrl') || jsonb_build_object('siteUrl', coalesce(${settings.value}->'siteUrl', '""'::jsonb))`,
              updatedAt: new Date(),
            } });
        });
      }
      revalidatePath("/sitemap.xml");
      revalidatePath("/robots.txt");
    } else {
      await saveSetting(parsed.data.section, parsed.data.data);
    }
    revalidatePath("/", "layout");
    return NextResponse.json({ ok: true });
  } catch (error) {
    return apiError(error, "تعذّر حفظ الإعدادات");
  }
}
