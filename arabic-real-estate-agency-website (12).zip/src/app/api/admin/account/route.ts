import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { adminUsers } from "@/db/schema";
import { eq, ne, and } from "drizzle-orm";
import { accountProfileSchema, accountPasswordSchema } from "@/lib/validators";
import { requireAdmin, verifyPassword, hashPassword, createSessionToken, setSessionCookie } from "@/lib/auth";
import { apiError, readJsonBody } from "@/lib/http";
import { z } from "zod";

export const runtime = "nodejs";
const actionSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("profile"), data: accountProfileSchema }),
  z.object({ action: z.literal("password"), data: accountPasswordSchema }),
]);
export async function PUT(req: NextRequest) {
  const admin = await requireAdmin({ allowPasswordChange: true });
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  try {
    const parsed = actionSchema.safeParse(await readJsonBody(req, 16 * 1024));
    if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" }, { status: 400 });
    if (parsed.data.action === "profile") {
      if (admin.mustChangePassword) return NextResponse.json({ error: "غيّر كلمة المرور المبدئية أولًا" }, { status: 403 });
      const email = parsed.data.data.email.toLowerCase();
      const [duplicate] = await db.select({ id: adminUsers.id }).from(adminUsers).where(and(eq(adminUsers.email, email), ne(adminUsers.id, admin.id))).limit(1);
      if (duplicate) return NextResponse.json({ error: "هذا البريد مستخدم بالفعل" }, { status: 409 });
      const [updated] = await db.update(adminUsers).set({ name: parsed.data.data.name, email, updatedAt: new Date() }).where(eq(adminUsers.id, admin.id)).returning();
      await setSessionCookie(await createSessionToken(updated));
      return NextResponse.json({ ok: true });
    }
    if (!await verifyPassword(parsed.data.data.currentPassword, admin.passwordHash)) return NextResponse.json({ error: "كلمة المرور الحالية غير صحيحة" }, { status: 400 });
    if (await verifyPassword(parsed.data.data.newPassword, admin.passwordHash)) return NextResponse.json({ error: "اختر كلمة مرور جديدة مختلفة" }, { status: 400 });
    const [updated] = await db.update(adminUsers).set({ passwordHash: await hashPassword(parsed.data.data.newPassword), mustChangePassword: false, updatedAt: new Date() }).where(eq(adminUsers.id, admin.id)).returning();
    await setSessionCookie(await createSessionToken(updated));
    return NextResponse.json({ ok: true });
  } catch (error) { return apiError(error, "تعذّر تحديث الحساب"); }
}
