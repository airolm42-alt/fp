import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { mediaFiles, properties, propertyImages, services, areas, settings } from "@/db/schema";
import { desc, inArray, sql } from "drizzle-orm";
import { requireAdmin } from "@/lib/auth";
import { getUploadsDirectory } from "@/lib/uploads-dir";
import { apiError, readJsonBody, RequestError } from "@/lib/http";
import { pageNumber } from "@/lib/input-safety";
import { unlink } from "node:fs/promises";
import path from "node:path";
import { z } from "zod";
export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  try {
    const page = pageNumber(req.nextUrl.searchParams.get("page")), limit = 48;
    const [items, counts] = await Promise.all([
      db.select().from(mediaFiles).orderBy(desc(mediaFiles.createdAt)).limit(limit).offset((page - 1) * limit),
      db.select({ count: sql<number>`count(*)` }).from(mediaFiles),
    ]);
    const total = Number(counts[0]?.count ?? 0);
    return NextResponse.json({ items, total, page, pages: Math.max(1, Math.ceil(total / limit)) });
  } catch (error) { return apiError(error, "تعذّر تحميل الوسائط"); }
}
const deleteSchema = z.object({ ids: z.array(z.string().uuid()).min(1).max(100) });
function containsReference(value: unknown, urls: Set<string>): boolean {
  if (typeof value === "string") return urls.has(value);
  if (Array.isArray(value)) return value.some((entry) => containsReference(entry, urls));
  if (value && typeof value === "object") return Object.values(value).some((entry) => containsReference(entry, urls));
  return false;
}
export async function DELETE(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  try {
    const parsed = deleteSchema.safeParse(await readJsonBody(req));
    if (!parsed.success) throw new RequestError("معرّفات صور غير صالحة");
    const deleted = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(7410032)`);
      const files = await tx.select().from(mediaFiles).where(inArray(mediaFiles.id, [...new Set(parsed.data.ids)]));
      if (!files.length) throw new RequestError("الصور غير موجودة", 404);
      const urls = files.map((file) => file.url);
      const [propertyRows, galleries, serviceRows, areaRows, config] = await Promise.all([
        tx.select({ id: properties.id }).from(properties).where(inArray(properties.mainImage, urls)).limit(1),
        tx.select({ id: propertyImages.id }).from(propertyImages).where(inArray(propertyImages.url, urls)).limit(1),
        tx.select({ id: services.id }).from(services).where(inArray(services.image, urls)).limit(1),
        tx.select({ id: areas.id }).from(areas).where(inArray(areas.image, urls)).limit(1),
        tx.select({ value: settings.value }).from(settings),
      ]);
      if (propertyRows.length || galleries.length || serviceRows.length || areaRows.length || config.some((row) => containsReference(row.value, new Set(urls)))) throw new RequestError("إحدى الصور مستخدمة في عقار أو محتوى الموقع. أزل ارتباطها أولًا؛ لم يتم حذف أي صورة.", 409);
      await tx.delete(mediaFiles).where(inArray(mediaFiles.id, files.map((file) => file.id)));
      return files;
    });
    await Promise.all(deleted.map((file) => {
      const name = file.url.replace(/^\/uploads\//, "");
      return /^[\w-]+\.webp$/.test(name) ? unlink(path.join(getUploadsDirectory(), name)).catch(() => {}) : Promise.resolve();
    }));
    return NextResponse.json({ ok: true });
  } catch (error) { return apiError(error, "تعذّر حذف الصور"); }
}
