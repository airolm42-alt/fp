import { NextRequest, NextResponse } from "next/server";
import { apiError, readJsonBody } from "@/lib/http";
import { isUuid } from "@/lib/input-safety";
import { db } from "@/db";
import { propertyTypes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { typeInputSchema } from "@/lib/validators";
import { slugify } from "@/lib/utils";
import { requireAdmin } from "@/lib/auth";
import { revalidatePath } from "next/cache";

export const runtime = "nodejs";

export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await ctx.params;
  if (!isUuid(id)) return NextResponse.json({ error: "معرّف غير صالح" }, { status: 400 });
  const [exists] = await db.select({ id: propertyTypes.id }).from(propertyTypes).where(eq(propertyTypes.id, id)).limit(1);
  if (!exists) return NextResponse.json({ error: "العنصر غير موجود" }, { status: 404 });
  let body;
  try { body = await readJsonBody(req); } catch (error) { return apiError(error); }
  const parsed = typeInputSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" }, { status: 400 });
  }
  try {
    await db.update(propertyTypes).set({ name: parsed.data.name, slug: slugify(parsed.data.slug || parsed.data.name) || undefined }).where(eq(propertyTypes.id, id));
  } catch (error) { return apiError(error, "تعذّر حفظ النوع"); }
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true });
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await ctx.params;
  if (!isUuid(id)) return NextResponse.json({ error: "معرّف غير صالح" }, { status: 400 });
  const [exists] = await db.select({ id: propertyTypes.id }).from(propertyTypes).where(eq(propertyTypes.id, id)).limit(1);
  if (!exists) return NextResponse.json({ error: "العنصر غير موجود" }, { status: 404 });
  await db.delete(propertyTypes).where(eq(propertyTypes.id, id));
  revalidatePath("/", "layout");
  return NextResponse.json({ ok: true });
}
