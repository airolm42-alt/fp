import { NextRequest, NextResponse } from "next/server";
import { apiError, readJsonBody } from "@/lib/http";
import { db } from "@/db";
import { propertyTypes } from "@/db/schema";
import { asc } from "drizzle-orm";
import { typeInputSchema } from "@/lib/validators";
import { slugify, uniqueSlug } from "@/lib/utils";
import { requireAdmin } from "@/lib/auth";
import { revalidatePath } from "next/cache";

export const runtime = "nodejs";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const rows = await db.select().from(propertyTypes).orderBy(asc(propertyTypes.name));
  return NextResponse.json({ items: rows });
}

export async function POST(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  let body;
  try { body = await readJsonBody(req); } catch (error) { return apiError(error); }
  const parsed = typeInputSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" }, { status: 400 });
  }
  const slug = slugify(parsed.data.slug || parsed.data.name) || uniqueSlug(parsed.data.name);
  try {
    const [row] = await db
      .insert(propertyTypes)
      .values({ name: parsed.data.name.trim(), slug })
      .returning();
    revalidatePath("/", "layout");
    return NextResponse.json({ ok: true, item: row });
  } catch {
    return NextResponse.json({ error: "النوع موجود بالفعل" }, { status: 409 });
  }
}
