import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { areas } from "@/db/schema";
import { asc, sql } from "drizzle-orm";
import { areaInputSchema } from "@/lib/validators";
import { requireAdmin } from "@/lib/auth";
import { assertMediaReferences } from "@/lib/media-references";
import { apiError, readJsonBody } from "@/lib/http";
import { revalidatePath } from "next/cache";
export const runtime = "nodejs";
export async function GET() {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  try { return NextResponse.json({ items: await db.select().from(areas).orderBy(asc(areas.sort), asc(areas.createdAt)) }); }
  catch (error) { return apiError(error, "تعذّر تحميل المناطق"); }
}
export async function POST(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  try {
    const parsed = areaInputSchema.safeParse(await readJsonBody(req));
    if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" }, { status: 400 });
    const [row] = await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(7410032)`);
      await assertMediaReferences(parsed.data, tx);
      return tx.insert(areas).values(parsed.data).returning({ id: areas.id });
    });
    revalidatePath("/", "layout"); return NextResponse.json({ ok: true, id: row.id });
  } catch (error) { return apiError(error, "تعذّر حفظ المناطق"); }
}
