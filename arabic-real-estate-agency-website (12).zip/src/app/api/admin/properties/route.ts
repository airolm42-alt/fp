import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { properties, propertyTypes } from "@/db/schema";
import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import { propertyInputSchema } from "@/lib/validators";
import { requireAdmin } from "@/lib/auth";
import { saveProperty } from "@/lib/property-mutations";
import { apiError, readJsonBody } from "@/lib/http";
import { isUuid, likePattern, pageNumber } from "@/lib/input-safety";
import { revalidatePath } from "next/cache";
export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  try {
    const sp = req.nextUrl.searchParams;
    const q = sp.get("q")?.trim().slice(0, 200) ?? "";
    const status = sp.get("status"), listing = sp.get("listing"), type = sp.get("type");
    const page = pageNumber(sp.get("page")), limit = 15;
    const conds = [];
    if (q) conds.push(or(ilike(properties.title, likePattern(q)), ilike(properties.location, likePattern(q))));
    if (status === "draft" || status === "published") conds.push(eq(properties.status, status));
    if (listing === "sale" || listing === "rent") conds.push(eq(properties.listingType, listing));
    if (type) conds.push(isUuid(type) ? eq(properties.typeId, type) : sql`false`);
    const where = conds.length ? and(...conds) : undefined;
    const [items, counts, types] = await Promise.all([
      db.select({ id: properties.id, title: properties.title, slug: properties.slug, listingType: properties.listingType, price: properties.price, currency: properties.currency, location: properties.location, status: properties.status, featured: properties.featured, mainImage: properties.mainImage, createdAt: properties.createdAt, typeId: properties.typeId, typeName: propertyTypes.name })
        .from(properties).leftJoin(propertyTypes, eq(properties.typeId, propertyTypes.id)).where(where).orderBy(desc(properties.createdAt)).limit(limit).offset((page - 1) * limit),
      db.select({ count: sql<number>`count(*)` }).from(properties).where(where),
      db.select().from(propertyTypes).orderBy(propertyTypes.name),
    ]);
    const total = Number(counts[0]?.count ?? 0);
    return NextResponse.json({ items, total, page, pages: Math.max(1, Math.ceil(total / limit)), types });
  } catch (error) { return apiError(error, "تعذّر تحميل العقارات"); }
}
export async function POST(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  try {
    const parsed = propertyInputSchema.safeParse(await readJsonBody(req));
    if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" }, { status: 400 });
    const saved = await saveProperty(parsed.data);
    revalidatePath("/", "layout"); revalidatePath("/sitemap.xml");
    return NextResponse.json({ ok: true, ...saved });
  } catch (error) { return apiError(error, "تعذّر حفظ العقار"); }
}
