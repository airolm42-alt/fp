import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { properties } from "@/db/schema";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { propertyInputSchema } from "@/lib/validators";
import { requireAdmin } from "@/lib/auth";
import { saveProperty } from "@/lib/property-mutations";
import { apiError, readJsonBody } from "@/lib/http";
import { isUuid } from "@/lib/input-safety";
import { revalidatePath } from "next/cache";
export const runtime = "nodejs";
const patchSchema = z.object({ status: z.enum(["draft", "published"]).optional(), featured: z.boolean().optional() }).strict().refine((v) => v.status !== undefined || v.featured !== undefined, "لا توجد تغييرات");

export async function PATCH(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await ctx.params;
  if (!isUuid(id)) return NextResponse.json({ error: "معرّف غير صالح" }, { status: 400 });
  try {
    const parsed = patchSchema.safeParse(await readJsonBody(req));
    if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" }, { status: 400 });
    const updated = await db.update(properties).set({ ...parsed.data, updatedAt: new Date() }).where(eq(properties.id, id)).returning({ id: properties.id });
    if (!updated.length) return NextResponse.json({ error: "العقار غير موجود" }, { status: 404 });
    revalidatePath("/", "layout"); revalidatePath("/sitemap.xml");
    return NextResponse.json({ ok: true });
  } catch (error) { return apiError(error, "تعذّر تحديث العقار"); }
}
export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await ctx.params;
  try {
    const parsed = propertyInputSchema.safeParse(await readJsonBody(req));
    if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" }, { status: 400 });
    const saved = await saveProperty(parsed.data, id);
    revalidatePath("/", "layout"); revalidatePath("/sitemap.xml");
    return NextResponse.json({ ok: true, ...saved });
  } catch (error) { return apiError(error, "تعذّر حفظ العقار"); }
}
export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await ctx.params;
  if (!isUuid(id)) return NextResponse.json({ error: "معرّف غير صالح" }, { status: 400 });
  try {
    const deleted = await db.delete(properties).where(eq(properties.id, id)).returning({ id: properties.id });
    if (!deleted.length) return NextResponse.json({ error: "العقار غير موجود" }, { status: 404 });
    revalidatePath("/", "layout"); revalidatePath("/sitemap.xml");
    return NextResponse.json({ ok: true });
  } catch (error) { return apiError(error, "تعذّر حذف العقار"); }
}
