import { NextRequest, NextResponse } from "next/server";
import { revalidatePath } from "next/cache";
import { z } from "zod";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { settings } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { normalizeSiteOrigin, siteOriginKind } from "@/lib/site-origin";

export const runtime = "nodejs";

const inputSchema = z.object({ siteUrl: z.string().trim().max(2048) }).strict();

/** Owner-only update of the canonical domain; preserves all other SEO fields. */
export async function PATCH(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "سجّل الدخول أولًا" }, { status: 401 });
  if (!admin.isOwner) return NextResponse.json({ error: "حفظ عنوان الإنتاج متاح للمالك فقط" }, { status: 403 });

  // The session is also supported in preview iframes. Enforce same-origin writes.
  const origin = req.headers.get("origin");
  const expectedHost = (req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? "").split(",")[0].trim();
  try {
    if (!origin || new URL(origin).host !== expectedHost) {
      return NextResponse.json({ error: "مصدر الطلب غير مسموح" }, { status: 403 });
    }
  } catch {
    return NextResponse.json({ error: "مصدر الطلب غير مسموح" }, { status: 403 });
  }

  const parsed = inputSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "أدخل رابط موقع صالحًا" }, { status: 400 });
  const raw = parsed.data.siteUrl;
  const normalized = raw ? normalizeSiteOrigin(raw) : "";
  if (raw && (!normalized || siteOriginKind(normalized) !== "public")) {
    return NextResponse.json(
      { error: "أدخل دومين الإنتاج دون مسار إضافي. رابط المعاينة أو localhost ليس رابطًا دائمًا." },
      { status: 400 },
    );
  }

  try {
    await db.insert(settings).values({ key: "seo", value: { siteUrl: normalized }, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: settings.key,
        set: {
          value: sql`jsonb_set(${settings.value}, '{siteUrl}', ${JSON.stringify(normalized)}::jsonb, true)`,
          updatedAt: new Date(),
        },
      });
    revalidatePath("/", "layout");
    revalidatePath("/sitemap.xml");
    revalidatePath("/robots.txt");
    return NextResponse.json({ ok: true, siteUrl: normalized });
  } catch (error) {
    console.error("Publishing domain update failed", error);
    return NextResponse.json({ error: "تعذّر حفظ الرابط. حاول مرة أخرى." }, { status: 500 });
  }
}
