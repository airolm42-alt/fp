import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { createSourceBundle } from "@/lib/source-export";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const lastExport = new Map<string, number>();
const COOLDOWN_MS = 10_000;

/** Full source export is private and restricted to the owner, never public. */
export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "سجّل الدخول أولًا" }, { status: 401 });
  if (!admin.isOwner) return NextResponse.json({ error: "تنزيل مصدر المشروع متاح للمالك فقط" }, { status: 403 });

  const now = Date.now();
  const previous = lastExport.get(admin.id) ?? 0;
  if (now - previous < COOLDOWN_MS) {
    return NextResponse.json({ error: "انتظر قليلًا قبل إعادة تنزيل الحزمة" }, { status: 429, headers: { "Retry-After": "10" } });
  }
  if (lastExport.size > 1000) {
    for (const [key, at] of lastExport) if (now - at > COOLDOWN_MS) lastExport.delete(key);
  }
  lastExport.set(admin.id, now);

  try {
    const bundle = await createSourceBundle();
    const payload = new ArrayBuffer(bundle.zip.length);
    new Uint8Array(payload).set(bundle.zip);
    return new NextResponse(payload, { headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": 'attachment; filename="arabic-real-estate-source.zip"',
      "Content-Length": String(bundle.zip.length),
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
      "X-Source-File-Count": String(bundle.manifest.fileCount),
    } });
  } catch (error) {
    console.error("Complete source export unavailable", error instanceof Error ? error.message : "unknown error");
    return NextResponse.json({ error: "لا يمكن إنشاء حزمة كاملة من هذه النسخة؛ قد لا تحتوي الاستضافة ملفات المصدر. نزّل من بيئة المشروع الأصلية أو استخدم سكربت export-project بعد فحص الملفات." }, { status: 409, headers: { "Cache-Control": "private, no-store" } });
  }
}
