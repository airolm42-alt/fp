import { NextResponse } from "next/server";
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { requireAdmin } from "@/lib/auth";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  try {
    const content = await readFile(join(process.cwd(), "DEPLOYMENT-AR.md"), "utf8");
    return new NextResponse(content, { headers: {
      "Content-Type": "text/markdown; charset=utf-8",
      "Content-Disposition": 'attachment; filename="deployment-ar.md"',
      "Cache-Control": "private, no-store",
    } });
  } catch {
    return NextResponse.json({ error: "دليل النشر غير متاح حاليًا" }, { status: 404 });
  }
}
