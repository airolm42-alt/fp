import { NextRequest, NextResponse } from "next/server";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { zipSync, type Zippable } from "fflate";
import { z } from "zod";
import { requireAdmin } from "@/lib/auth";
import { apiError, readJsonBody } from "@/lib/http";
import { consumeLimit } from "@/lib/rate-limit";
import { buildPages } from "@/lib/pages-build";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const input = z.object({ apiUrl: z.string().trim().min(1).max(2048), siteUrl: z.string().trim().max(2048).default("") }).strict();

export async function POST(req: NextRequest) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  if (!admin.isOwner) return NextResponse.json({ error: "تصدير الواجهة متاح للمالك فقط" }, { status: 403 });
  let temporary = "";
  try {
    const parsed = input.safeParse(await readJsonBody(req, 8 * 1024));
    if (!parsed.success) return NextResponse.json({ error: "أدخل عنوان خادم صالحًا" }, { status: 400 });
    const limit = await consumeLimit("pages-build", admin.id, 12, 3600);
    if (!limit.allowed) return NextResponse.json({ error: "انتظر قليلًا قبل إعادة بناء الحزمة" }, { status: 429, headers: { "Retry-After": String(limit.retryAfter) } });
    temporary = await mkdtemp(path.join(os.tmpdir(), "arabic-pages-"));
    let result;
    try { result = await buildPages({ ...parsed.data, outputDirectory: path.join(temporary, "site") }); }
    catch (error) {
      console.error("Pages build failed", error instanceof Error ? error.message : "unknown error");
      return NextResponse.json({ error: "تعذّر البناء. استخدم نطاق HTTPS للخادم دون مسارات أو بيانات دخول، وتأكد أن ملفات github-pages ومكتبة esbuild موجودة في الاستضافة. لا تستخدم localhost في حزمة الإنتاج." }, { status: 400 });
    }
    const files: Zippable = Object.create(null);
    for (const file of result.files) files[file.path] = await readFile(path.join(result.directory, file.path));
    const zipped = zipSync(files, { level: 6 });
    const output = new ArrayBuffer(zipped.length); new Uint8Array(output).set(zipped);
    return new NextResponse(output, { headers: { "Content-Type": "application/zip", "Content-Disposition": 'attachment; filename="real-estate-pages-static.zip"', "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" } });
  } catch (error) { return apiError(error, "تعذّر تجهيز واجهة Pages"); }
  finally { if (temporary) await rm(temporary, { recursive: true, force: true }); }
}
