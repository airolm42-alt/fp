import { NextRequest, NextResponse } from "next/server";
import { randomUUID } from "node:crypto";
import path from "node:path";
import { mkdir, writeFile, unlink } from "node:fs/promises";
import sharp from "sharp";
import { db } from "@/db";
import { mediaFiles } from "@/db/schema";
import { requireAdmin } from "@/lib/auth";
import { getUploadsDirectory } from "@/lib/uploads-dir";
import { apiError, readBodyLimited, RequestError } from "@/lib/http";
export const runtime = "nodejs";
const MAX_FILE = 8 * 1024 * 1024;
const MAX_REQUEST = 25 * 1024 * 1024;
const MIME = new Set(["image/jpeg", "image/png", "image/webp", "image/avif"]);
const FORMATS = new Set(["jpeg", "png", "webp", "heif", "avif"]);

export async function POST(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const written: string[] = [];
  try {
    const contentType = req.headers.get("content-type") ?? "";
    if (!contentType.startsWith("multipart/form-data")) throw new RequestError("استخدم نموذج رفع الصور", 415);
    const body = await readBodyLimited(req, MAX_REQUEST);
    const payload = new ArrayBuffer(body.length); new Uint8Array(payload).set(body);
    let form;
    try { form = await new Request(req.url, { method: "POST", headers: { "Content-Type": contentType }, body: payload }).formData(); }
    catch { throw new RequestError("نموذج رفع الصور غير صالح"); }
    const files = [...form.getAll("files"), ...form.getAll("file")].filter((file): file is File => file instanceof File);
    if (!files.length || files.length > 10) throw new RequestError("اختر من صورة واحدة إلى 10 صور، بإجمالي 25MB كحد أقصى");
    const prepared: { url: string; name: string; size: number; mime: string; bytes: Buffer; filename: string }[] = [];
    for (const file of files) {
      if (!MIME.has(file.type) || !file.size || file.size > MAX_FILE) throw new RequestError("كل صورة يجب أن تكون JPG أو PNG أو WebP أو AVIF وحجمها حتى 8MB");
      try {
        const buffer = Buffer.from(await file.arrayBuffer());
        const pipeline = sharp(buffer, { limitInputPixels: 40_000_000, animated: false }).timeout({ seconds: 15 });
        const metadata = await pipeline.metadata();
        if (!metadata.format || !FORMATS.has(metadata.format)) throw new Error("Invalid image format");
        const optimized = await pipeline.rotate().resize({ width: 1920, height: 1920, fit: "inside", withoutEnlargement: true }).webp({ quality: 82 }).toBuffer();
        const filename = `${randomUUID()}.webp`;
        prepared.push({ filename, url: `/uploads/${filename}`, name: file.name.replace(/[^\w.\-\u0600-\u06FF ]/g, "").slice(0, 120) || filename, size: optimized.length, mime: "image/webp", bytes: optimized });
      } catch { throw new RequestError("إحدى الصور تالفة أو أبعادها كبيرة جدًا؛ لم يتم حفظ أي صورة من هذه الدفعة"); }
    }
    const directory = getUploadsDirectory();
    await mkdir(directory, { recursive: true });
    for (const image of prepared) {
      const filename = path.join(directory, image.filename);
      await writeFile(filename, image.bytes, { flag: "wx" }); written.push(filename);
    }
    await db.insert(mediaFiles).values(prepared.map(({ url, name, size, mime }) => ({ url, name, size, mime })));
    return NextResponse.json({ files: prepared.map(({ url, name, size, mime }) => ({ url, name, size, mime })) });
  } catch (error) {
    await Promise.all(written.map((filename) => unlink(filename).catch(() => {})));
    return apiError(error, "تعذّر رفع الصور");
  }
}
