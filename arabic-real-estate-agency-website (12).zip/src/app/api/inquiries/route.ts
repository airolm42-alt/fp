import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { inquiries, properties } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { inquiryInputSchema } from "@/lib/validators";
import { apiError, readJsonBody } from "@/lib/http";
import { clientIp, consumeLimit } from "@/lib/rate-limit";
import { revalidatePath } from "next/cache";

export async function POST(req: NextRequest) {
  try {
    const parsed = inquiryInputSchema.safeParse(await readJsonBody(req, 16 * 1024));
    if (!parsed.success) return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" }, { status: 400 });
    if (parsed.data.website) return NextResponse.json({ ok: true });
    const limit = await consumeLimit("inquiry", clientIp(req.headers), 8, 3600);
    if (!limit.allowed) return NextResponse.json({ error: "رسائل كثيرة؛ يرجى الانتظار قبل المحاولة مجددًا" }, { status: 429, headers: { "Retry-After": String(limit.retryAfter) } });
    let propertyId: string | null = null;
    let propertyTitle = "";
    if (parsed.data.propertyId) {
      const [property] = await db.select({ id: properties.id, title: properties.title }).from(properties).where(and(eq(properties.id, parsed.data.propertyId), eq(properties.status, "published"))).limit(1);
      if (!property) return NextResponse.json({ error: "العقار لم يعد متاحًا. يمكنك إرسال استفسار عام من صفحة التواصل." }, { status: 400 });
      propertyId = property.id; propertyTitle = property.title;
    }
    await db.insert(inquiries).values({ name: parsed.data.name, phone: parsed.data.phone, email: parsed.data.email ?? "", message: parsed.data.message, propertyId, propertyTitle });
    revalidatePath("/admin/dashboard");
    return NextResponse.json({ ok: true });
  } catch (error) { return apiError(error, "تعذّر إرسال الاستفسار"); }
}
