import { NextRequest, NextResponse } from "next/server";
import { createReadStream } from "node:fs";
import { stat } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import { getUploadsDirectory } from "@/lib/uploads-dir";

const MIME: Record<string, string> = { webp: "image/webp", jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", avif: "image/avif" };
export const runtime = "nodejs";

export async function GET(_req: NextRequest, ctx: { params: Promise<{ path: string[] }> }) {
  const { path: segments } = await ctx.params;
  if (segments.length !== 1) return new NextResponse(null, { status: 404 });
  const filename = segments[0];
  if (!/^[\w-][\w.-]*\.(webp|jpe?g|png|avif)$/i.test(filename) || filename.includes("..")) {
    return new NextResponse(null, { status: 404 });
  }
  const extension = filename.split(".").pop()?.toLowerCase() ?? "";
  const filePath = path.join(getUploadsDirectory(), filename);
  try {
    const info = await stat(filePath);
    if (!info.isFile()) return new NextResponse(null, { status: 404 });
    const stream = Readable.toWeb(createReadStream(filePath)) as ReadableStream;
    return new NextResponse(stream, { headers: {
      "Content-Type": MIME[extension],
      "Content-Length": String(info.size),
      "Cache-Control": "public, max-age=31536000, immutable",
      "X-Content-Type-Options": "nosniff",
    } });
  } catch {
    return new NextResponse(null, { status: 404 });
  }
}
