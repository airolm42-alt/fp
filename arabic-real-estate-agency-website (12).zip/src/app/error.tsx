"use client";
import { CircleAlert, RotateCcw } from "lucide-react";

export default function ApplicationError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <section className="mx-auto flex min-h-[60vh] max-w-2xl flex-col items-center justify-center px-6 py-16 text-center" role="alert">
    <span className="mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-gold-100 text-gold-700"><CircleAlert className="h-8 w-8" /></span>
    <h1 className="text-2xl font-black text-brand-950">تعذّر تحميل هذه الصفحة مؤقتًا</h1>
    <p className="mt-3 text-sm leading-loose text-ink-soft">قد يكون هناك انقطاع مؤقت في الاتصال بالخادم. حاول مرة أخرى؛ لا تحتاج إعادة إرسال بياناتك أو تغيير كلمة مرورك بسبب هذا الخطأ.</p>
    <button type="button" onClick={reset} className="mt-6 inline-flex cursor-pointer items-center gap-2 rounded-xl bg-brand-700 px-6 py-3 text-sm font-bold text-white hover:bg-brand-800"><RotateCcw className="h-4 w-4" /> إعادة المحاولة</button>
  </section>;
}
