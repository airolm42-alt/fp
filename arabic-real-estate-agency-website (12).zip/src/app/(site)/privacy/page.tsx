import type { Metadata } from "next";
import { getBusinessSettings } from "@/lib/settings";
import { ShieldCheck } from "lucide-react";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "سياسة الخصوصية",
  description: "كيفية تعاملنا مع بياناتك الشخصية عند استخدام موقعنا",
  alternates: { canonical: "/privacy" },
};

export default async function PrivacyPage() {
  const b = await getBusinessSettings();
  const name = b.businessName || "هذا الموقع";

  const sections = [
    {
      title: "أولًا: البيانات التي نجمعها",
      items: [
        "البيانات التي تقدمها بنفسك عند ملء نماذج التواصل (الاسم، رقم الهاتف، البريد الإلكتروني، ومحتوى رسالتك).",
        "بيانات الاستخدام الفنية الأساسية التي يجمعها خادم الموقع تلقائيًا لأغراض التشغيل والأمان فقط.",
      ],
    },
    {
      title: "ثانيًا: كيفية استخدام البيانات",
      items: [
        "الرد على استفساراتك وطلباتك المتعلقة بالعقارات المعروضة.",
        "التواصل معك بخصوص العقارات التي أبديت اهتمامًا بها.",
        "تحسين محتوى الموقع وخدماته.",
        "لا نستخدم بياناتك لأي غرض تسويقي خارج نطاق خدماتنا، ولا نرسل رسائل غير مرغوبة.",
      ],
    },
    {
      title: "ثالثًا: مشاركة البيانات",
      items: [
        "لا نبيع بياناتك الشخصية ولا نشاركها مع أطراف خارجية لأغراض إعلانية.",
        "قد تتم مشاركة بياناتك فقط في الحدود اللازمة لإتمام الخدمة المطلوبة أو عند وجود التزام قانوني بذلك.",
      ],
    },
    {
      title: "رابعًا: حماية البيانات",
      items: [
        "نطبق إجراءات تقنية وتنظيمية مناسبة لحماية بياناتك من الوصول غير المصرح به أو الفقدان أو التعديل.",
        "الوصول إلى بيانات العملاء مقصور على الأشخاص المخولين بإدارة الموقع فقط.",
      ],
    },
    {
      title: "خامسًا: حقوقك",
      items: [
        "يحق لك طلب الاطلاع على البيانات المسجلة لديك أو طلب تعديلها أو حذفها في أي وقت.",
        "لممارسة هذه الحقوق يمكنك التواصل معنا عبر وسائل الاتصال الموضحة في صفحة «تواصل معنا».",
      ],
    },
    {
      title: "سادسًا: التعديلات على هذه السياسة",
      items: [
        "قد نقوم بتحديث هذه السياسة من وقت لآخر، وسيتم نشر النسخة الأحدث دائمًا على هذه الصفحة.",
        "استمرارك في استخدام الموقع بعد نشر أي تعديل يعني موافقتك على السياسة المحدثة.",
      ],
    },
  ];

  return (
    <div>
      <section className="bg-brand-950 py-14 pattern-arabesque sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <span className="mb-2 block h-1 w-12 rounded-full bg-gold-400" />
          <h1 className="flex items-center gap-3 text-3xl font-black text-white sm:text-4xl">
            <ShieldCheck className="h-8 w-8 text-gold-400" />
            سياسة الخصوصية
          </h1>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-brand-100/70">
            خصوصيتك أمانة. توضح هذه الصفحة كيف يتعامل {name} مع بياناتك عند استخدامك للموقع.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-4xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="space-y-5">
          {sections.map((s) => (
            <section key={s.title} className="rounded-2xl border border-stone-200/70 bg-white p-6 shadow-card sm:p-7">
              <h2 className="text-lg font-black text-brand-950">{s.title}</h2>
              <ul className="mt-3 space-y-2.5">
                {s.items.map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-sm leading-relaxed text-ink-soft">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-gold-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
        <p className="mt-8 rounded-2xl bg-brand-50 p-5 text-sm font-semibold leading-relaxed text-brand-800 ring-1 ring-brand-600/10">
          لأي استفسار بخصوص الخصوصية، يمكنك التواصل معنا من صفحة «تواصل معنا» وسنرد عليك في أقرب وقت.
        </p>
      </div>
    </div>
  );
}
