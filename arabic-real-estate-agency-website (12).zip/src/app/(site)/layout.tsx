import type { ReactNode } from "react";
import type { Metadata } from "next";
import { getAllSettings } from "@/lib/settings";
import { getSiteUrl } from "@/lib/site-url";
import { SiteHeader } from "@/components/site/header";
import { SiteFooter } from "@/components/site/footer";
import { WhatsAppFloat } from "@/components/site/whatsapp-float";
import { safeJsonLd } from "@/lib/input-safety";

export const revalidate = 60;

export async function generateMetadata(): Promise<Metadata> {
  const { business, seo } = await getAllSettings();
  const baseUrl = await getSiteUrl();
  const name = seo.siteTitle || business.businessName || "موقع عقاري";
  const description = seo.siteDescription || undefined;
  return {
    title: {
      default: name,
      template: `%s | ${name}`,
    },
    description,
    keywords: seo.keywords || undefined,
    alternates: { canonical: "/" },
    robots: { index: true, follow: true },
    verification: seo.googleVerification ? { google: seo.googleVerification } : undefined,
    openGraph: {
      siteName: name,
      title: name,
      description,
      url: baseUrl,
      images: seo.ogImage ? [{ url: seo.ogImage }] : undefined,
      locale: "ar_EG",
      type: "website",
    },
    twitter: {
      card: "summary_large_image",
      title: name,
      description,
      images: seo.ogImage ? [seo.ogImage] : undefined,
    },
  };
}

export default async function SiteLayout({ children }: { children: ReactNode }) {
  const { business, site, seo } = await getAllSettings();
  const baseUrl = await getSiteUrl();

  // Structured data helps Google show the business correctly in search results.
  const sameAs = [business.facebook, business.instagram, business.tiktok, business.youtube].filter(Boolean);
  const orgJsonLd: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": "RealEstateAgent",
    name: seo.siteTitle || business.businessName || "موقع عقاري",
    url: baseUrl,
    ...(seo.siteDescription ? { description: seo.siteDescription } : {}),
    ...(business.logo ? { logo: `${baseUrl}${business.logo}` } : {}),
    ...(business.phone ? { telephone: business.phone } : {}),
    ...(business.email ? { email: business.email } : {}),
    ...(business.address
      ? { address: { "@type": "PostalAddress", streetAddress: business.address, addressCountry: "EG" } }
      : {}),
    ...(business.workingHours ? { openingHours: business.workingHours } : {}),
    ...(business.googleMapsUrl ? { hasMap: business.googleMapsUrl } : {}),
    ...(sameAs.length ? { sameAs } : {}),
  };

  const searchJsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    url: baseUrl,
    name: seo.siteTitle || business.businessName || "موقع عقاري",
    potentialAction: {
      "@type": "SearchAction",
      target: `${baseUrl}/properties?q={search_term_string}`,
      "query-input": "required name=search_term_string",
    },
  };

  return (
    <>
      {business.businessName && <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: safeJsonLd(orgJsonLd) }} />}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: safeJsonLd(searchJsonLd) }} />
      {/^G-[A-Z0-9]{4,32}$/.test(seo.googleAnalyticsId) && (
        <>
          <script async src={`https://www.googletagmanager.com/gtag/js?id=${seo.googleAnalyticsId}`} />
          <script
            dangerouslySetInnerHTML={{
              __html: `window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag('js',new Date());gtag('config','${seo.googleAnalyticsId}');`,
            }}
          />
        </>
      )}
      <SiteHeader business={business} />
      <main id="main-content" className="min-h-[60vh]">{children}</main>
      <SiteFooter business={business} site={site} />
      {business.whatsapp && <WhatsAppFloat whatsapp={business.whatsapp} />}
    </>
  );
}
