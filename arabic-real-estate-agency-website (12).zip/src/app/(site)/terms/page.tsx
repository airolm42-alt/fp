import type { Metadata } from "next";
import { getBusinessSettings } from "@/lib/settings";
import { ScrollText } from "lucide-react";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "الشروط والأحكام",
  description: "الشروط والأحكام المنظمة لاستخدام الموقع",
  alternates: { canonical: "/terms" },
};

export default async function TermsPage() {
  const b = await getBusinessSettings();
  const name = b.businessName || "هذا الموقع";

  const sections = [
    {
      title: "أولًا: التعريف والنطاق",
      items: [
        `تحكم هذه الشروط استخدامك لموقع ${name}، وباستخدامك للموقع فأنت توافق على الالتزام بها.`,
        "المحتوى المعروض يهدف إلى تقديم معلومات عن العقارات والخدمات العقارية المتاحة لدينا.",
      ],
    },
    {
      title: "ثانيًا: معلومات العقارات",
      items: [
        "نحرص على دقة تفاصيل العقارات المعروضة (الأسعار، المساحات، المواصفات) وقد تتغير هذه التفاصيل دون إشعار مسبق بناءً على تحديثات المُلاك أو السوق.",
        "الصور المعروضة للعقارات تُستخدم لأغراض التوضيح وقد لا تعكس الحالة الراهنة بالكامل؛ لذا ننصح دائمًا بتحديد موعد للمعاينة قبل اتخاذ أي قرار.",
        "عرض أي عقار على الموقع لا يُعد التزامًا نهائيًا بتوفره حتى يتم تأكيد ذلك مباشرة مع فريقنا.",
      ],
    },
    {
      title: "ثالثًا: استخدام الموقع",
      items: [
        "يُستخدم الموقع لأغراض مشروعة فقط، ويُمنع استخدامه في أي نشاط مخالف للقانون أو معطل لعمل الموقع.",
        "يُمنع إرسال بيانات غير صحيحة عمدًا عبر نماذج التواصل أو انتحال هوية الآخرين.",
      ],
    },
    {
      title: "رابعًا: الملكية الفكرية",
      items: [
        `جميع محتويات الموقع من نصوص وتصميم وشعارات وصور مملوكة لـ${name} ما لم يُذكر خلاف ذلك.`,
        "لا يجوز إعادة نشر أو نسخ محتوى الموقع لأغراض تجارية دون إذن كتابي مسبق.",
      ],
    },
    {
      title: "خامسًا: حدود المسؤولية",
      items: [
        "نبذل جهدًا معقولًا لإبقاء الموقع متاحًا ومحدثًا، ولا نضمن خلوه من الأخطاء أو الانقطاعات.",
        "أي قرار شراء أو استئجار يتم بناءً على تعاقد مباشر موثق مع الأطراف المعنية؛ ودور الموقع تعريفي وإرشادي.",
      ],
    },
    {
      title: "سادسًا: تعديل الشروط",
      items: [
        "يجوز لنا تعديل هذه الشروط في أي وقت، وتسري التعديلات فور نشرها على هذه الصفحة.",
      ],
    },
  ];

  return (
    <div>
      <section className="bg-brand-950 py-14 pattern-arabesque sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <span className="mb-2 block h-1 w-12 rounded-full bg-gold-400" />
          <h1 className="flex items-center gap-3 text-3xl font-black text-white sm:text-4xl">
            <ScrollText className="h-8 w-8 text-gold-400" />
            الشروط والأحكام
          </h1>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-brand-100/70">
            يرجى قراءة هذه الشروط بعناية قبل استخدام موقع {name}.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-4xl px-4 py-14 sm:px-6 lg:px-8">
        <div className="space-y-5">
          {sections.map((s) => (
            <section key={s.title} className="rounded-2xl border border-stone-200/70 bg-white p-6 shadow-card sm:p-7">
              <h2 className="text-lg font-black text-brand-950">{s.title}</h2>
              <ul className="mt-3 space-y-2.5">
                {s.items.map((item) => (
                  <li key={item} className="flex items-start gap-2.5 text-sm leading-relaxed text-ink-soft">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-gold-500" />
                    {item}
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
        <p className="mt-8 rounded-2xl bg-sand-dark p-5 text-xs leading-relaxed text-stone-500">
          آخر تحديث: {new Date().toLocaleDateString("ar-EG-u-nu-latn", { year: "numeric", month: "long" })} — باستخدامك لهذا الموقع فأنت تقر باطلاعك على هذه الشروط وموافقتك عليها.
        </p>
      </div>
    </div>
  );
}
