import type { Metadata } from "next";
import { Phone, Mail, MapPin, Clock, Map, MessageCircle, Settings2 } from "lucide-react";
import { getBusinessSettings } from "@/lib/settings";
import { ContactForm } from "@/components/site/contact-form";
import { FacebookIcon, InstagramIcon, TikTokIcon, YoutubeIcon } from "@/components/site/social-icons";
import { whatsappLink, isMapsEmbed } from "@/lib/utils";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "تواصل معنا",
  description: "تواصل مع فريقنا لأي استفسار عقاري — هاتف، واتساب، بريد إلكتروني أو نموذج التواصل",
  alternates: { canonical: "/contact" },
};

export default async function ContactPage() {
  const b = await getBusinessSettings();
  const hasAny = b.phone || b.whatsapp || b.email || b.address || b.workingHours;
  const hasSocial = b.facebook || b.instagram || b.tiktok || b.youtube;

  return (
    <div>
      <section className="bg-brand-950 py-14 pattern-arabesque sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <span className="mb-2 block h-1 w-12 rounded-full bg-gold-400" />
          <h1 className="text-3xl font-black text-white sm:text-4xl">تواصل معنا</h1>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-brand-100/70">
            فريقنا جاهز للرد على استفساراتك ومساعدتك في خطوتك العقارية القادمة.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-16 lg:px-8">
        <div className="grid gap-8 lg:grid-cols-5">
          {/* Info cards */}
          <div className="space-y-4 lg:col-span-2">
            {hasAny ? (
              <>
                {b.phone && (
                  <a href={`tel:${b.phone}`} className="flex items-center gap-4 rounded-2xl border border-stone-200/70 bg-white p-5 shadow-card transition hover:-translate-y-0.5 hover:shadow-card-hover">
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-brand-700 text-gold-300">
                      <Phone className="h-5.5 w-5.5" />
                    </span>
                    <span>
                      <span className="block text-xs font-bold text-stone-400">اتصل بنا</span>
                      <span className="mt-0.5 block text-base font-black text-brand-950" dir="ltr">{b.phone}</span>
                    </span>
                  </a>
                )}
                {b.whatsapp && (
                  <a href={whatsappLink(b.whatsapp, "مرحبًا، أريد الاستفسار عن العقارات المتاحة")} target="_blank" rel="noopener noreferrer" className="flex items-center gap-4 rounded-2xl border border-stone-200/70 bg-white p-5 shadow-card transition hover:-translate-y-0.5 hover:shadow-card-hover">
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[#25d366] text-white">
                      <MessageCircle className="h-5.5 w-5.5" />
                    </span>
                    <span>
                      <span className="block text-xs font-bold text-stone-400">واتساب</span>
                      <span className="mt-0.5 block text-base font-black text-brand-950" dir="ltr">{b.whatsapp}</span>
                    </span>
                  </a>
                )}
                {b.email && (
                  <a href={`mailto:${b.email}`} className="flex items-center gap-4 rounded-2xl border border-stone-200/70 bg-white p-5 shadow-card transition hover:-translate-y-0.5 hover:shadow-card-hover">
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-gold-100 text-gold-700">
                      <Mail className="h-5.5 w-5.5" />
                    </span>
                    <span>
                      <span className="block text-xs font-bold text-stone-400">البريد الإلكتروني</span>
                      <span className="mt-0.5 block break-all text-base font-black text-brand-950" dir="ltr">{b.email}</span>
                    </span>
                  </a>
                )}
                {b.address && (
                  <div className="flex items-center gap-4 rounded-2xl border border-stone-200/70 bg-white p-5 shadow-card">
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                      <MapPin className="h-5.5 w-5.5" />
                    </span>
                    <span>
                      <span className="block text-xs font-bold text-stone-400">العنوان</span>
                      <span className="mt-0.5 block text-sm font-black leading-relaxed text-brand-950">{b.address}</span>
                    </span>
                  </div>
                )}
                {b.workingHours && (
                  <div className="flex items-center gap-4 rounded-2xl border border-stone-200/70 bg-white p-5 shadow-card">
                    <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-700">
                      <Clock className="h-5.5 w-5.5" />
                    </span>
                    <span>
                      <span className="block text-xs font-bold text-stone-400">مواعيد العمل</span>
                      <span className="mt-0.5 block text-sm font-black leading-relaxed text-brand-950">{b.workingHours}</span>
                    </span>
                  </div>
                )}
                {b.googleMapsUrl && (
                  <a href={b.googleMapsUrl} target="_blank" rel="noopener noreferrer" className="flex items-center justify-center gap-2 rounded-2xl border border-brand-200 bg-brand-50 p-4 text-sm font-black text-brand-700 transition hover:bg-brand-100">
                    <Map className="h-5 w-5" />
                    افتح موقعنا على خرائط Google
                  </a>
                )}
                {hasSocial && (
                  <div className="rounded-2xl border border-stone-200/70 bg-white p-5 shadow-card">
                    <p className="mb-3 text-xs font-bold text-stone-400">تابعنا على</p>
                    <div className="flex gap-2.5">
                      {b.facebook && <a href={b.facebook} target="_blank" rel="noopener noreferrer" aria-label="فيسبوك" className="flex h-11 w-11 items-center justify-center rounded-xl bg-stone-100 text-ink transition hover:bg-brand-700 hover:text-white"><FacebookIcon className="h-5 w-5" /></a>}
                      {b.instagram && <a href={b.instagram} target="_blank" rel="noopener noreferrer" aria-label="إنستجرام" className="flex h-11 w-11 items-center justify-center rounded-xl bg-stone-100 text-ink transition hover:bg-brand-700 hover:text-white"><InstagramIcon className="h-5 w-5" /></a>}
                      {b.tiktok && <a href={b.tiktok} target="_blank" rel="noopener noreferrer" aria-label="تيك توك" className="flex h-11 w-11 items-center justify-center rounded-xl bg-stone-100 text-ink transition hover:bg-brand-700 hover:text-white"><TikTokIcon className="h-5 w-5" /></a>}
                      {b.youtube && <a href={b.youtube} target="_blank" rel="noopener noreferrer" aria-label="يوتيوب" className="flex h-11 w-11 items-center justify-center rounded-xl bg-stone-100 text-ink transition hover:bg-brand-700 hover:text-white"><YoutubeIcon className="h-5 w-5" /></a>}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="flex items-start gap-3 rounded-2xl border-2 border-dashed border-stone-200 bg-white p-6">
                <Settings2 className="mt-0.5 h-6 w-6 shrink-0 text-stone-300" />
                <div>
                  <p className="text-sm font-black text-brand-950">بيانات التواصل قيد الإعداد</p>
                  <p className="mt-1 text-xs leading-relaxed text-stone-400">
                    يمكنك إرسال رسالتك الآن من نموذج التواصل وسيتم الرد عليك فور إضافة بيانات الاتصال.
                  </p>
                </div>
              </div>
            )}

            {/* Map embed */}
            {b.googleMapsUrl && isMapsEmbed(b.googleMapsUrl) && (
              <iframe
                src={b.googleMapsUrl}
                title="موقعنا على الخريطة"
                className="h-64 w-full rounded-2xl border border-stone-200/70 shadow-card"
                loading="lazy"
                allowFullScreen
                referrerPolicy="no-referrer-when-downgrade"
              />
            )}
          </div>

          {/* Form */}
          <div className="lg:col-span-3">
            <div className="rounded-3xl border border-stone-200/70 bg-white p-6 shadow-card sm:p-8">
              <h2 className="text-xl font-black text-brand-950">أرسل لنا رسالة</h2>
              <p className="mt-1.5 mb-6 text-sm text-stone-400">املأ النموذج وسيتواصل معك فريقنا في أقرب وقت</p>
              <ContactForm />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
