import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import { Briefcase, ArrowLeft, Building2, Home, KeyRound, TrendingUp, FileSignature, Compass, Wallet, ShieldCheck, Map } from "lucide-react";
import { getPublishedServices } from "@/lib/public-data";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "خدماتنا",
  description: "تعرف على الخدمات العقارية التي نقدمها",
  alternates: { canonical: "/services" },
};

const ICONS: Record<string, typeof Briefcase> = {
  building: Building2,
  home: Home,
  key: KeyRound,
  chart: TrendingUp,
  document: FileSignature,
  compass: Compass,
  wallet: Wallet,
  shield: ShieldCheck,
  map: Map,
};

export default async function ServicesPage() {
  const list = await getPublishedServices();

  return (
    <div>
      <section className="bg-brand-950 py-14 pattern-arabesque sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <span className="mb-2 block h-1 w-12 rounded-full bg-gold-400" />
          <h1 className="text-3xl font-black text-white sm:text-4xl">خدماتنا</h1>
          <p className="mt-4 max-w-2xl text-base leading-relaxed text-brand-100/70">
            نقدم مجموعة من الخدمات العقارية المصممة لتسهيل رحلتك — من أول استفسار وحتى ما بعد التعاقد.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-16 lg:px-8">
        {list.length === 0 ? (
          <div className="flex flex-col items-center rounded-3xl border-2 border-dashed border-stone-200 bg-white px-6 py-16 text-center">
            <span className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-50 text-brand-300">
              <Briefcase className="h-8 w-8" />
            </span>
            <p className="text-lg font-black text-brand-950">تفاصيل خدماتنا ستُعلن قريبًا</p>
            <p className="mt-2 max-w-md text-sm leading-relaxed text-ink-soft">
              نعمل على تحديث هذه الصفحة. في هذه الأثناء يمكنك التواصل معنا لمعرفة كيف يمكننا خدمتك.
            </p>
            <Link href="/contact" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-brand-700 px-6 py-3 text-sm font-black text-white transition hover:bg-brand-800">
              تواصل معنا
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((s) => {
              const Icon = ICONS[s.icon] ?? Briefcase;
              return (
                <article key={s.id} className="group flex flex-col overflow-hidden rounded-2xl border border-stone-200/70 bg-white shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover">
                  {s.image && (
                    <div className="relative aspect-[16/9] overflow-hidden bg-sand-dark">
                      <Image src={s.image} alt={s.title} fill className="object-cover transition-transform duration-500 group-hover:scale-105" sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw" />
                    </div>
                  )}
                  <div className="flex flex-1 flex-col p-6">
                    {!s.image && (
                      <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-700 text-gold-300">
                        <Icon className="h-6 w-6" />
                      </span>
                    )}
                    <h2 className="text-lg font-black text-brand-950">{s.title}</h2>
                    {s.description && (
                      <p className="mt-2.5 whitespace-pre-line text-sm leading-relaxed text-ink-soft">{s.description}</p>
                    )}
                    <Link href="/contact" className="mt-4 inline-flex items-center gap-1.5 text-sm font-black text-brand-700 transition hover:gap-2.5">
                      اطلب الخدمة
                      <ArrowLeft className="h-4 w-4" />
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
