import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import {
  BedDouble,
  Bath,
  Ruler,
  MapPin,
  Building2,
  Phone,
  CheckCircle2,
  Layers,
  Sparkles,
  ChevronLeft,
  Map,
  Share2,
} from "lucide-react";
import { getPropertyBySlug, getSimilarProperties } from "@/lib/public-data";
import { getBusinessSettings } from "@/lib/settings";
import { PropertyGallery } from "@/components/site/gallery";
import { ContactForm } from "@/components/site/contact-form";
import { PropertyCard, WhatsAppGlyph } from "@/components/site/property-card";
import { SectionHeading } from "@/components/site/section-heading";
import { formatPrice, formatNumber, whatsappLink, isMapsEmbed, cn } from "@/lib/utils";
import { safeJsonLd } from "@/lib/input-safety";
import { getSiteUrl } from "@/lib/site-url";
import { ShareProperty } from "@/components/site/share-property";

export const revalidate = 60;

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const { slug } = await params;
  const p = await getPropertyBySlug(slug);
  if (!p) return { title: "عقار غير موجود" };
  const title = p.metaTitle || p.title;
  const description =
    p.metaDescription ||
    p.description?.slice(0, 160) ||
    `${p.title} — ${p.typeName ?? "عقار"} ${p.listingType === "sale" ? "للبيع" : "للإيجار"}${p.location ? ` في ${p.location}` : ""}`;
  return {
    title,
    description,
    alternates: { canonical: `/properties/${p.slug}` },
    openGraph: {
      title,
      description,
      url: `/properties/${p.slug}`,
      images: p.mainImage ? [{ url: p.mainImage, alt: p.title }] : undefined,
      type: "article",
    },
  };
}

export default async function PropertyDetailsPage({ params }: { params: Params }) {
  const { slug } = await params;
  const [property, business] = await Promise.all([getPropertyBySlug(slug), getBusinessSettings()]);
  if (!property) notFound();

  const [similar, baseUrl] = await Promise.all([getSimilarProperties(property), getSiteUrl()]);

  // Compose gallery: main image first, then gallery (dedup)
  const galleryImages: { url: string; alt: string }[] = [];
  if (property.mainImage) galleryImages.push({ url: property.mainImage, alt: property.title });
  for (const img of property.images) {
    if (!galleryImages.some((g) => g.url === img.url)) {
      galleryImages.push({ url: img.url, alt: img.alt || property.title });
    }
  }

  const waMessage = property.whatsappMessage || `مرحبًا، أنا مهتم بالعقار: ${property.title}`;

  const specs: { icon: typeof Ruler; label: string; value: string }[] = [];
  if (property.area) specs.push({ icon: Ruler, label: "المساحة", value: `${formatNumber(property.area)} م²` });
  if (property.bedrooms != null) specs.push({ icon: BedDouble, label: "غرف النوم", value: `${property.bedrooms}` });
  if (property.bathrooms != null) specs.push({ icon: Bath, label: "الحمامات", value: `${property.bathrooms}` });
  if (property.floor) specs.push({ icon: Layers, label: "الدور", value: property.floor });
  if (property.finishing) specs.push({ icon: Sparkles, label: "التشطيب", value: property.finishing });
  if (property.typeName) specs.push({ icon: Building2, label: "النوع", value: property.typeName });

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "RealEstateListing",
    name: property.title,
    description: property.description || undefined,
    url: `${baseUrl}/properties/${property.slug}`,
    image: property.mainImage ? `${baseUrl}${property.mainImage}` : undefined,
    offers: property.price && ["ج.م", "EGP"].includes(property.currency)
      ? {
          "@type": "Offer",
          price: property.price,
          priceCurrency: "EGP",
          availability: "https://schema.org/InStock",
        }
      : undefined,
  };

  return (
    <div className="bg-sand">
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: safeJsonLd(jsonLd) }} />

      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        {/* Breadcrumb */}
        <nav className="mb-5 flex items-center gap-1.5 text-xs font-semibold text-stone-400" aria-label="مسار التنقل">
          <Link href="/" className="hover:text-brand-700">الرئيسية</Link>
          <ChevronLeft className="h-3.5 w-3.5" />
          <Link href="/properties" className="hover:text-brand-700">العقارات</Link>
          <ChevronLeft className="h-3.5 w-3.5" />
          <span className="max-w-56 truncate text-brand-700">{property.title}</span>
        </nav>

        <div className="grid gap-8 lg:grid-cols-3">
          {/* Main column */}
          <div className="space-y-8 lg:col-span-2">
            <PropertyGallery images={galleryImages} title={property.title} />

            {/* Header info */}
            <div className="rounded-2xl border border-stone-200/80 bg-white p-5 shadow-card sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <div className="mb-2 flex flex-wrap gap-1.5">
                    <span className={cn(
                      "rounded-full px-3 py-1 text-xs font-black text-white",
                      property.listingType === "sale" ? "bg-brand-700" : "bg-gold-600",
                    )}>
                      {property.listingType === "sale" ? "للبيع" : "للإيجار"}
                    </span>
                    {property.typeName && (
                      <span className="rounded-full bg-stone-100 px-3 py-1 text-xs font-black text-ink">{property.typeName}</span>
                    )}
                    {property.featured && (
                      <span className="rounded-full bg-gold-100 px-3 py-1 text-xs font-black text-gold-800 ring-1 ring-gold-600/20">عقار مميز</span>
                    )}
                  </div>
                  <h1 className="text-xl font-black leading-snug text-brand-950 sm:text-2xl">{property.title}</h1>
                  {property.location && (
                    <p className="mt-2 flex items-center gap-1.5 text-sm font-semibold text-ink-soft">
                      <MapPin className="h-4.5 w-4.5 text-brand-500" />
                      {property.location}
                    </p>
                  )}
                  {property.address && <p className="mt-1 text-xs text-stone-400">{property.address}</p>}
                </div>
                <div className="text-start">
                  <p className="text-xs font-bold text-stone-400">السعر</p>
                  <p className="mt-0.5 text-2xl font-black text-brand-800">{formatPrice(property.price, property.currency)}</p>

                </div>
              </div>

              {specs.length > 0 && (
                <div className="mt-5 grid grid-cols-3 gap-3 border-t border-stone-100 pt-5 sm:grid-cols-6">
                  {specs.map((s) => (
                    <div key={s.label} className="flex flex-col items-center gap-1.5 rounded-xl bg-sand px-2 py-3.5 text-center">
                      <s.icon className="h-5 w-5 text-brand-600" />
                      <span className="text-[11px] font-bold text-stone-400">{s.label}</span>
                      <span className="text-sm font-black text-brand-950">{s.value}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Description */}
            {property.description && (
              <section className="rounded-2xl border border-stone-200/80 bg-white p-5 shadow-card sm:p-6" aria-labelledby="desc-title">
                <h2 id="desc-title" className="mb-3 text-lg font-black text-brand-950">وصف العقار</h2>
                <p className="whitespace-pre-line text-sm leading-loose text-ink-soft sm:text-base">{property.description}</p>
              </section>
            )}

            {/* Features */}
            {property.features.length > 0 && (
              <section className="rounded-2xl border border-stone-200/80 bg-white p-5 shadow-card sm:p-6" aria-labelledby="features-title">
                <h2 id="features-title" className="mb-4 text-lg font-black text-brand-950">المميزات</h2>
                <ul className="grid gap-2.5 sm:grid-cols-2">
                  {property.features.map((f) => (
                    <li key={f} className="flex items-center gap-2.5 rounded-xl bg-sand px-4 py-3 text-sm font-bold text-ink">
                      <CheckCircle2 className="h-4.5 w-4.5 shrink-0 text-emerald-600" />
                      {f}
                    </li>
                  ))}
                </ul>
              </section>
            )}

            {/* Map */}
            {property.googleMapsUrl && (
              <section className="overflow-hidden rounded-2xl border border-stone-200/80 bg-white shadow-card" aria-labelledby="map-title">
                <h2 id="map-title" className="p-5 pb-0 text-lg font-black text-brand-950 sm:px-6">الموقع على الخريطة</h2>
                <div className="p-4 sm:p-6">
                  {isMapsEmbed(property.googleMapsUrl) ? (
                    <iframe
                      src={property.googleMapsUrl}
                      title={`موقع ${property.title} على الخريطة`}
                      className="h-72 w-full rounded-xl border-0 sm:h-80"
                      loading="lazy"
                      allowFullScreen
                      referrerPolicy="no-referrer-when-downgrade"
                    />
                  ) : (
                    <a
                      href={property.googleMapsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 rounded-xl bg-brand-50 py-8 text-sm font-black text-brand-700 transition hover:bg-brand-100"
                    >
                      <Map className="h-5 w-5" />
                      عرض الموقع على خرائط Google
                    </a>
                  )}
                </div>
              </section>
            )}
          </div>

          {/* Sidebar */}
          <aside className="space-y-5">
            {/* Price & CTA */}
            <div className="rounded-2xl border border-stone-200/80 bg-white p-5 shadow-card sm:p-6">
              <p className="text-xs font-bold text-stone-400">سعر العقار</p>
              <p className="mt-1 text-3xl font-black text-brand-800">{formatPrice(property.price, property.currency)}</p>

              <div className="mt-5 space-y-2.5">
                {business.whatsapp && (
                  <a
                    href={whatsappLink(business.whatsapp, waMessage)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-[#25d366] py-3.5 text-sm font-black text-white shadow-sm transition hover:brightness-95 active:scale-[0.98]"
                  >
                    <WhatsAppGlyph className="h-5 w-5" />
                    تواصل عبر واتساب
                  </a>
                )}
                {business.phone && (
                  <a
                    href={`tel:${business.phone}`}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-brand-700 py-3.5 text-sm font-black text-white shadow-sm transition hover:bg-brand-800 active:scale-[0.98]"
                  >
                    <Phone className="h-4.5 w-4.5" />
                    <span dir="ltr">{business.phone}</span>
                  </a>
                )}
                {!business.whatsapp && !business.phone && (
                  <p className="rounded-xl bg-sand px-4 py-3 text-center text-xs leading-relaxed text-stone-400">
                    أرسل استفسارك من النموذج بالأسفل وسنعاود التواصل معك
                  </p>
                )}

              </div>

              <ShareProperty title={property.title} />
            </div>

            {/* Contact form */}
            <div className="rounded-2xl border border-stone-200/80 bg-white p-5 shadow-card sm:p-6">
              <h2 className="mb-1 text-lg font-black text-brand-950">أرسل استفسارك</h2>
              <p className="mb-4 text-xs text-stone-400">سيتواصل معك فريقنا في أقرب وقت</p>
              <ContactForm propertyId={property.id} propertyTitle={property.title} compact />
            </div>
          </aside>
        </div>

        {/* Similar */}
        {similar.length > 0 && (
          <section className="mt-14" aria-labelledby="similar-title">
            <SectionHeading title="عقارات مشابهة" subtitle="قد يعجبك أيضًا من نفس الفئة" linkHref="/properties" linkLabel="عرض الكل" />
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {similar.map((p) => (
                <PropertyCard key={p.id} property={p} whatsapp={business.whatsapp || undefined} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
