import Link from "next/link";
import type { Metadata } from "next";
import { Building2, ChevronRight, ChevronLeft, SearchX } from "lucide-react";
import { getPublishedProperties, getAllPropertyTypes, getDistinctLocations } from "@/lib/public-data";
import { getBusinessSettings } from "@/lib/settings";
import { PropertyFilters } from "@/components/site/property-filters";
import { PropertyCard } from "@/components/site/property-card";
import { cn } from "@/lib/utils";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "العقارات",
  description: "تصفح جميع العقارات المتاحة للبيع والإيجار مع فلاتر بحث متقدمة",
  alternates: { canonical: "/properties" },
};

export default async function PropertiesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const get = (k: string) => (typeof sp[k] === "string" ? (sp[k] as string) : undefined);

  const [business, types, locations, result] = await Promise.all([
    getBusinessSettings(),
    getAllPropertyTypes(),
    getDistinctLocations(),
    getPublishedProperties({
      q: get("q"),
      listing: get("listing"),
      type: get("type"),
      location: get("location"),
      minPrice: get("minPrice"),
      maxPrice: get("maxPrice"),
      beds: get("beds"),
      baths: get("baths"),
      minArea: get("minArea"),
      maxArea: get("maxArea"),
      sort: get("sort"),
      featuredOnly: get("featured") === "1",
      page: Number(get("page") ?? "1") || 1,
    }),
  ]);

  const hasFilters = ["q", "listing", "type", "location", "minPrice", "maxPrice", "beds", "baths", "minArea", "maxArea", "featured"].some(
    (k) => sp[k],
  );

  function pageHref(n: number) {
    const p = new URLSearchParams();
    for (const [k, v] of Object.entries(sp)) {
      if (typeof v === "string") p.set(k, v);
    }
    p.set("page", String(n));
    return `/properties?${p.toString()}`;
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14 lg:px-8">
      {/* Heading */}
      <div className="mb-8">
        <span className="mb-2 block h-1 w-12 rounded-full bg-gold-500" />
        <h1 className="text-2xl font-black text-brand-950 sm:text-3xl">تصفح العقارات</h1>
        <p className="mt-2 text-sm text-ink-soft sm:text-base">
          استخدم الفلاتر للوصول إلى العقار المناسب لك بسرعة
        </p>
      </div>

      <PropertyFilters types={types} locations={locations} total={result.total} />

      {result.items.length === 0 ? (
        <div className="flex flex-col items-center rounded-3xl border-2 border-dashed border-stone-200 bg-white px-6 py-16 text-center">
          <span className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-50 text-brand-300">
            {hasFilters ? <SearchX className="h-8 w-8" /> : <Building2 className="h-8 w-8" />}
          </span>
          {hasFilters ? (
            <>
              <p className="text-lg font-black text-brand-950">لا توجد نتائج مطابقة للفلاتر الحالية</p>
              <p className="mt-2 text-sm text-ink-soft">جرّب تعديل الفلاتر أو توسيع نطاق البحث</p>
              <Link href="/properties" className="mt-5 inline-flex rounded-xl bg-brand-700 px-6 py-3 text-sm font-black text-white transition hover:bg-brand-800">
                مسح الفلاتر وعرض الكل
              </Link>
            </>
          ) : (
            <>
              <p className="text-lg font-black text-brand-950">لا توجد عقارات منشورة حاليًا</p>
              <p className="mt-2 max-w-md text-sm leading-relaxed text-ink-soft">
                سيتم إضافة العقارات المتاحة قريبًا. تواصل معنا وسجل اهتمامك ليصلك الجديد أولًا.
              </p>
              <Link href="/contact" className="mt-5 inline-flex rounded-xl bg-brand-700 px-6 py-3 text-sm font-black text-white transition hover:bg-brand-800">
                تواصل معنا
              </Link>
            </>
          )}
        </div>
      ) : (
        <>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {result.items.map((p) => (
              <PropertyCard key={p.id} property={p} whatsapp={business.whatsapp || undefined} />
            ))}
          </div>

          {/* Pagination */}
          {result.pages > 1 && (
            <nav className="mt-10 flex items-center justify-center gap-1.5" aria-label="ترقيم الصفحات">
              {result.page > 1 && (
                <Link
                  href={pageHref(result.page - 1)}
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-stone-200 bg-white text-ink transition hover:border-brand-500"
                  aria-label="الصفحة السابقة"
                >
                  <ChevronRight className="h-4.5 w-4.5" />
                </Link>
              )}
              {Array.from({ length: result.pages }, (_, i) => i + 1)
                .filter((n) => Math.abs(n - result.page) <= 2 || n === 1 || n === result.pages)
                .map((n, idx, arr) => (
                  <span key={n} className="flex items-center gap-1.5">
                    {idx > 0 && arr[idx - 1] < n - 1 && <span className="px-1 text-stone-300">…</span>}
                    <Link
                      href={pageHref(n)}
                      className={cn(
                        "flex h-10 w-10 items-center justify-center rounded-xl text-sm font-black transition",
                        n === result.page
                          ? "bg-brand-700 text-white shadow-sm"
                          : "border border-stone-200 bg-white text-ink hover:border-brand-500",
                      )}
                      aria-current={n === result.page ? "page" : undefined}
                    >
                      {n}
                    </Link>
                  </span>
                ))}
              {result.page < result.pages && (
                <Link
                  href={pageHref(result.page + 1)}
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-stone-200 bg-white text-ink transition hover:border-brand-500"
                  aria-label="الصفحة التالية"
                >
                  <ChevronLeft className="h-4.5 w-4.5" />
                </Link>
              )}
            </nav>
          )}
        </>
      )}
    </div>
  );
}
