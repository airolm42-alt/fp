import Image from "next/image";
import Link from "next/link";
import type { Metadata } from "next";
import { Target, Eye as EyeIcon, Gem, ArrowLeft, MapPin, Info } from "lucide-react";
import { getAboutSettings } from "@/lib/settings";
import { getPublishedAreas } from "@/lib/public-data";

export const revalidate = 60;

export const metadata: Metadata = {
  title: "من نحن",
  description: "تعرف على نشاطنا ورسالتنا ورؤيتنا",
  alternates: { canonical: "/about" },
};

export default async function AboutPage() {
  const [about, areasList] = await Promise.all([getAboutSettings(), getPublishedAreas()]);
  const hasContent = about.title || about.description || about.mission || about.vision || about.values.length > 0 || about.images.length > 0;

  return (
    <div>
      {/* Header */}
      <section className="bg-brand-950 py-14 pattern-arabesque sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <span className="mb-2 block h-1 w-12 rounded-full bg-gold-400" />
          <h1 className="text-3xl font-black text-white sm:text-4xl">{about.title || "من نحن"}</h1>
          {about.description && (
            <p className="mt-4 max-w-3xl text-base leading-loose text-brand-100/70 sm:text-lg">
              {about.description.split("\n")[0]}
            </p>
          )}
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6 sm:py-16 lg:px-8">
        {!hasContent ? (
          <div className="flex flex-col items-center rounded-3xl border-2 border-dashed border-stone-200 bg-white px-6 py-16 text-center">
            <span className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-50 text-brand-300">
              <Info className="h-8 w-8" />
            </span>
            <p className="text-lg font-black text-brand-950">محتوى هذه الصفحة قيد الإعداد</p>
            <p className="mt-2 max-w-md text-sm leading-relaxed text-ink-soft">
              سيتم تحديث صفحة التعريف بالنشاط قريبًا. تواصل معنا الآن لأي استفسار.
            </p>
            <Link href="/contact" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-brand-700 px-6 py-3 text-sm font-black text-white transition hover:bg-brand-800">
              تواصل معنا
              <ArrowLeft className="h-4 w-4" />
            </Link>
          </div>
        ) : (
          <div className="space-y-14">
            {/* Description + images */}
            <div className="grid items-start gap-10 lg:grid-cols-2">
              {about.description && (
                <div>
                  <h2 className="mb-4 text-xl font-black text-brand-950 sm:text-2xl">نبذة عنّا</h2>
                  <p className="whitespace-pre-line text-sm leading-loose text-ink-soft sm:text-base">
                    {about.description}
                  </p>
                </div>
              )}
              {about.images.length > 0 && (
                <div className="grid gap-3 sm:grid-cols-2">
                  {about.images.slice(0, 4).map((img, i) => (
                    <div
                      key={img}
                      className={`relative overflow-hidden rounded-2xl bg-sand-dark ${i === 0 && about.images.length > 1 ? "sm:col-span-2 aspect-[16/9]" : "aspect-[4/3]"}`}
                    >
                      <Image src={img} alt={`${about.title || "صورة المكتب"} — ${i + 1}`} fill className="object-cover transition-transform duration-500 hover:scale-105" sizes="(max-width: 1024px) 100vw, 50vw" />
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Mission / Vision */}
            {(about.mission || about.vision) && (
              <div className="grid gap-5 md:grid-cols-2">
                {about.mission && (
                  <div className="rounded-2xl border border-stone-200/70 bg-white p-7 shadow-card">
                    <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-brand-700 text-gold-300">
                      <Target className="h-6 w-6" />
                    </span>
                    <h2 className="text-lg font-black text-brand-950">رسالتنا</h2>
                    <p className="mt-2.5 whitespace-pre-line text-sm leading-loose text-ink-soft">{about.mission}</p>
                  </div>
                )}
                {about.vision && (
                  <div className="rounded-2xl border border-stone-200/70 bg-white p-7 shadow-card">
                    <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gold-100 text-gold-700">
                      <EyeIcon className="h-6 w-6" />
                    </span>
                    <h2 className="text-lg font-black text-brand-950">رؤيتنا</h2>
                    <p className="mt-2.5 whitespace-pre-line text-sm leading-loose text-ink-soft">{about.vision}</p>
                  </div>
                )}
              </div>
            )}

            {/* Values */}
            {about.values.length > 0 && (
              <section aria-labelledby="values-title">
                <h2 id="values-title" className="mb-6 text-xl font-black text-brand-950 sm:text-2xl">قيمنا</h2>
                <div className="flex flex-wrap gap-3">
                  {about.values.map((v) => (
                    <span key={v} className="inline-flex items-center gap-2 rounded-2xl border border-gold-200 bg-gold-50 px-5 py-3 text-sm font-black text-gold-800">
                      <Gem className="h-4 w-4" />
                      {v}
                    </span>
                  ))}
                </div>
              </section>
            )}

            {/* Areas */}
            {areasList.length > 0 && (
              <section aria-labelledby="areas-title">
                <h2 id="areas-title" className="mb-6 text-xl font-black text-brand-950 sm:text-2xl">مناطق نخدمها</h2>
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  {areasList.map((a) => (
                    <Link
                      key={a.id}
                      href={`/properties?location=${encodeURIComponent(a.name)}`}
                      className="flex items-center gap-3 rounded-2xl border border-stone-200/70 bg-white p-4 shadow-card transition hover:-translate-y-0.5 hover:shadow-card-hover"
                    >
                      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-brand-50 text-brand-600">
                        <MapPin className="h-5 w-5" />
                      </span>
                      <span className="text-sm font-black text-brand-950">{a.name}</span>
                    </Link>
                  ))}
                </div>
              </section>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
