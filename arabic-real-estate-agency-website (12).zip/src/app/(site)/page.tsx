import Link from "next/link";
import Image from "next/image";
import {
  Building2,
  Search,
  Phone,
  MapPin,
  ShieldCheck,
  Handshake,
  FileCheck,
  Compass,
  ArrowLeft,
  Briefcase,
} from "lucide-react";
import { getAllSettings } from "@/lib/settings";
import {
  getFeaturedProperties,
  getPublishedServices,
  getPublishedAreas,
  getAllPropertyTypes,
  getDistinctLocations,
} from "@/lib/public-data";
import { HeroSearch } from "@/components/site/hero-search";
import { PropertyCard } from "@/components/site/property-card";
import { SectionHeading } from "@/components/site/section-heading";
import { ReviewsSection } from "@/components/site/reviews-section";
import { whatsappLink } from "@/lib/utils";

export const revalidate = 60;

const WHY_US = [
  {
    icon: ShieldCheck,
    title: "شفافية كاملة",
    text: "قارن السعر والمواصفات والموقع، وتأكد من التفاصيل قبل اتخاذ القرار.",
  },
  {
    icon: Handshake,
    title: "خطوات تعاقد واضحة",
    text: "حدّد مراحل المعاينة والتعاقد والاستلام بوضوح مع الأطراف المعنية.",
  },
  {
    icon: FileCheck,
    title: "مراجعة المستندات",
    text: "راجع المستندات القانونية واستعن بمتخصص قبل إتمام أي تعاقد.",
  },
  {
    icon: Compass,
    title: "اختيارات تناسب هدفك",
    text: "اختر بناءً على احتياجك وميزانيتك، وليس على الصور وحدها.",
  },
];

export default async function HomePage() {
  const [{ business, site, about }, featured, servicesList, areasList, types, locations] = await Promise.all([
    getAllSettings(),
    getFeaturedProperties(6),
    getPublishedServices(),
    getPublishedAreas(),
    getAllPropertyTypes(),
    getDistinctLocations(),
  ]);

  const heroTitle = site.heroTitle || "اعثر على عقارك المثالي بكل سهولة";
  const heroSubtitle =
    site.heroSubtitle ||
    "سجل بيانات تواصلك معنا، وسنساعدك في الوصول إلى العقار المناسب لاحتياجك وميزانيتك — شقق، فيلات، وعقارات تجارية للبيع والإيجار.";

  return (
    <div>
      {/* ============================= HERO ============================= */}
      <section className="relative overflow-hidden bg-brand-950 pattern-arabesque">
        {site.heroImage && (
          <>
            <Image src={site.heroImage} alt="واجهة الموقع الرئيسية" fill priority className="object-cover opacity-40" sizes="100vw" />
            <div className="absolute inset-0 bg-gradient-to-b from-brand-950/70 via-brand-950/60 to-brand-950" />
          </>
        )}
        {!site.heroImage && (
          <>
            <div className="pointer-events-none absolute -top-32 start-1/4 h-96 w-96 rounded-full bg-brand-600/20 blur-3xl" />
            <div className="pointer-events-none absolute bottom-0 end-0 h-80 w-80 rounded-full bg-gold-500/10 blur-3xl" />
          </>
        )}

        <div className="relative mx-auto max-w-7xl px-4 pb-32 pt-16 sm:px-6 sm:pt-24 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            {business.businessName && (
              <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-xs font-black tracking-wide text-gold-300 animate-rise">
                <Building2 className="h-3.5 w-3.5" />
                {business.businessName}
              </span>
            )}
            <h1 className="text-3xl font-black leading-[1.25] text-white animate-rise sm:text-5xl sm:leading-[1.2]">
              {heroTitle}
            </h1>
            <p className="mx-auto mt-5 max-w-2xl text-base leading-relaxed text-brand-100/70 animate-rise-1 sm:text-lg">
              {heroSubtitle}
            </p>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-3 animate-rise-2">
              <Link
                href="/properties"
                className="inline-flex items-center gap-2 rounded-xl bg-gold-500 px-7 py-3.5 text-sm font-black text-brand-950 shadow-lg shadow-gold-500/25 transition hover:bg-gold-400 active:scale-[0.98]"
              >
                <Search className="h-4.5 w-4.5" />
                تصفح العقارات
              </Link>
              {business.whatsapp ? (
                <a
                  href={whatsappLink(business.whatsapp, "مرحبًا، أريد الاستفسار عن العقارات المتاحة")}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/5 px-7 py-3.5 text-sm font-black text-white backdrop-blur-sm transition hover:bg-white/10"
                >
                  تواصل معنا
                  <ArrowLeft className="h-4 w-4" />
                </a>
              ) : business.phone ? (
                <a
                  href={`tel:${business.phone}`}
                  className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/5 px-7 py-3.5 text-sm font-black text-white backdrop-blur-sm transition hover:bg-white/10"
                >
                  <Phone className="h-4.5 w-4.5" />
                  اتصل بنا
                </a>
              ) : (
                <Link
                  href="/contact"
                  className="inline-flex items-center gap-2 rounded-xl border border-white/20 bg-white/5 px-7 py-3.5 text-sm font-black text-white backdrop-blur-sm transition hover:bg-white/10"
                >
                  تواصل معنا
                  <ArrowLeft className="h-4 w-4" />
                </Link>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* ========================= SEARCH CARD ========================== */}
      <div className="relative z-10 mx-auto -mt-16 max-w-5xl px-4 sm:px-6 animate-rise-3">
        <HeroSearch types={types} locations={locations} />
      </div>

      {/* ====================== FEATURED PROPERTIES ===================== */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
        <SectionHeading
          title="عقارات مميزة"
          subtitle="أحدث العقارات المختارة بعناية من محفظتنا"
          linkHref="/properties"
          linkLabel="عرض جميع العقارات"
        />
        {featured.length === 0 ? (
          <div className="flex flex-col items-center rounded-3xl border-2 border-dashed border-stone-200 bg-white px-6 py-16 text-center">
            <span className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-50 text-brand-300">
              <Building2 className="h-8 w-8" />
            </span>
            <p className="text-lg font-black text-brand-950">سيتم إضافة العقارات المتاحة قريبًا</p>
            <p className="mt-2 max-w-md text-sm leading-relaxed text-ink-soft">
              نعمل حاليًا على تحديث محفظة العقارات. تابعنا أو تواصل معنا ليصلك جديد العروض فور توفرها.
            </p>
            {(business.phone || business.whatsapp) && (
              <Link href="/contact" className="mt-5 inline-flex items-center gap-2 rounded-xl bg-brand-700 px-6 py-3 text-sm font-black text-white transition hover:bg-brand-800">
                سجل اهتمامك الآن
                <ArrowLeft className="h-4 w-4" />
              </Link>
            )}
          </div>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {featured.map((p) => (
              <PropertyCard key={p.id} property={p} whatsapp={business.whatsapp || undefined} />
            ))}
          </div>
        )}
      </section>

      {/* =========================== SERVICES =========================== */}
      <section className="bg-sand-dark/60 py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <SectionHeading
            title="خدماتنا"
            subtitle="حلول عقارية متكاملة من البحث حتى الاستلام"
            linkHref="/services"
            linkLabel="كل الخدمات"
          />
          {servicesList.length === 0 ? (
            <div className="flex flex-col items-center rounded-3xl border-2 border-dashed border-stone-200 bg-white px-6 py-14 text-center">
              <span className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-brand-50 text-brand-300">
                <Briefcase className="h-8 w-8" />
              </span>
              <p className="text-lg font-black text-brand-950">تفاصيل خدماتنا ستُعلن قريبًا</p>
              <p className="mt-2 text-sm text-ink-soft">تواصل معنا لمعرفة كيف يمكننا مساعدتك</p>
            </div>
          ) : (
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {servicesList.slice(0, 6).map((s) => (
                <div key={s.id} className="group rounded-2xl border border-stone-200/70 bg-white p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover">
                  <div className="relative mb-4 h-14 w-14 overflow-hidden rounded-2xl bg-brand-700 text-gold-300">
                    {s.image ? (
                      <Image src={s.image} alt={s.title} fill className="object-cover" sizes="56px" />
                    ) : (
                      <span className="flex h-full items-center justify-center">
                        <Briefcase className="h-6 w-6" />
                      </span>
                    )}
                  </div>
                  <h3 className="text-base font-extrabold text-brand-950 sm:text-lg">{s.title}</h3>
                  <p className="mt-2 line-clamp-3 text-sm leading-relaxed text-ink-soft">{s.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ========================== WHY CHOOSE US ======================== */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
        <SectionHeading title="خطوات تساعدك على الاختيار" subtitle="نقاط مهمة قبل اتخاذ قرار شراء أو استئجار عقار" />
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {WHY_US.map((w) => (
            <div key={w.title} className="rounded-2xl border border-stone-200/70 bg-white p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover">
              <span className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gold-100 text-gold-700">
                <w.icon className="h-6 w-6" />
              </span>
              <h3 className="text-base font-extrabold text-brand-950">{w.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-ink-soft">{w.text}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ============================ AREAS ============================= */}
      {areasList.length > 0 && (
        <section className="bg-white py-16 sm:py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <SectionHeading title="مناطق نخدمها" subtitle="نغطي مجموعة من أهم المناطق والأحياء" />
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
              {areasList.map((a) => (
                <Link
                  key={a.id}
                  href={`/properties?location=${encodeURIComponent(a.name)}`}
                  className="group relative overflow-hidden rounded-2xl border border-stone-200/70 bg-brand-950 p-6 shadow-card transition-all duration-300 hover:-translate-y-1 hover:shadow-card-hover"
                >
                  {a.image && (
                    <>
                      <Image src={a.image} alt={a.name} fill className="object-cover opacity-45 transition-transform duration-500 group-hover:scale-105" sizes="(max-width: 640px) 100vw, 25vw" />
                      <div className="absolute inset-0 bg-gradient-to-t from-brand-950/90 to-brand-950/30" />
                    </>
                  )}
                  <div className="relative">
                    <MapPin className="mb-3 h-6 w-6 text-gold-400" />
                    <h3 className="text-lg font-black text-white">{a.name}</h3>
                    {a.description && <p className="mt-1.5 line-clamp-2 text-xs leading-relaxed text-white/70">{a.description}</p>}
                    <span className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-gold-300 transition group-hover:gap-2">
                      تصفح عقارات المنطقة <ArrowLeft className="h-3.5 w-3.5" />
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ========================= ABOUT SNIPPET ======================== */}
      <section className="relative overflow-hidden bg-brand-950 py-16 pattern-arabesque sm:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid items-center gap-10 lg:grid-cols-2">
            <div>
              <span className="mb-2 block h-1 w-12 rounded-full bg-gold-400" />
              <h2 className="text-2xl font-black text-white sm:text-3xl">
                {about.title || `من نحن`}
              </h2>
              <p className="mt-4 max-w-xl text-sm leading-loose text-brand-100/70 sm:text-base">
                {about.description
                  ? about.description.slice(0, 320) + (about.description.length > 320 ? "…" : "")
                  : "تعرف على نشاطنا وأسلوب عملنا وقيمنا التي نلتزم بها مع كل عميل."}
              </p>
              <Link
                href="/about"
                className="mt-6 inline-flex items-center gap-2 rounded-xl bg-gold-500 px-6 py-3 text-sm font-black text-brand-950 transition hover:bg-gold-400"
              >
                اقرأ المزيد عنا
                <ArrowLeft className="h-4 w-4" />
              </Link>
            </div>
            {about.images[0] ? (
              <div className="relative aspect-[4/3] overflow-hidden rounded-3xl shadow-2xl">
                <Image src={about.images[0]} alt={about.title || "صورة المكتب"} fill className="object-cover" sizes="(max-width: 1024px) 100vw, 50vw" />
              </div>
            ) : (
              <div className="hidden aspect-[4/3] items-center justify-center rounded-3xl border border-white/10 bg-white/5 lg:flex">
                <Building2 className="h-20 w-20 text-white/10" />
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ========================= GOOGLE REVIEWS ======================= */}
      <ReviewsSection googleReviewsUrl={business.googleReviewsUrl} />

      {/* ============================ CONTACT CTA ======================= */}
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 sm:py-20 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-l from-brand-800 to-brand-950 px-6 py-12 text-center pattern-arabesque sm:px-12 sm:py-16">
          <div className="pointer-events-none absolute -top-20 end-0 h-64 w-64 rounded-full bg-gold-500/15 blur-3xl" />
          <h2 className="relative text-2xl font-black text-white sm:text-3xl">جاهز للخطوة القادمة؟</h2>
          <p className="relative mx-auto mt-3 max-w-xl text-sm leading-relaxed text-brand-100/70 sm:text-base">
            سواء كنت تبحث عن شراء أو بيع أو استئجار عقار — فريقنا جاهز لمساعدتك. راسلنا وسنرد عليك في أقرب وقت.
          </p>
          <div className="relative mt-7 flex flex-wrap items-center justify-center gap-3">
            <Link href="/contact" className="inline-flex items-center gap-2 rounded-xl bg-gold-500 px-7 py-3.5 text-sm font-black text-brand-950 transition hover:bg-gold-400">
              تواصل معنا الآن
              <ArrowLeft className="h-4 w-4" />
            </Link>
            {business.phone && (
              <a href={`tel:${business.phone}`} className="inline-flex items-center gap-2 rounded-xl border border-white/25 px-7 py-3.5 text-sm font-black text-white transition hover:bg-white/10">
                <Phone className="h-4.5 w-4.5" />
                <span dir="ltr">{business.phone}</span>
              </a>
            )}
          </div>
        </div>
      </section>
    </div>
  );
}
