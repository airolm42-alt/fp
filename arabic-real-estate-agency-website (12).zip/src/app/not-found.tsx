import Link from "next/link";
import { Home, Search } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-sand px-4 py-20 text-center">
      <p className="text-7xl font-black text-brand-200 sm:text-8xl">404</p>
      <h1 className="mt-4 text-2xl font-black text-brand-950">الصفحة غير موجودة</h1>
      <p className="mt-2 max-w-sm text-sm leading-relaxed text-ink-soft">
        ربما تم نقل الصفحة أو حذفها، أو أن العقار لم يعد متاحًا. تصفح عقاراتنا المتاحة أو عد للرئيسية.
      </p>
      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <Link href="/" className="inline-flex items-center gap-2 rounded-xl bg-brand-700 px-6 py-3 text-sm font-black text-white transition hover:bg-brand-800">
          <Home className="h-4.5 w-4.5" /> الرئيسية
        </Link>
        <Link href="/properties" className="inline-flex items-center gap-2 rounded-xl border border-stone-300 bg-white px-6 py-3 text-sm font-black text-ink transition hover:border-brand-500">
          <Search className="h-4.5 w-4.5" /> تصفح العقارات
        </Link>
      </div>
    </div>
  );
}
