"use client";

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return <html lang="ar" dir="rtl"><body style={{ margin: 0, background: "#faf8f4", color: "#14201c", fontFamily: "Tahoma, Arial, sans-serif" }}><main role="alert" style={{ maxWidth: 640, margin: "12vh auto", padding: 28, textAlign: "center", lineHeight: 1.9 }}>
    <h1 style={{ fontSize: 26 }}>حدث خطأ مؤقت في تشغيل الموقع</h1>
    <p>حاول إعادة التحميل بعد لحظات. لا نعرض تفاصيل تقنية أو بيانات خاصة هنا حفاظًا على الأمان.</p>
    <button type="button" onClick={reset} style={{ background: "#1f5445", color: "white", border: 0, borderRadius: 12, padding: "12px 24px", cursor: "pointer", fontFamily: "inherit", fontWeight: 700 }}>إعادة المحاولة</button>
  </main></body></html>;
}
