/** Build a complete source ZIP. Requires npm ci; never exports runtime secrets or data. */
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { createSourceBundle } from "../src/lib/source-export";

async function main() {
  const args = process.argv.slice(2);
  if (args.includes("--help")) {
    console.log("Usage: npx tsx scripts/export-project.ts [--output <file.zip>]\nDefault output: exports/arabic-real-estate-source.zip\nThis archives source files, NOT credentials, database data, or uploaded customer images.");
    return;
  }
  if (args.length && (args.length !== 2 || args[0] !== "--output")) throw new Error("Use --output <file.zip> or --help");
  const destination = path.resolve(args[1] ?? "exports/arabic-real-estate-source.zip");
  const publicDirectory = path.resolve("public");
  if (destination === publicDirectory || destination.startsWith(publicDirectory + path.sep)) throw new Error("Never put private source archives in public/");
  if (!destination.toLowerCase().endsWith(".zip")) throw new Error("Output path must end with .zip");

  const bundle = await createSourceBundle();
  await mkdir(path.dirname(destination), { recursive: true });
  await writeFile(destination, bundle.zip);
  console.log(`Complete source archive created: ${bundle.manifest.fileCount} files plus PROJECT-MANIFEST.json.`);
  console.log(`Saved to ${destination}. No .env, credentials, database records, or uploads are included.`);
}

main().catch((error) => { console.error(error instanceof Error ? error.message : "Source export failed"); process.exitCode = 1; });
