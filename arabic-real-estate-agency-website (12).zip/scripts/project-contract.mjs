import { lstatSync, readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";

export const CONTRACT_NAME = "PROJECT-FILES.json";
const BLOCKED_SEGMENTS = new Set(["node_modules", ".next", ".git", ".vercel", ".railway", "coverage"]);
const ROOT_NAMES = new Set([
  CONTRACT_NAME, "package.json", "package-lock.json", "tsconfig.json", "next-env.d.ts",
  "next.config.ts", "postcss.config.mjs", "eslint.config.mjs", "drizzle.config.ts",
  ".env.example", ".gitignore", ".nvmrc", "README.md", "START-HERE.html", "DEPLOYMENT-AR.md", "AUDIT-REPORT-AR.md", "GITHUB-PAGES-AR.md",
]);

export function safeDeliveryPath(name) {
  if (typeof name !== "string" || !name || name.length > 1024 || name.startsWith("/") || /[\\\u0000:]/.test(name)) return false;
  const parts = name.split("/");
  if (parts.some((part) => !part || part === "." || part === ".." || BLOCKED_SEGMENTS.has(part))) return false;
  const filename = parts.at(-1);
  if (filename.startsWith(".env") && name !== ".env.example") return false;
  if (/\.(?:cookies|log|pem|key|p12|pfx|tsbuildinfo)$/i.test(filename) || filename === ".DS_Store") return false;
  if (parts[0] === ".github") return name === ".github/workflows" || name === ".github/workflows/github-pages.yml";
  return ROOT_NAMES.has(name) || ["src", "scripts", "public", "drizzle", "github-pages"].includes(parts[0]) && parts.length > 1;
}

/** Authoritative expected paths, independent of files present when a ZIP is built. */
export function loadDeliveryContract(root) {
  const contractPath = join(root, CONTRACT_NAME);
  const info = lstatSync(contractPath);
  if (!info.isFile() || info.isSymbolicLink() || info.size > 1024 * 1024) throw new Error("Delivery contract must be a small regular JSON file.");
  const value = JSON.parse(readFileSync(contractPath, "utf8"));
  if (value.format !== "arabic-real-estate-delivery-v1" || !Array.isArray(value.files) || !value.files.length || value.files.length > 3000 || !Array.isArray(value.routes)) throw new Error("Invalid delivery contract format.");
  const seen = new Set();
  for (const name of value.files) {
    if (!safeDeliveryPath(name) || seen.has(name)) throw new Error("Unsafe or duplicate required file in delivery contract.");
    seen.add(name);
  }
  for (const necessary of [CONTRACT_NAME, "package.json", "package-lock.json", ".env.example", "src/app/layout.tsx", "src/app/(site)/page.tsx", "src/db/schema.ts", "src/proxy.ts", "scripts/project-contract.mjs"]) {
    if (!seen.has(necessary)) throw new Error(`Delivery contract lacks a baseline file: ${necessary}`);
  }
  for (const route of value.routes) {
    if (!route || !seen.has(route.file) || !["page", "handler", "metadata"].includes(route.kind) || typeof route.path !== "string" || !route.path.startsWith("/") || /[\\\u0000?#]/.test(route.path) || !Array.isArray(route.methods) || route.methods.some((method) => !["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"].includes(method))) throw new Error("Invalid expected route in delivery contract.");
  }
  return value;
}

/** Read-only local file check; no dependencies, network, database, or secrets. */
export function auditDeliveryFiles(root) {
  const errors = [];
  let contract;
  try { contract = loadDeliveryContract(root); }
  catch (error) { return { ok: false, expected: 0, routes: 0, errors: [error instanceof Error ? error.message : "Delivery contract missing"] }; }
  for (const name of contract.files) {
    try {
      const parts = name.split("/");
      for (let index = 1; index <= parts.length; index++) {
        const info = lstatSync(join(root, ...parts.slice(0, index)));
        if (info.isSymbolicLink()) throw new Error("symbolic link");
        if (index < parts.length && !info.isDirectory() || index === parts.length && !info.isFile()) throw new Error("not a regular source path");
      }
    } catch { errors.push(`Required file missing or unsafe: ${name}`); }
  }
  return { ok: errors.length === 0, expected: contract.files.length, routes: contract.routes.length, errors };
}

/** Find actual delivery source paths; never traverse dependencies or private roots. */
export function listActualSourceFiles(root) {
  const result = [];
  function walk(relative) {
    const folder = join(root, relative);
    if (!lstatSync(folder).isDirectory() || lstatSync(folder).isSymbolicLink()) throw new Error(`Unsafe source directory: ${relative}`);
    for (const entry of readdirSync(folder, { withFileTypes: true })) {
      const name = `${relative}/${entry.name}`;
      if (!safeDeliveryPath(name)) continue;
      if (entry.isSymbolicLink()) throw new Error(`Source symbolic link: ${name}`);
      if (entry.isDirectory()) walk(name);
      else if (entry.isFile()) result.push(name);
    }
  }
  for (const dir of ["src", "public", "scripts", "github-pages", ".github"]) walk(dir);
  return result.sort();
}
