import { config } from "dotenv";
import { buildPages } from "../src/lib/pages-build";
import { normalizeSiteOrigin, siteOriginKind } from "../src/lib/site-origin";
config({ quiet: true });

async function main() {
  const args = new Set(process.argv.slice(2));
  if (args.has("--help")) {
    console.log("Usage: PAGES_API_URL=https://your-backend.example PAGES_SITE_URL=https://OWNER.github.io/REPO/ npx tsx scripts/build-pages.ts [--verify-backend]\nOutputs public HTML/CSS/JS to out-pages/. Auth, database, uploads and admin still run on the real backend.\n--verify-backend verifies the live public API BEFORE generating output. GitHub Actions enables it.\n--allow-local is for local integration tests only; never use it in a production workflow.");
    return;
  }
  if ([...args].some((arg) => !["--allow-local", "--verify-backend"].includes(arg))) throw new Error("Unknown option; use --help");
  if (!process.env.PAGES_API_URL) throw new Error("PAGES_API_URL is required. Configure the real public backend URL; no fake or offline property data will be generated.");
  const apiOrigin = normalizeSiteOrigin(process.env.PAGES_API_URL);
  if (!apiOrigin || process.env.PAGES_API_URL.trim().replace(/\/$/, "") !== apiOrigin || !args.has("--allow-local") && siteOriginKind(apiOrigin) === "local") throw new Error("PAGES_API_URL must be a public HTTPS origin without paths, credentials or query strings. --allow-local is for tests only.");

  if (args.has("--verify-backend")) {
    const headers = new Headers();
    if (process.env.PAGES_SITE_URL) {
      const site = new URL(process.env.PAGES_SITE_URL);
      if (!["https:", "http:"].includes(site.protocol) || site.username || site.password || site.search || site.hash) throw new Error("PAGES_SITE_URL is invalid");
      headers.set("Origin", site.origin);
    }
    let response;
    try { response = await fetch(new URL("/api/pages?resource=config", apiOrigin), { headers, credentials: "omit", signal: AbortSignal.timeout(20000) }); }
    catch { throw new Error("Public backend API is unreachable. Deploy the real backend and correct PAGES_API_URL before publishing the static frontend."); }
    const data = await response.json().catch(() => null);
    if (!response.ok || data?.version !== 1 || !data.business || !Array.isArray(data.types) || data.adminUrl !== `${apiOrigin}/admin`) throw new Error("PAGES_API_URL did not return the expected public Pages API. Check backend deployment and PAGES_BACKEND_PUBLIC_ORIGIN.");
    console.log("Live public API verified; admin login stays on the backend.");
    if (!data.inquiriesEnabled) console.warn("Notice: PAGES_ALLOWED_ORIGINS does not allow this Pages origin yet. The frontend will show the backend's secure contact form link until configured.");
  }
  const result = await buildPages({ apiUrl: apiOrigin, siteUrl: process.env.PAGES_SITE_URL, allowLocal: args.has("--allow-local") });
  console.log(`Pages frontend built: ${result.files.length} files in out-pages/ (including index.html).`);
  console.log(`Public API: ${result.apiOrigin}\nProtected admin: ${result.adminUrl}`);
  console.log("Upload only out-pages/ to a static host. Never upload .env, the repository root, .next or server source as a Pages artifact.");
}
main().catch((error) => { console.error(error instanceof Error ? error.message : "Pages build failed"); process.exitCode = 1; });
