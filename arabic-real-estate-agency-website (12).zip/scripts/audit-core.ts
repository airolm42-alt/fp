/**
 * Repeatable integration audit. Run ONLY against a test/preview deployment.
 * AUDIT_BASE_URL, AUDIT_ADMIN_EMAIL and AUDIT_ADMIN_PASSWORD are private env vars.
 * Created fixtures are tagged and deleted individually; existing content is not reset.
 */
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { config } from "dotenv";
import sharp from "sharp";
import { unzipSync } from "fflate";
config({ quiet: true });

async function main() {
  if (process.env.AUDIT_ALLOW_MUTATIONS !== "yes") throw new Error("Run only on a test deployment with AUDIT_ALLOW_MUTATIONS=yes. This audit creates and removes its own fixtures.");
  const base = (process.env.AUDIT_BASE_URL || "http://localhost:3000").replace(/\/$/, "");
  const email = process.env.AUDIT_ADMIN_EMAIL, password = process.env.AUDIT_ADMIN_PASSWORD;
  if (!email || !password) throw new Error("Set private AUDIT_ADMIN_EMAIL and AUDIT_ADMIN_PASSWORD; no credentials are embedded in this script.");
  const tag = `مراجعة-${randomUUID().slice(0, 8)}`;
  let ownerCookie = "", staffId = "", propertyId = "", mediaId = "", inquiryId = "", typeId = "", serviceId = "", areaId = "";
  let passed = 0;
  function pass(name: string) { passed++; console.log(`PASS ${passed}: ${name}`); }
  async function req(route: string, method = "GET", data?: unknown, cookie = ownerCookie) {
    return fetch(base + route, { method, redirect: "manual", headers: { ...(cookie ? { Cookie: cookie } : {}), ...(method !== "GET" ? { Origin: base } : {}), ...(data !== undefined ? { "Content-Type": "application/json" } : {}) }, body: data === undefined ? undefined : JSON.stringify(data) });
  }
  async function login(account: string, passphrase: string) {
    const response = await req("/api/admin/login", "POST", { email: account, password: passphrase }, "");
    assert.equal(response.status, 200, "Audit account login failed");
    return response.headers.get("set-cookie")?.split(";")[0] ?? "";
  }
  try {
    for (const route of ["/", "/properties", "/about", "/services", "/contact", "/privacy", "/terms", "/robots.txt", "/sitemap.xml", "/api/health", "/favicon.svg"]) assert.equal((await req(route, "GET", undefined, "")).status, 200, route);
    pass("All public routes and SEO files return 200");
    for (const route of ["/admin/dashboard", "/admin/properties/new", "/admin/inquiries", "/admin/team", "/admin/diagnostics"]) assert.equal((await req(route, "GET", undefined, "")).status, 307);
    assert.equal((await req("/api/admin/media", "GET", undefined, "")).status, 401);
    assert.equal((await req("/api/admin/publishing/source", "GET", undefined, "")).status, 401);
    pass("Pages and APIs are protected without cookies");
    ownerCookie = await login(email, password); assert.ok(ownerCookie);
    assert.equal((await req("/admin/diagnostics")).status, 200);
    assert.equal((await req("/api/admin/team", "POST", { name: tag, email: `${tag}@example.invalid`, password: "weak" })).status, 400);
    pass("Owner access and password validation work");
    for (const query of ["page=Infinity", "minPrice=Infinity", "beds=1.5", "type=aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa", "maxArea=999999999999999999999"]) assert.equal((await req(`/properties?${query}`, "GET", undefined, "")).status, 200);
    assert.equal((await req("/api/admin/properties/not-a-uuid", "PATCH", { status: "published" })).status, 400);
    assert.equal((await req(`/api/admin/properties/${randomUUID()}`, "PATCH", { status: "published" })).status, 404);
    pass("Malformed filter and missing record inputs do not crash pages");

    let response = await req("/api/admin/types", "POST", { name: tag, slug: `audit-${randomUUID()}` }); assert.equal(response.status, 200); typeId = (await response.json()).item.id;
    response = await req("/api/admin/services", "POST", { title: tag, description: "خدمة اختبار مؤقتة", published: false }); assert.equal(response.status, 200); serviceId = (await response.json()).id;
    response = await req("/api/admin/areas", "POST", { name: tag, description: "منطقة اختبار مؤقتة", published: false }); assert.equal(response.status, 200); areaId = (await response.json()).id;
    assert.equal((await req(`/api/admin/services/${serviceId}`, "PUT", { title: tag, published: true })).status, 200);
    assert.ok((await (await req("/services", "GET", undefined, "")).text()).includes(tag));
    assert.equal((await req(`/api/admin/services/${serviceId}`, "PUT", { title: tag, published: false })).status, 200);
    pass("Type, service and area CRUD works; publication reaches public page");

    const image = await sharp({ create: { width: 64, height: 48, channels: 3, background: "#174437" } }).png().toBuffer();
    const form = new FormData(); form.append("files", new Blob([new Uint8Array(image)], { type: "image/png" }), `${tag}.png`);
    response = await fetch(base + "/api/admin/upload", { method: "POST", headers: { Cookie: ownerCookie, Origin: base }, body: form }); assert.equal(response.status, 200); const imageUrl = (await response.json()).files[0].url;
    const library = await (await req("/api/admin/media")).json(); mediaId = library.items.find((file: { url: string }) => file.url === imageUrl).id;
    assert.equal((await req(imageUrl, "GET", undefined, "")).status, 200);
    const broken = new FormData(); broken.append("files", new Blob(["not an image"], { type: "image/png" }), "broken.png");
    response = await fetch(base + "/api/admin/upload", { method: "POST", headers: { Cookie: ownerCookie, Origin: base }, body: broken }); assert.equal(response.status, 400);
    pass("Images upload, optimize and serve; corrupt images are rejected");

    const property = { title: tag, listingType: "sale", typeId, price: 123456, currency: "ج.م", area: 95, bedrooms: 2, bathrooms: 1, location: tag, features: ["ميزة اختبار"], mainImage: imageUrl, images: [{ url: imageUrl, alt: tag }], status: "draft" };
    response = await req("/api/admin/properties", "POST", property); assert.equal(response.status, 200); const created = await response.json(); propertyId = created.id; const slug = created.slug;
    assert.equal((await req(`/properties/${slug}`, "GET", undefined, "")).status, 404);
    assert.equal((await req("/api/admin/media", "DELETE", { ids: [mediaId] })).status, 409);
    assert.equal((await req(`/api/admin/properties/${propertyId}`, "PATCH", { status: "published", featured: true })).status, 200);
    let html = await (await req(`/properties/${slug}`, "GET", undefined, "")).text(); assert.ok(html.includes(tag));
    const attack = `</script><script id="audit-xss">alert(1)</script>`;
    response = await req(`/api/admin/properties/${propertyId}`, "PUT", { ...property, title: tag + " تعديل", description: attack, status: "published" }); assert.equal(response.status, 200); assert.equal((await response.json()).slug, slug);
    html = await (await req(`/properties/${slug}`, "GET", undefined, "")).text(); assert.ok(html.includes("تعديل")); assert.ok(!html.includes('<script id="audit-xss">'));
    assert.equal((await req(`/api/admin/properties/${propertyId}`, "PUT", { ...property, typeId: randomUUID(), status: "published" })).status, 400);
    assert.ok((await (await req(`/properties/${slug}`, "GET", undefined, "")).text()).includes("تعديل"));
    pass("Draft/publish/edit works, slug persists, gallery is protected, invalid edits roll back, JSON-LD is escaped");
    assert.equal((await req("/api/admin/settings", "PUT", { section: "business", data: { facebook: "javascript:alert(1)" } })).status, 400);
    pass("Unsafe business links are rejected server-side");

    response = await req("/api/inquiries", "POST", { name: tag, phone: "01000000000", message: tag + " رسالة اختبار", propertyId }, ""); assert.equal(response.status, 200);
    const inquiries = await (await req(`/api/admin/inquiries?q=${encodeURIComponent(tag)}`)).json(); inquiryId = inquiries.items.find((item: { name: string }) => item.name === tag).id;
    assert.equal((await req(`/api/admin/inquiries/${inquiryId}`, "PATCH", { status: "contacted" })).status, 200);
    assert.equal((await req(`/api/admin/properties/${propertyId}`, "PATCH", { status: "draft" })).status, 200);
    assert.equal((await req(`/properties/${slug}`, "GET", undefined, "")).status, 404);
    assert.equal((await req("/api/inquiries", "POST", { name: tag, phone: "01000000000", message: "رسالة لعقار مسودة", propertyId }, "")).status, 400);
    pass("Inquiry submits and appears in admin; unpublishing removes property and rejects draft inquiry");

    const staffEmail = `audit-${randomUUID()}@example.invalid`, staffPassword = randomUUID().replaceAll("-", "") + "Az9", newPassword = randomUUID().replaceAll("-", "") + "By8";
    response = await req("/api/admin/team", "POST", { name: tag, email: staffEmail, password: staffPassword, mustChangePassword: true }); assert.equal(response.status, 200); staffId = (await response.json()).id;
    let staffCookie = await login(staffEmail, staffPassword);
    assert.equal((await req("/api/admin/properties", "GET", undefined, staffCookie)).status, 403);
    const beforeChangeCookie = staffCookie;
    response = await req("/api/admin/account", "PUT", { action: "password", data: { currentPassword: staffPassword, newPassword } }, staffCookie); assert.equal(response.status, 200); staffCookie = response.headers.get("set-cookie")?.split(";")[0] ?? "";
    assert.equal((await req("/api/admin/session", "GET", undefined, beforeChangeCookie)).status, 401);
    assert.equal((await req("/api/admin/properties", "GET", undefined, staffCookie)).status, 200);
    assert.equal((await req("/api/admin/team", "POST", { name: tag, email: `forbidden-${randomUUID()}@example.invalid`, password: newPassword }, staffCookie)).status, 403);
    assert.equal((await req("/api/admin/publishing/source", "GET", undefined, staffCookie)).status, 403);
    assert.equal((await req(`/api/admin/team/${staffId}`, "PATCH", { password: staffPassword })).status, 200);
    assert.equal((await req("/api/admin/session", "GET", undefined, staffCookie)).status, 401);
    const deletedCookie = await login(staffEmail, staffPassword);
    assert.equal((await req(`/api/admin/team/${staffId}`, "DELETE")).status, 200); staffId = "";
    assert.equal((await req("/api/admin/session", "GET", undefined, deletedCookie)).status, 401);
    assert.equal((await req("/admin/login", "GET", undefined, deletedCookie)).status, 200);
    pass("First-password change enforced; old/reset/deleted sessions revoked; no login redirect loop; staff cannot create admins or download source");

    response = await fetch(base + "/api/admin/properties", { method: "POST", headers: { Cookie: ownerCookie, Origin: "https://cross-site.example", "Content-Type": "application/json" }, body: "{}" }); assert.equal(response.status, 403);
    response = await fetch(base + "/api/inquiries", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: "x".repeat(20000) }) }); assert.equal(response.status, 413);
    pass("Cross-site admin writes and excessive public request bodies are blocked");
    response = await req("/api/admin/publishing/source"); assert.equal(response.status, 200);
    const archive = unzipSync(new Uint8Array(await response.arrayBuffer()));
    const manifest = JSON.parse(new TextDecoder().decode(archive["arabic-real-estate/PROJECT-MANIFEST.json"]));
    assert.equal(Object.keys(archive).length, manifest.fileCount + 1);
    assert.ok(archive["arabic-real-estate/src/app/uploads/[...path]/route.ts"]);
    assert.ok(!archive["arabic-real-estate/.env"]);
    pass("Complete source archive includes manifest and upload route but no environment secret file");
    console.log(`Audit completed: ${passed} checks passed. Fixtures are removed in finally.`);
  } finally {
    if (ownerCookie) {
      const removals = [["inquiries", inquiryId], ["properties", propertyId], ["team", staffId], ["services", serviceId], ["areas", areaId], ["types", typeId]];
      for (const [section, id] of removals) if (id) await req(`/api/admin/${section}/${id}`, "DELETE").catch(() => {});
      if (mediaId) await req("/api/admin/media", "DELETE", { ids: [mediaId] }).catch(() => {});
      await req("/api/admin/logout", "POST").catch(() => {});
    }
    console.log("Cleanup attempted only for this audit's individually tracked fixtures; existing business records were not reset.");
  }
}
main().catch((error) => { console.error(error instanceof Error ? error.message : "Audit failed"); process.exitCode = 1; });
