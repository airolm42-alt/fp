import { readFileSync, statSync } from "node:fs";
import { dirname, isAbsolute, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { auditDeliveryFiles } from "./project-contract.mjs";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const args = new Set(process.argv.slice(2));
const accepted = new Set(["--files-only", "--help"]);
let passed = true;

function check(label, ok, hint = "") {
  console.log(`${ok ? "OK" : "NEEDS ATTENTION"}: ${label}${ok || !hint ? "" : ` — ${hint}`}`);
  if (!ok) passed = false;
}
function readJson(name) {
  try { return JSON.parse(readFileSync(join(root, name), "utf8")); } catch { return null; }
}
function sameDependencies(left = {}, right = {}) {
  const keys = new Set([...Object.keys(left), ...Object.keys(right)]);
  return [...keys].every((key) => left[key] === right[key]);
}
function hasPath(name, directory = false) {
  try {
    const info = statSync(join(root, name));
    return directory ? info.isDirectory() : info.isFile();
  } catch { return false; }
}
function isProductionOrigin(raw) {
  try {
    const candidate = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
    const url = new URL(candidate);
    const host = url.hostname.toLowerCase();
    return url.protocol === "https:" && !url.username && !url.password && !url.port &&
      url.pathname === "/" && !url.search && !url.hash && host.includes(".") &&
      !["127.0.0.1", "localhost", "e2b.app", "e2b.dev"].includes(host) &&
      !host.endsWith(".e2b.app") && !host.endsWith(".e2b.dev") &&
      host.split(".").every((part) => /^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(part));
  } catch { return false; }
}

if ([...args].some((arg) => !accepted.has(arg))) {
  console.error("Unknown option. Use --files-only to check the deployment package, or --help.");
  process.exitCode = 2;
} else if (args.has("--help")) {
  console.log("Usage: node scripts/check-deployment.mjs [--files-only]\n\n--files-only checks repository files and lockfile consistency without dependencies, environment variables, network access, or database changes.\nWithout this flag it also checks local production environment settings. It never deploys the application or changes data.");
} else {
  console.log("Deployment package files:");
  const required = [
    ["public", true],
    ["public/.gitkeep", false],
    ["public/favicon.svg", false],
    ["scripts/seed.ts", false],
    ["scripts/check-deployment.mjs", false],
    ["scripts/verify-download.mjs", false],
    ["scripts/export-project.ts", false],
    ["package.json", false],
    ["package-lock.json", false],
    [".env.example", false],
    [".gitignore", false],
    ["next.config.ts", false],
    ["next-env.d.ts", false],
    ["tsconfig.json", false],
    ["postcss.config.mjs", false],
    ["eslint.config.mjs", false],
    ["drizzle.config.ts", false],
    ["src/app/layout.tsx", false],
    ["src/app/globals.css", false],
    ["src/app/(site)/layout.tsx", false],
    ["src/app/(site)/page.tsx", false],
    ["src/app/(site)/properties/page.tsx", false],
    ["src/app/(site)/properties/[slug]/page.tsx", false],
    ["src/app/admin/(auth)/login/page.tsx", false],
    ["src/app/admin/(panel)/layout.tsx", false],
    ["src/app/api/admin/login/route.ts", false],
    ["src/app/api/admin/publishing/source/route.ts", false],
    ["src/app/api/health/route.ts", false],
    ["src/app/uploads/[...path]/route.ts", false],
    ["src/proxy.ts", false],
    ["src/db/index.ts", false],
    ["src/db/schema.ts", false],
    ["src/lib/source-export.ts", false],
    ["README.md", false],
    ["AUDIT-REPORT-AR.md", false],
    ["scripts/audit-core.ts", false],
    ["scripts/audit-browser.mjs", false],
    ["src/app/admin/(panel)/diagnostics/page.tsx", false],
    ["START-HERE.html", false],
    ["DEPLOYMENT-AR.md", false],
    ["GITHUB-PAGES-AR.md", false],
    ["github-pages/index.html", false],
    ["github-pages/src/app.tsx", false],
    ["github-pages/styles.css", false],
    ["scripts/build-pages.ts", false],
    [".github/workflows/github-pages.yml", false],
  ];
  for (const [name, directory] of required) {
    check(name, hasPath(name, directory), "Include this path in the exported repository.");
  }

  const delivery = auditDeliveryFiles(root);
  check("Complete registered delivery files and routes", delivery.ok, "Include every path in PROJECT-FILES.json, not only a small baseline list.");
  if (delivery.ok) console.log(`INFO: ${delivery.expected} required files and ${delivery.routes} application routes registered.`);
  else for (const error of delivery.errors) console.error(`  ${error}`);

  const manifest = readJson("package.json");
  const lock = readJson("package-lock.json");
  const lockedRoot = lock?.packages?.[""];
  check("NPM lockfile matches package.json", !!manifest && !!lockedRoot &&
    lock.lockfileVersion >= 2 && lockedRoot.name === manifest.name &&
    sameDependencies(manifest.dependencies, lockedRoot.dependencies) &&
    sameDependencies(manifest.devDependencies, lockedRoot.devDependencies),
    "Regenerate with npm install --package-lock-only and include the lockfile. Use npm ci for deployments.");

  if (hasPath(".env.example")) {
    const example = readFileSync(join(root, ".env.example"), "utf8");
    check("Example environment has no real credentials", ["DATABASE_URL", "AUTH_SECRET", "ADMIN_EMAIL", "ADMIN_PASSWORD"].every((key) => new RegExp(`^${key}=\\s*$`, "m").test(example)),
      "Keep credential values empty in .env.example; configure them privately on the server.");
  }
  if (hasPath(".gitignore")) {
    const ignore = readFileSync(join(root, ".gitignore"), "utf8").split(/\r?\n/).map((line) => line.trim());
    check("Secret files excluded; .env.example retained", ignore.includes(".env") && ignore.includes(".env.*") && ignore.includes("!.env.example"),
      "Ignore private .env files, but explicitly allow .env.example.");
    check("Deployment files are not explicitly excluded", !["package-lock.json", "/package-lock.json", "public/", "/public/", "scripts/", "/scripts/"].some((pattern) => ignore.includes(pattern)),
      "Do not exclude the lockfile, static assets, or deployment scripts.");
  }

  if (hasPath("PROJECT-MANIFEST.json")) {
    try {
      const { verifyDownloadedProject } = await import("./verify-download.mjs");
      const result = verifyDownloadedProject(root);
      check("All exported file fingerprints", result.ok, "Re-download or re-extract the ZIP before editing files.");
      for (const error of result.errors) console.error(`  ${error}`);
    } catch {
      check("Download verification script available", false, "Include scripts/verify-download.mjs in the extracted project.");
    }
  } else {
    console.log("INFO: no generated manifest in this working source tree. The owner's ZIP includes PROJECT-MANIFEST.json for full-file verification.");
  }
  console.log("INFO: this is a Next.js server application. index.html is not an expected source entry point; use src/app/(site)/page.tsx and the Node.js build/start workflow.");

  if (!args.has("--files-only")) {
    console.log("\nProduction environment configuration:");
    try {
      const { config } = await import("dotenv");
      config({ path: join(root, ".env"), quiet: true });
      let databaseValid = false;
      try {
        const url = new URL(process.env.DATABASE_URL ?? "");
        databaseValid = ["postgres:", "postgresql:"].includes(url.protocol) && !!url.hostname;
      } catch {}
      check("Database connection configured", databaseValid, "Set DATABASE_URL privately on the hosting provider.");
      check("Private session signing secret configured", (process.env.AUTH_SECRET?.length ?? 0) >= 32, "Generate at least 32 random characters; do not reuse a public/default secret.");
      check("Production domain configured", isProductionOrigin(process.env.NEXT_PUBLIC_SITE_URL ?? "") || isProductionOrigin(process.env.RAILWAY_PUBLIC_DOMAIN ?? ""), "Configure the HTTPS production domain, not the preview URL.");
      const uploadPath = process.env.UPLOAD_DIR?.trim() || process.env.RAILWAY_VOLUME_MOUNT_PATH?.trim() || "";
      check("Absolute image storage path configured", !!uploadPath && isAbsolute(uploadPath), "Attach a persistent Volume and configure its absolute mount path.");
    } catch {
      check("Environment checker dependencies installed", false, "Run npm ci first; --files-only works before installing dependencies.");
    }
  }

  console.log("\nThis check does not deploy a service, create tables or accounts, verify DNS/storage persistence, or confirm backups/Google indexing. It prints no secret values. File checks do not prove that files were pushed to a remote Git repository.");
  process.exitCode = passed ? 0 : 1;
}
