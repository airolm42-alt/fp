/**
 * First owner and property-type setup, NOT schema creation.
 * First create tables with: npx drizzle-kit push --config=drizzle.config.ts
 * Then run: npx tsx scripts/seed.ts (with private ADMIN_EMAIL / ADMIN_PASSWORD).
 * Existing owner credentials are preserved unless RESET_ADMIN_PASSWORD=true.
 */
import { config } from "dotenv";
config({ quiet: true });
import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { eq, sql } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { adminUsers, propertyTypes } from "../src/db/schema";

const TYPES = [
  { name: "شقة", slug: "apartment" }, { name: "فيلا", slug: "villa" },
  { name: "دوبلكس", slug: "duplex" }, { name: "بنتهاوس", slug: "penthouse" },
  { name: "تاون هاوس", slug: "townhouse" }, { name: "ستوديو", slug: "studio" },
  { name: "شالية", slug: "chalet" }, { name: "محل تجاري", slug: "shop" },
  { name: "مكتب إداري", slug: "office" }, { name: "أرض", slug: "land" },
  { name: "مخزن", slug: "warehouse" },
];

async function main() {
  const databaseUrl = process.env.DATABASE_URL;
  const email = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  const password = process.env.ADMIN_PASSWORD;
  if (!databaseUrl) throw new Error("DATABASE_URL is required");
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Set a valid ADMIN_EMAIL privately in server environment variables");
  if (!password || password.length < 12 || !/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) throw new Error("ADMIN_PASSWORD must have at least 12 characters including a letter and a number");

  const pool = new Pool({ connectionString: databaseUrl });
  const db = drizzle(pool);
  try {
    const schema = await db.execute<{ owners: string | null; types: string | null }>(sql`
      select to_regclass('public.admin_users')::text as owners,
             to_regclass('public.property_types')::text as types
    `);
    if (!schema.rows[0]?.owners || !schema.rows[0]?.types) {
      throw new Error("Required tables are missing. First run npx drizzle-kit push --config=drizzle.config.ts, then run this seed script. This script does not create tables.");
    }

    await db.transaction(async (tx) => {
      await tx.execute(sql`select pg_advisory_xact_lock(73114282)`);
      const existing = await tx.select().from(adminUsers).where(eq(adminUsers.email, email)).limit(1);
      if (existing[0]) {
        if (!existing[0].isOwner) throw new Error("This email belongs to a staff account. Use the owner's Team page to manage staff.");
        if (process.env.RESET_ADMIN_PASSWORD === "true") {
          await tx.update(adminUsers).set({ passwordHash: await bcrypt.hash(password, 12), updatedAt: new Date() }).where(eq(adminUsers.id, existing[0].id));
          console.log("Owner password explicitly reset.");
        } else {
          console.log("Existing owner preserved; no password changes.");
        }
      } else {
        const anyAdmin = await tx.select({ id: adminUsers.id }).from(adminUsers).limit(1);
        if (anyAdmin.length) throw new Error("An owner already exists. Add new admins from the protected Team page instead.");
        await tx.insert(adminUsers).values({ email, passwordHash: await bcrypt.hash(password, 12), name: "المدير", isOwner: true });
        console.log("Initial owner created.");
      }
      const anyType = await tx.select({ id: propertyTypes.id }).from(propertyTypes).limit(1);
      if (!anyType.length) await tx.insert(propertyTypes).values(TYPES).onConflictDoNothing();
    });
  } finally {
    await pool.end();
  }
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : "Owner setup failed");
  process.exitCode = 1;
});
