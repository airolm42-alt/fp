import { createHash } from "node:crypto";
import { lstatSync, readFileSync, realpathSync } from "node:fs";
import { dirname, join, resolve, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { auditDeliveryFiles, loadDeliveryContract } from "./project-contract.mjs";

export function verifyDownloadedProject(rootDirectory) {
  const root = resolve(rootDirectory);
  const errors = [];
  let verified = 0;
  let manifest;
  try {
    manifest = JSON.parse(readFileSync(join(root, "PROJECT-MANIFEST.json"), "utf8"));
  } catch {
    return { ok: false, verified: 0, errors: ["PROJECT-MANIFEST.json is missing or invalid. Download the complete ZIP from the owner's Publishing page."] };
  }
  if (manifest.format !== "arabic-real-estate-source-v1" || !Array.isArray(manifest.files) || manifest.files.length < 1 || manifest.files.length > 3000 || manifest.fileCount !== manifest.files.length) {
    return { ok: false, verified: 0, errors: ["Invalid source manifest format or file count."] };
  }
  const seen = new Set();
  const rootReal = realpathSync(root);
  for (const file of manifest.files) {
    const relative = file?.path;
    if (typeof relative !== "string" || relative.startsWith("/") || relative.includes("\\") || relative.includes("\0") || relative.split("/").some((part) => !part || part === "." || part === "..") || seen.has(relative) || !Number.isSafeInteger(file.bytes) || file.bytes < 0 || file.bytes > 16 * 1024 * 1024 || !/^[a-f0-9]{64}$/.test(file.sha256 ?? "")) {
      errors.push("Invalid or duplicate file entry in PROJECT-MANIFEST.json.");
      continue;
    }
    seen.add(relative);
    try {
      const filename = join(root, relative);
      const info = lstatSync(filename);
      const real = realpathSync(filename);
      if (!info.isFile() || info.isSymbolicLink() || !real.startsWith(rootReal + sep)) {
        errors.push(`Not a regular file inside the project: ${relative}`);
        continue;
      }
      if (info.size !== file.bytes) {
        errors.push(`Size mismatch: ${relative}`);
        continue;
      }
      const hash = createHash("sha256").update(readFileSync(filename)).digest("hex");
      if (hash !== file.sha256) errors.push(`Content mismatch: ${relative}`);
      else verified++;
    } catch {
      errors.push(`Missing or unreadable file: ${relative}`);
    }
  }
  for (const required of ["package.json", "package-lock.json", ".env.example", ".gitignore", "README.md", "START-HERE.html", "next.config.ts", "tsconfig.json", "src/app/(site)/page.tsx", "src/app/layout.tsx", "src/db/schema.ts", "src/app/uploads/[...path]/route.ts", "scripts/seed.ts", "scripts/verify-download.mjs"]) {
    if (!seen.has(required)) errors.push(`Required source path absent from manifest: ${required}`);
  }
  const delivery = auditDeliveryFiles(root);
  errors.push(...delivery.errors);
  if (delivery.ok) {
    const contract = loadDeliveryContract(root);
    for (const required of contract.files) {
      if (!seen.has(required)) errors.push(`Delivery file absent from archive manifest: ${required}`);
    }
  }
  return { ok: errors.length === 0, verified, errors };
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
  if (process.argv.includes("--help")) {
    console.log("Usage: node scripts/verify-download.mjs\nChecks every exported file against PROJECT-MANIFEST.json before installation or editing. No secrets, database, or dependencies required.");
  } else {
    const result = verifyDownloadedProject(root);
    if (result.ok) console.log(`PASS: all ${result.verified} source files match the archive manifest. This is a Next.js application; no index.html is required.`);
    else {
      for (const message of result.errors) console.error(`FAILED: ${message}`);
      console.error("Re-extract the complete source ZIP. If you already edited files, those changes also cause fingerprint differences.");
      process.exitCode = 1;
    }
  }
}
