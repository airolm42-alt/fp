/** Browser integration audit: requires a TEST deployment and private audit env vars. */
import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { chromium } from "playwright";
import sharp from "sharp";
import { config } from "dotenv";
config({ quiet: true });

async function main() {
  if (process.env.AUDIT_ALLOW_MUTATIONS !== "yes") throw new Error("Use AUDIT_ALLOW_MUTATIONS=yes only on a test deployment.");
  const base = (process.env.AUDIT_BASE_URL || "http://localhost:3000").replace(/\/$/, "");
  const email = process.env.AUDIT_ADMIN_EMAIL, password = process.env.AUDIT_ADMIN_PASSWORD;
  if (!email || !password) throw new Error("Provide private AUDIT_ADMIN_EMAIL and AUDIT_ADMIN_PASSWORD.");
  const tag = `متصفح-${randomUUID().slice(0, 8)}`;
  const browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
  const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
  context.setDefaultTimeout(15_000);
  context.setDefaultNavigationTimeout(30_000);
  const page = await context.newPage();
  const errors = [];
  page.on("pageerror", (error) => errors.push(error.message));
  let propertyId = "", imageUrl = "", inquiryId = "", serviceId = "";
  let checks = 0;
  function pass(message) { checks++; console.log(`PASS ${checks}: ${message}`); }
  async function checkWidth() { const box = await page.evaluate(() => ({ width: document.documentElement.scrollWidth, viewport: innerWidth })); assert.ok(box.width <= box.viewport + 1, `Horizontal overflow on ${page.url()}: ${JSON.stringify(box)}`); }
  try {
    for (const route of ["/", "/properties", "/about", "/services", "/contact", "/privacy", "/terms"]) {
      const response = await page.goto(base + route, { waitUntil: "domcontentloaded" }); assert.equal(response.status(), 200); await checkWidth();
      assert.equal(await page.locator('html[lang="ar"][dir="rtl"]').count(), 1);
    }
    pass("Public pages render in Arabic RTL at mobile width without horizontal overflow");
    await page.goto(base, { waitUntil: "domcontentloaded" });
    await page.getByRole("button", { name: "فتح القائمة", exact: true }).click();
    const drawer = page.getByRole("dialog", { name: "قائمة التنقل", exact: true });
    await drawer.waitFor({ state: "visible" });
    const rectangle = await drawer.boundingBox(); assert.ok(rectangle.height >= 800, "Mobile menu must cover viewport, not header height");
    await page.keyboard.press("Escape"); await drawer.waitFor({ state: "hidden" });
    pass("Mobile menu covers the screen and closes with Escape");

    await page.goto(base + "/admin/dashboard", { waitUntil: "domcontentloaded" });
    assert.ok(page.url().includes("/admin/login"));
    await page.getByLabel("البريد الإلكتروني", { exact: true }).fill(email);
    await page.getByLabel("كلمة المرور", { exact: true }).fill(password);
    await page.getByRole("button", { name: "تسجيل الدخول", exact: true }).click();
    await page.waitForURL(/\/admin\/dashboard/); await checkWidth();
    pass("Real UI login reaches the protected dashboard");
    await page.getByRole("button", { name: "فتح القائمة", exact: true }).click();
    await page.getByRole("dialog", { name: "قائمة الإدارة", exact: true }).waitFor({ state: "visible" });
    await page.keyboard.press("Escape");
    await page.getByRole("dialog", { name: "قائمة الإدارة", exact: true }).waitFor({ state: "hidden" });
    pass("Admin sidebar opens and closes on mobile");

    await page.goto(base + "/admin/services", { waitUntil: "domcontentloaded" });
    await page.getByRole("button", { name: /إضافة خدمة/, exact: false }).first().click();
    const serviceDialog = page.getByRole("dialog", { name: "إضافة خدمة", exact: true });
    await serviceDialog.waitFor({ state: "visible" });
    const serviceName = serviceDialog.getByLabel("اسم الخدمة", { exact: true });
    await serviceName.click();
    await serviceName.pressSequentially(tag, { delay: 30 });
    assert.equal(await serviceName.inputValue(), tag);
    assert.ok(await serviceName.evaluate((input) => document.activeElement === input), "Typing in a modal must not reset focus to the close button");
    await serviceDialog.getByLabel("الوصف", { exact: true }).fill("اختبار كتابة نافذة خدمة غير منشورة");
    const serviceResponse = page.waitForResponse((response) => response.url().endsWith("/api/admin/services") && response.request().method() === "POST");
    await serviceDialog.getByRole("button", { name: "إضافة الخدمة", exact: true }).click();
    const serviceSaved = await serviceResponse; assert.equal(serviceSaved.status(), 200);
    await serviceDialog.waitFor({ state: "hidden" });
    // The UI immediately refreshes this page; do not wait on a detached browser
    // response-body handle. Verify the resulting record through the protected API.
    const serviceList = await (await context.request.get(base + "/api/admin/services", { timeout: 15000 })).json();
    serviceId = serviceList.items.find((item) => item.title === tag)?.id ?? "";
    assert.ok(serviceId, "Saved service must exist in the database");
    pass("Typing and saving in service modal retains keyboard focus and works");

    await page.goto(base + "/admin/properties/new", { waitUntil: "domcontentloaded" });
    await page.getByLabel("عنوان العقار", { exact: true }).fill(tag);
    await page.getByLabel("السعر", { exact: true }).fill("250000");
    await page.getByLabel("الوصف", { exact: true }).fill("عقار اختبار واجهة مؤقت سيُحذف بعد المراجعة");
    await page.getByLabel("المنطقة / المدينة", { exact: true }).fill(tag);
    await page.getByLabel("المساحة (م²)", { exact: true }).fill("120");
    await page.getByLabel("غرف النوم", { exact: true }).fill("3");
    await page.getByLabel("الحمامات", { exact: true }).fill("2");
    const image = await sharp({ create: { width: 320, height: 240, channels: 3, background: "#174437" } }).png().toBuffer();
    const uploadResponse = page.waitForResponse((response) => response.url().endsWith("/api/admin/upload") && response.request().method() === "POST");
    await page.locator('input[type="file"]').setInputFiles({ name: `${tag}.png`, mimeType: "image/png", buffer: image });
    const uploaded = await uploadResponse; assert.equal(uploaded.status(), 200); imageUrl = (await uploaded.json()).files[0].url;
    await page.getByRole("button", { name: "اختيار من مكتبة الصور", exact: true }).click();
    const library = page.getByRole("dialog", { name: "اختر صورة موجودة في المكتبة", exact: true });
    await library.waitFor({ state: "visible" });
    await library.getByRole("button", { name: `اختيار ${tag}.png`, exact: true }).waitFor({ state: "visible" });
    await page.keyboard.press("Escape"); await library.waitFor({ state: "hidden" });
    pass("Accessible property inputs, image upload and library picker work");
    const savedResponse = page.waitForResponse((response) => response.url().endsWith("/api/admin/properties") && response.request().method() === "POST");
    await page.getByRole("button", { name: "نشر العقار", exact: true }).click();
    const saved = await savedResponse; assert.equal(saved.status(), 200);
    await page.waitForURL(/\/admin\/properties\??/);
    const propertyList = await (await context.request.get(base + `/api/admin/properties?q=${encodeURIComponent(tag)}`, { timeout: 15000 })).json();
    const property = propertyList.items.find((item) => item.title === tag);
    assert.ok(property, "Published property must be present in the database");
    propertyId = property.id;
    const publicPage = await context.newPage();
    await publicPage.goto(base + `/properties/${property.slug}`, { waitUntil: "domcontentloaded" });
    await publicPage.getByRole("heading", { level: 1, name: tag, exact: true }).waitFor({ state: "visible" });
    await publicPage.locator('img').first().waitFor({ state: "visible" });
    const imageReady = await publicPage.locator(`img[src*="${imageUrl.split('/').at(-1)}"]`).first().evaluate((img) => img.complete && img.naturalWidth > 0); assert.ok(imageReady);
    pass("UI publishing creates a real public property with a rendered image");

    await page.goto(base + `/admin/properties/${propertyId}`, { waitUntil: "domcontentloaded" });
    await page.getByLabel("عنوان العقار", { exact: true }).fill(tag + " تعديل");
    const editResponse = page.waitForResponse((response) => response.url().endsWith(`/api/admin/properties/${propertyId}`) && response.request().method() === "PUT");
    await page.getByRole("button", { name: "تحديث النشر", exact: true }).click();
    assert.equal((await editResponse).status(), 200);
    await publicPage.reload({ waitUntil: "domcontentloaded" });
    await publicPage.getByRole("heading", { level: 1, name: tag + " تعديل", exact: true }).waitFor();
    pass("UI edits update public property without changing its URL");
    await publicPage.getByLabel("الاسم بالكامل", { exact: true }).fill(tag);
    await publicPage.getByLabel("رقم الهاتف", { exact: true }).fill("01000000000");
    await publicPage.getByLabel("رسالتك", { exact: true }).fill(tag + " رسالة من الواجهة");
    await publicPage.getByRole("button", { name: "إرسال الرسالة", exact: true }).click();
    await publicPage.getByText("تم إرسال رسالتك بنجاح", { exact: true }).waitFor();
    const messages = await (await context.request.get(base + `/api/admin/inquiries?q=${encodeURIComponent(tag)}`)).json();
    inquiryId = messages.items.find((item) => item.name === tag).id;
    pass("Public browser inquiry saves to database and appears in admin");
    await context.request.patch(base + `/api/admin/properties/${propertyId}`, { data: { status: "draft" }, headers: { Origin: base } });
    assert.equal((await publicPage.reload({ waitUntil: "domcontentloaded" })).status(), 404);
    await publicPage.close();
    pass("Unpublished property is removed publicly");
    for (const width of [768, 1440]) {
      await page.setViewportSize({ width, height: 900 });
      await page.goto(base + "/properties", { waitUntil: "domcontentloaded" }); await checkWidth();
      await page.goto(base + "/admin/dashboard", { waitUntil: "domcontentloaded" }); await checkWidth();
    }
    assert.deepEqual(errors, []);
    pass("Tablet/desktop layouts render without overflow or JavaScript page errors");
    console.log(`Browser audit: ${checks} checks passed.`);
  } finally {
    if (inquiryId) await context.request.delete(base + `/api/admin/inquiries/${inquiryId}`, { headers: { Origin: base } }).catch(() => {});
    if (propertyId) await context.request.delete(base + `/api/admin/properties/${propertyId}`, { headers: { Origin: base } }).catch(() => {});
    if (serviceId) await context.request.delete(base + `/api/admin/services/${serviceId}`, { headers: { Origin: base } }).catch(() => {});
    if (imageUrl) {
      const result = await context.request.get(base + "/api/admin/media").catch(() => null);
      const library = result?.ok() ? await result.json() : null;
      const file = library?.items?.find((item) => item.url === imageUrl);
      if (file) await context.request.delete(base + "/api/admin/media", { data: { ids: [file.id] }, headers: { Origin: base } }).catch(() => {});
    }
    await context.request.post(base + "/api/admin/logout", { headers: { Origin: base } }).catch(() => {});
    await browser.close();
    console.log("Only this browser audit's tracked fixtures were removed; existing records were not reset.");
  }
}
main().catch((error) => { console.error(error instanceof Error ? error.message : "Browser audit failed"); process.exitCode = 1; });
