import { readFileSync, statSync } from "node:fs";
import { dirname, join, relative, resolve } from "node:path";
import { isBuiltin } from "node:module";
import { fileURLToPath, pathToFileURL } from "node:url";
import { auditDeliveryFiles, listActualSourceFiles, loadDeliveryContract } from "./project-contract.mjs";

/** Check local imports, declared dependencies, and all expected routes, read-only. */
export async function auditSource(rootDirectory) {
  const root = resolve(rootDirectory);
  const filesCheck = auditDeliveryFiles(root);
  if (!filesCheck.ok) return { ...filesCheck, imports: 0, packages: 0 };
  let ts;
  try { ts = (await import("typescript")).default; }
  catch { return { ok: false, errors: ["Install build dependencies with npm ci --include=dev before checking imports."], expected: filesCheck.expected, routes: 0, imports: 0, packages: 0 }; }
  const contract = loadDeliveryContract(root);
  const manifest = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
  const declared = new Set([...Object.keys(manifest.dependencies ?? {}), ...Object.keys(manifest.devDependencies ?? {})]);
  const errors = [];
  const usedPackages = new Set();
  const config = ts.readConfigFile(join(root, "tsconfig.json"), ts.sys.readFile);
  if (config.error) return { ok: false, errors: ["Invalid TypeScript configuration."], expected: filesCheck.expected, routes: 0, imports: 0, packages: 0 };
  const compiler = ts.parseJsonConfigFileContent(config.config, ts.sys, root).options;
  const options = { ...compiler, allowJs: true, noEmit: true };
  const cache = ts.createModuleResolutionCache(root, (name) => name, options);
  let imports = 0;
  const sourceNames = [...new Set([...contract.files, ...listActualSourceFiles(root)])].filter((file) => /\.(?:tsx?|mjs|cjs|jsx?)$/.test(file) && !file.endsWith(".d.ts"));
  const syntaxTrees = new Map();
  for (const filename of sourceNames) {
    const absolute = join(root, filename);
    const text = readFileSync(absolute, "utf8");
    const kind = filename.endsWith(".tsx") ? ts.ScriptKind.TSX : /\.[mc]?js$/.test(filename) ? ts.ScriptKind.JS : ts.ScriptKind.TS;
    const tree = ts.createSourceFile(absolute, text, ts.ScriptTarget.Latest, true, kind);
    syntaxTrees.set(filename, tree);
    for (const diagnostic of tree.parseDiagnostics ?? []) {
      const line = tree.getLineAndCharacterOfPosition(diagnostic.start ?? 0).line + 1;
      errors.push(`${filename}:${line}: syntax error: ${ts.flattenDiagnosticMessageText(diagnostic.messageText, " ")}`);
    }
    function checkSpecifier(node, name) {
      if (typeof name !== "string") return;
      imports++;
      const local = name.startsWith(".") || name.startsWith("@/");
      if (isBuiltin(name)) return;
      if (!local) {
        const pkg = name.startsWith("@") ? name.split("/").slice(0, 2).join("/") : name.split("/")[0];
        usedPackages.add(pkg);
        if (!declared.has(pkg)) { errors.push(`${filename}: undeclared package import ${name}`); return; }
      }
      let target = ts.resolveModuleName(name, absolute, options, ts.sys, cache).resolvedModule?.resolvedFileName;
      if (!target && local) {
        const raw = name.startsWith("@/") ? join(root, "src", name.slice(2)) : resolve(dirname(absolute), name);
        try { if (statSync(raw).isFile()) target = raw; } catch {}
      }
      if (!target) {
        const line = tree.getLineAndCharacterOfPosition(node.getStart()).line + 1;
        errors.push(`${filename}:${line}: missing import ${name}`);
      } else if (local && !relative(root, target).startsWith("node_modules")) {
        const targetRelative = relative(root, target).replaceAll("\\", "/");
        if (targetRelative.startsWith("../") || !contract.files.includes(targetRelative)) errors.push(`${filename}: local import target not registered for delivery: ${targetRelative}`);
      }
    }
    function walk(node) {
      if ((ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) && node.moduleSpecifier && ts.isStringLiteralLike(node.moduleSpecifier)) checkSpecifier(node, node.moduleSpecifier.text);
      if (ts.isCallExpression(node) && (node.expression.kind === ts.SyntaxKind.ImportKeyword || ts.isIdentifier(node.expression) && node.expression.text === "require") && node.arguments[0] && ts.isStringLiteralLike(node.arguments[0])) checkSpecifier(node, node.arguments[0].text);
      ts.forEachChild(node, walk);
    }
    walk(tree);
  }
  const expected = new Set(contract.files);
  for (const filename of listActualSourceFiles(root)) if (!expected.has(filename)) errors.push(`New source file not registered in PROJECT-FILES.json: ${filename}. Review and update the delivery list intentionally.`);
  const actualRoutes = listActualSourceFiles(root).filter((file) => /^src\/app\/.+\/(?:page\.tsx|route\.ts)$/.test(file) || file === "src/app/page.tsx" || file === "src/app/robots.ts" || file === "src/app/sitemap.ts");
  for (const file of actualRoutes) if (!contract.routes.some((route) => route.file === file)) errors.push(`Route not registered for delivery: ${file}`);
  for (const route of contract.routes) {
    const derivedPath = route.kind === "metadata"
      ? route.file === "src/app/robots.ts" ? "/robots.txt" : route.file === "src/app/sitemap.ts" ? "/sitemap.xml" : ""
      : route.file.startsWith("src/app/")
        ? "/" + route.file.slice("src/app/".length).split("/").slice(0, -1).filter((part) => !/^\(.+\)$/.test(part)).join("/")
        : "";
    if (derivedPath !== route.path) errors.push(`Registered route path does not match its Next.js file: ${route.path} (${route.file})`);
    const tree = syntaxTrees.get(route.file);
    if (!tree) { errors.push(`Route source could not be parsed: ${route.file}`); continue; }
    if (route.kind === "handler") {
      const exported = new Set();
      for (const node of tree.statements) {
        if (!node.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword)) continue;
        if (ts.isFunctionDeclaration(node) && node.name) exported.add(node.name.text);
        if (ts.isVariableStatement(node)) for (const declaration of node.declarationList.declarations) if (ts.isIdentifier(declaration.name)) exported.add(declaration.name.text);
      }
      for (const method of route.methods) if (!exported.has(method)) errors.push(`Expected HTTP method missing: ${method} ${route.path} (${route.file})`);
    } else if (!tree.statements.some((node) => ts.isExportAssignment(node) || node.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.DefaultKeyword))) {
      errors.push(`Expected default route export missing: ${route.path}`);
    }
  }
  return { ok: errors.length === 0, expected: filesCheck.expected, routes: contract.routes.length, imports, packages: usedPackages.size, errors };
}

if (process.argv[1] && pathToFileURL(resolve(process.argv[1])).href === import.meta.url) {
  const args = process.argv.slice(2);
  if (args.includes("--help")) console.log("Usage: node scripts/check-source.mjs [--root <project-directory>]\nRequires npm ci --include=dev. Checks all required source files, routes, HTTP exports, local imports and declared package dependencies; it never changes data or deploys a site.");
  else if (args.length && (args.length !== 2 || args[0] !== "--root")) { console.error("Use --root <directory> or --help."); process.exitCode = 2; }
  else {
    const root = args[1] ? resolve(args[1]) : resolve(dirname(fileURLToPath(import.meta.url)), "..");
    try {
      const result = await auditSource(root);
      if (result.ok) console.log(`PASS: ${result.expected} delivery files, ${result.routes} application routes, ${result.imports} import references and ${result.packages} declared packages verified.`);
      else { for (const error of result.errors) console.error(`FAILED: ${error}`); process.exitCode = 1; }
    } catch (error) { console.error(error instanceof Error ? error.message : "Source audit failed"); process.exitCode = 1; }
  }
}
