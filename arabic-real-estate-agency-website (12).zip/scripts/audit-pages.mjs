/** End-to-end static Pages + real backend test. Creates only tagged temporary fixtures. */
import assert from "node:assert/strict";
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { spawnSync } from "node:child_process";
import { config } from "dotenv";
import { chromium } from "playwright";
import sharp from "sharp";
config({ quiet: true });

async function main() {
  if (process.env.AUDIT_ALLOW_MUTATIONS !== "yes") throw new Error("Run only on a test deployment with AUDIT_ALLOW_MUTATIONS=yes");
  const backend = (process.env.AUDIT_BASE_URL || "http://localhost:3000").replace(/\/$/, "");
  const port = Number(process.env.AUDIT_PAGES_PORT || 4177);
  const origin = `http://127.0.0.1:${port}`;
  const prefix = "/test-repository/";
  const base = origin + prefix;
  if (!process.env.AUDIT_ADMIN_EMAIL || !process.env.AUDIT_ADMIN_PASSWORD) throw new Error("Set private audit owner credentials");
  let cookie = "", propertyId = "", draftId = "", mediaId = "", inquiryId = "";
  let server, browser;
  const tag = `Pages-${randomUUID().slice(0, 8)}`;
  let checks = 0;
  function pass(message) { checks++; console.log(`PASS ${checks}: ${message}`); }
  async function request(route, method = "GET", data, authenticated = true, requestOrigin = backend) {
    return fetch(backend + route, { method, redirect: "manual", headers: { ...(authenticated && cookie ? { Cookie: cookie } : {}), ...(requestOrigin ? { Origin: requestOrigin } : {}), ...(data !== undefined ? { "Content-Type": "application/json" } : {}) }, body: data === undefined ? undefined : JSON.stringify(data) });
  }
  try {
    let response = await request("/api/pages", "GET", undefined, false, origin);
    assert.equal(response.status, 200);
    const configuration = await response.json();
    assert.ok(configuration.inquiriesEnabled, `Test frontend ${origin} must be included in PAGES_ALLOWED_ORIGINS on the backend before testing`);
    for (const key of ["passwordHash", "adminUsers", "DATABASE_URL", "AUTH_SECRET", "inquiries"]) assert.ok(!JSON.stringify(configuration).includes(`"${key}"`));
    assert.equal(configuration.adminUrl, backend + "/admin");
    pass("Public bridge returns only public configuration and the real admin URL");
    response = await request("/api/pages/inquiries", "OPTIONS", undefined, false, origin);
    assert.equal(response.status, 204); assert.equal(response.headers.get("access-control-allow-origin"), origin); assert.equal(response.headers.get("access-control-allow-credentials"), null);
    assert.equal((await request("/api/pages/inquiries", "OPTIONS", undefined, false, "https://forbidden.example")).status, 403);
    assert.equal((await request("/api/pages/inquiries", "POST", { name: tag, phone: "01000000000", message: tag }, false, "https://forbidden.example")).status, 403);
    pass("Allowed frontend preflight works; other origins and credential sharing are rejected");
    response = await request("/api/admin/login", "POST", { email: process.env.AUDIT_ADMIN_EMAIL, password: process.env.AUDIT_ADMIN_PASSWORD }, false);
    assert.equal(response.status, 200); cookie = response.headers.get("set-cookie")?.split(";")[0] ?? "";
    assert.ok(cookie);
    const image = await sharp({ create: { width: 480, height: 320, channels: 3, background: "#174437" } }).png().toBuffer();
    const form = new FormData(); form.append("files", new Blob([image], { type: "image/png" }), `${tag}.png`);
    response = await fetch(backend + "/api/admin/upload", { method: "POST", headers: { Cookie: cookie, Origin: backend }, body: form }); assert.equal(response.status, 200);
    const imageUrl = (await response.json()).files[0].url;
    const media = await (await request("/api/admin/media")).json(); mediaId = media.items.find((file) => file.url === imageUrl).id;
    const input = { title: tag + " منشور", description: "تفاصيل عقار اختبار ربط Pages حقيقي مؤقت", listingType: "sale", price: 123456, currency: "ج.م", location: tag, area: 120, bedrooms: 3, bathrooms: 2, mainImage: imageUrl, images: [{ url: imageUrl, alt: tag }], status: "published", featured: true };
    response = await request("/api/admin/properties", "POST", input); assert.equal(response.status, 200); const published = await response.json(); propertyId = published.id;
    response = await request("/api/admin/properties", "POST", { ...input, title: tag + " مسودة", status: "draft", featured: false }); assert.equal(response.status, 200); const draft = await response.json(); draftId = draft.id;
    response = await request(`/api/pages?resource=properties&q=${encodeURIComponent(tag)}`, "GET", undefined, false, origin);
    const feed = await response.json(); assert.equal(feed.total, 1); assert.equal(feed.items[0].id, propertyId); assert.ok(feed.items[0].mainImage.startsWith(backend + "/uploads/"));
    assert.equal((await request(`/api/pages?resource=property&slug=${encodeURIComponent(draft.slug)}`, "GET", undefined, false, origin)).status, 404);
    pass("Real published property and absolute image are public; draft remains inaccessible");

    const built = spawnSync("npx", ["--no-install", "tsx", "scripts/build-pages.ts", "--allow-local"], { env: { ...process.env, PAGES_API_URL: backend, PAGES_SITE_URL: base }, encoding: "utf8", timeout: 120000 });
    if (built.status !== 0) throw new Error(built.stderr || built.stdout || "Static build failed");
    const artifactRoot = path.resolve("out-pages");
    const metadata = JSON.parse(await readFile(path.join(artifactRoot, "PAGES-BUILD.json"), "utf8"));
    assert.equal(metadata.requiresLiveBackend, true); assert.equal(metadata.containsCredentials, false);
    assert.ok(metadata.files.some((file) => file.path === "index.html"));
    pass("Static build emits index.html without needing database credentials in the artifact");

    server = createServer(async (req, res) => {
      try {
        const url = new URL(req.url, origin);
        if (!url.pathname.startsWith(prefix)) { res.writeHead(404); res.end(); return; }
        const relative = decodeURIComponent(url.pathname.slice(prefix.length)) || "index.html";
        if (relative.includes("..") || relative.includes("\\")) { res.writeHead(400); res.end(); return; }
        const filename = path.join(artifactRoot, relative.endsWith("/") ? relative + "index.html" : relative);
        const bytes = await readFile(filename);
        const type = filename.endsWith(".html") ? "text/html; charset=utf-8" : filename.endsWith(".js") ? "text/javascript; charset=utf-8" : filename.endsWith(".css") ? "text/css; charset=utf-8" : filename.endsWith(".svg") ? "image/svg+xml" : "text/plain; charset=utf-8";
        res.writeHead(200, { "Content-Type": type, "Cache-Control": "no-store" }); res.end(bytes);
      } catch { res.writeHead(404); res.end(); }
    });
    await new Promise((resolve, reject) => { server.once("error", reject); server.listen(port, "127.0.0.1", resolve); });
    browser = await chromium.launch({ headless: true, args: ["--no-sandbox"] });
    const context = await browser.newContext({ viewport: { width: 390, height: 844 } }); context.setDefaultTimeout(12000);
    const page = await context.newPage(); const errors = [];
    page.on("pageerror", (error) => errors.push(error.message));
    await page.goto(base, { waitUntil: "domcontentloaded" });
    await page.getByRole("heading", { name: "عقارات مميزة", exact: true }).waitFor();
    await page.getByRole("heading", { name: input.title, exact: true }).waitFor();
    assert.equal(await page.locator('input[type="password"]').count(), 0);
    const widths = await page.evaluate(() => ({ width: document.documentElement.scrollWidth, viewport: innerWidth })); assert.ok(widths.width <= widths.viewport + 1);
    await page.getByRole("button", { name: "فتح القائمة", exact: true }).click();
    const drawer = page.getByRole("dialog", { name: "قائمة التنقل", exact: true }); await drawer.waitFor({ state: "visible" });
    assert.ok((await drawer.boundingBox()).height >= 830); await page.keyboard.press("Escape"); await drawer.waitFor({ state: "hidden" });
    pass("Published data renders from another origin under a repository path; mobile navigation and asset paths work");

    for (const [route, heading] of [["/about", "من نحن"], ["/services", "خدماتنا"], ["/contact", "تواصل معنا"], ["/privacy", "سياسة الخصوصية"], ["/terms", "الشروط والأحكام"]]) {
      await page.goto(base + "#" + route, { waitUntil: "domcontentloaded" }); await page.getByRole("heading", { level: 1, name: heading, exact: true }).waitFor();
    }
    await page.goto(base + "#/properties", { waitUntil: "domcontentloaded" });
    await page.getByLabel("كلمة البحث", { exact: true }).fill(tag);
    await page.getByRole("button", { name: "تطبيق البحث", exact: true }).click();
    await page.getByRole("heading", { name: input.title, exact: true }).waitFor();
    assert.equal(await page.getByRole("heading", { name: tag + " مسودة", exact: true }).count(), 0);
    await page.getByRole("link", { name: "عرض التفاصيل", exact: true }).first().click();
    await page.getByRole("heading", { level: 1, name: input.title, exact: true }).waitFor();
    await page.waitForFunction(() => [...document.querySelectorAll('.gallery-main img')].some((image) => image.complete && image.naturalWidth > 0));
    await page.getByRole("button", { name: "تكبير صورة العقار", exact: true }).click();
    await page.getByRole("dialog", { name: "معرض صور العقار", exact: true }).waitFor(); await page.keyboard.press("Escape");
    pass("All public routes, real server filters, details, backend images and gallery work on static hosting");

    await page.getByLabel("الاسم بالكامل", { exact: true }).fill(tag);
    await page.getByLabel("رقم الهاتف", { exact: true }).fill("01000000000");
    await page.getByLabel("رسالتك", { exact: true }).fill("رسالة من اختبار الواجهة الثابتة " + tag);
    await page.getByRole("button", { name: "إرسال الاستفسار", exact: true }).click();
    await page.getByRole("heading", { name: "تم إرسال رسالتك بنجاح", exact: true }).waitFor();
    const inquiries = await (await request(`/api/admin/inquiries?q=${encodeURIComponent(tag)}`)).json(); inquiryId = inquiries.items.find((item) => item.name === tag).id;
    pass("A real browser CORS form submission is saved to the real inquiries database");
    response = await request(`/api/admin/properties/${propertyId}`, "PUT", { ...input, title: tag + " معدل" }); assert.equal(response.status, 200); assert.equal((await response.json()).slug, published.slug);
    await page.reload({ waitUntil: "domcontentloaded" }); await page.getByRole("heading", { level: 1, name: tag + " معدل", exact: true }).waitFor();
    await request(`/api/admin/properties/${propertyId}`, "PATCH", { status: "draft" });
    await page.reload({ waitUntil: "domcontentloaded" }); await page.getByRole("heading", { name: "العقار غير متاح حاليًا", exact: true }).waitFor();
    pass("Backend edits and unpublishing reach the static UI live without rebuilding");

    const adminLink = page.getByRole("link", { name: /دخول الإدارة/ }).last(); assert.equal(await adminLink.getAttribute("href"), backend + "/admin");
    const adminPage = await context.newPage(); await adminPage.goto(base + "admin/", { waitUntil: "domcontentloaded" }); await adminPage.waitForURL(/\/admin\/login/); assert.ok(adminPage.url().startsWith(backend)); await adminPage.close();
    await page.route("**/api/pages?*", (route) => route.abort("failed")); await page.reload({ waitUntil: "domcontentloaded" });
    await page.getByRole("heading", { name: "تعذّر الاتصال ببيانات الموقع", exact: true }).waitFor();
    assert.equal(await page.getByRole("heading", { name: input.title, exact: true }).count(), 0);
    assert.deepEqual(errors, []);
    pass("Admin navigates to real protected login; an unavailable backend shows an honest error, never fake data");
    console.log(`Pages end-to-end audit passed: ${checks} checks.`);
  } finally {
    if (cookie) {
      if (inquiryId) await request(`/api/admin/inquiries/${inquiryId}`, "DELETE").catch(() => {});
      if (propertyId) await request(`/api/admin/properties/${propertyId}`, "DELETE").catch(() => {});
      if (draftId) await request(`/api/admin/properties/${draftId}`, "DELETE").catch(() => {});
      if (mediaId) await request("/api/admin/media", "DELETE", { ids: [mediaId] }).catch(() => {});
      await request("/api/admin/logout", "POST").catch(() => {});
    }
    if (browser) await browser.close();
    if (server) await new Promise((resolve) => server.close(resolve));
    console.log("Only this audit's tagged fixtures were removed. Static test server and browser stopped.");
  }
}
main().catch((error) => { console.error(error instanceof Error ? error.message : "Pages audit failed"); process.exitCode = 1; });
