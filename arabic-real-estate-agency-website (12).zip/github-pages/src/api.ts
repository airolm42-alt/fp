export type PagesRuntime = { apiOrigin: string; siteUrl: string; version: 1 };
const element = document.getElementById("pages-runtime");
export const runtime: PagesRuntime = JSON.parse(element?.textContent || "{}");
if (!runtime.apiOrigin || !/^https?:\/\//.test(runtime.apiOrigin)) throw new Error("عنوان خادم البيانات غير مضبوط في بناء الواجهة");
export class PublicApiError extends Error { constructor(message: string, public status: number) { super(message); } }

export async function publicRequest<T>(resource: string, query = "", signal?: AbortSignal): Promise<T> {
  const url = new URL("/api/pages", runtime.apiOrigin);
  for (const [key, value] of new URLSearchParams(query)) if (value) url.searchParams.set(key, value);
  url.searchParams.set("resource", resource);
  const response = await fetch(url, { signal, credentials: "omit", cache: "no-store" });
  const data = await response.json().catch(() => null);
  if (!response.ok || !data) throw new PublicApiError(data?.error || "تعذّر تحميل البيانات من الخادم", response.status);
  return data as T;
}
export async function sendInquiry(data: { name: string; phone: string; email: string; message: string; propertyId: string | null; website: string }) {
  const response = await fetch(new URL("/api/pages/inquiries", runtime.apiOrigin), { method: "POST", credentials: "omit", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data), signal: AbortSignal.timeout(20000) });
  const result = await response.json().catch(() => null);
  if (!response.ok) throw new PublicApiError(result?.error || "تعذّر إرسال الرسالة، حاول مرة أخرى", response.status);
  return result;
}
export function routeHref(path: string) { return `#${path.startsWith("/") ? path : `/${path}`}`; }
export function navigate(path: string) { window.location.hash = path; }
